# Arabic Bridge Program — Architecture Proposal & Roadmap
**Status:** Awaiting owner's approval · **Date:** 2026-10-10
**Project state:** Empty — greenfield build (no existing code to preserve).

---

## 1. Recommended Technology Stack

### Choice: Django (Python) + PostgreSQL

**Why Django — in simple words:**
- **One language (Python)** for everything — easiest for a beginner to read and maintain later.
- **Free built-in admin panel** — Django gives you a secure admin dashboard out of the box. A large part of the "Administrator Dashboard" (managing students, teachers, courses, fees) comes almost free.
- **Built-in login & security** — password hashing, sessions, protection against common attacks (CSRF, XSS, SQL injection) are included and battle-tested. We will not invent our own auth.
- **Database migrations are automatic** — changing the data model later is safe and simple.
- **Huge documentation & community** — any future developer can pick it up.

**Why not the alternatives?**
- *Next.js (JavaScript):* modern and fast, but needs separate frontend + backend skills — harder for a beginner owner to maintain.
- *Laravel (PHP):* also good, but Python/Django has the gentler learning curve and the stronger free admin panel.

**Other pieces:**
- **Database:** PostgreSQL (free, reliable, the standard for Django).
- **Frontend:** Django templates + a clean CSS framework (responsive for desktop/tablet/mobile). No heavy JavaScript framework needed — keeps it maintainable.
- **File uploads (books, PDFs):** stored on the server with secure handling; OCR via Tesseract (free, open-source) when books are scanned images.
- **Background jobs** (reminders, 90-day recording cleanup): Celery + Redis, or a simpler scheduler to start.

### Assumption
The admin/teacher/student portals will be primarily in **English**, with full support for **Arabic content** (lessons, Quranic text, RTL display). If you want a full Arabic UI translation later, that's a separate phase.

---

## 2. Costs — explained before we rely on anything

| Item | Cost | When needed |
|---|---|---|
| Building the portal (my work) | Free | Now |
| Code hosting (GitHub) | Free | Now |
| App hosting — Render/Railway starter | Free tier to start (~$5–15/month when serious) | Phase 9 (deployment) |
| Domain name (e.g. arabicbridgeprogram.com) | ~$10–15/year | Phase 9 |
| PostgreSQL database | Free tier included with hosting | Phase 9 |
| **Zoom** (Pro plan — required for meeting APIs & attendance reports) | ~$15/month | Phase 4 — will explain fully before activation |
| **WhatsApp Business API** (per-message cost) | Varies, pay per message | Phase 7 — optional, manual fallback first |
| Email sending (OTP, notifications) | Free tier (e.g. Resend free 3,000/month) | Phase 1/7 |

**No paid service will be activated without your explicit approval.**

---

## 3. Project Roadmap — one phase at a time

Each phase ends with: summary + test results + **your approval** before the next begins.

| Phase | Scope | Key deliverables |
|---|---|---|
| **0 — Setup & Branding** | Project skeleton, logo (SVG), colors, directory structure, docs | Logo files, favicon, branding guide, README |
| **1 — Accounts & Roles** | Login/auth, 4 roles (admin/teacher/student/guardian), registration + admin approval, auto student IDs (ABP-2026-0001), password reset, audit log start | Working login, role dashboards (basic) |
| **2 — Courses & Books** | 4 course tracks structure, book upload (PDF/Word/images), OCR, curriculum chapters/topics (structure only — content after you supply books) | Book library, curriculum organizer |
| **3 — Lessons & Progress** | Lessons (text/audio/video), exercises, completion rules, lesson unlocking, progress tracking | Student lesson flow |
| **4 — Scheduling & Zoom** | Class scheduling (30-min, 1:1 & group), Zoom links, reminders, attendance (Zoom + teacher), late/absence rules | Working class cycle |
| **5 — Homework & Tests** | Assignments, submissions, grading, tests, speaking/listening assessments | Assessment flow |
| **6 — Fees & Finance** | Fee setup, payments, receipts (PDF), overdue tracking, teacher salaries, financial reports | Finance module |
| **7 — Notifications & Recordings** | Email/WhatsApp notifications, class recordings (90-day retention) | Comms module |
| **8 — Reports & Certificates** | Progress reports, certificates (PDF), backups, full audit logs | Reporting module |
| **9 — Deployment** | Production deploy, domain, backups, security checklist | Live portal |

**Deliberately deferred until you supply them:** final curriculum content, course levels and level names (per your spec §4 — no invented curriculum).

---

## 4. Decisions needed from you (only 3)

1. **Tech stack:** Approve Django + PostgreSQL? (recommended above)
2. **Fee currency:** Which currency for fees/receipts? (default: USD unless you say otherwise)
3. **Phase 1 first, or branding first?** I recommend **Phase 0 (branding + setup)** so the logo/colors exist before we build screens on top of them.

Reply with your answers and I'll begin. Nothing gets built until you approve.
