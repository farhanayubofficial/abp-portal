# Review File — All Quizzes (English)

How to review: Read each question. If anything is wrong, note the question number
and send it to me (e.g. 'Q5 answer is wrong, correct is X'). I will fix it.
Mark ✓ for lessons that are fully correct.

---

# Quranic Arabic

## Lesson 1: Detached Pronouns

**Q1** (MCQ)
Question: What is the translation of هُمْ مُسْلِمُونَ?
  1. He is a Muslim
  2. They are all Muslims
  3. You are all Muslims
  4. We are all Muslims
Correct answer: They are all Muslims
Hint: Remember the book's first table

**Q2** (Fill in the blank)
Question: Fill in the blank: هُوَ ___ (He is a Muslim)
Correct answer: مُسْلِمٌ
Hint: The book's first example

**Q3** (MCQ)
Question: How do you say 'I am a Muslim' in Arabic?
  1. هُوَ مُسْلِمٌ
  2. أَنَا مُسْلِمٌ
  3. أَنْتَ مُسْلِمٌ
  4. نَحْنُ مُسْلِمُونَ
Correct answer: أَنَا مُسْلِمٌ

**Q4** (Q&A)
Question: What are detached pronouns? Explain with the book's example.
Model answer (teacher only): Detached pronouns are written separately, e.g. هُوَ، هُمْ، أَنْتَ، أَنَا، نَحْنُ. The book's example: هُوَ مُسْلِمٌ (He is a Muslim).


## Lesson 2: Singular, Dual, Plural

**Q5** (MCQ)
Question: What is the dual of صَالِح?
  1. صَالِحُونَ
  2. صَالِحَانِ
  3. صَالِحَۃ
  4. اَلصَّالِح
Correct answer: صَالِحَانِ
Hint: Book rule: add ان for dual

**Q6** (Fill in the blank)
Question: Fill in the blank: the plural of مُؤْمِن is ___
Correct answer: مُؤْمِنُونَ
Hint: Add ون for plural

**Q7** (MCQ)
Question: According to the book, how do you form the dual?
  1. Add ون at the end
  2. Add ان at the end
  3. Add ال at the start
  4. Add ۃ at the end
Correct answer: Add ان at the end

**Q8** (Q&A)
Question: Form the dual and plural of کَافِر.
Model answer (teacher only): Dual: کَافِرَانِ (two disbelievers), Plural: کَافِرُونَ — the book's example.


## Lesson 3: Attached Pronouns

**Q9** (MCQ)
Question: In اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ, whose pronoun is the ي in لِي?
  1. Third person (for him)
  2. Second person (for you)
  3. First person (for me)
  4. Third person feminine
Correct answer: First person (for me)
Hint: The dua when entering the masjid

**Q10** (Fill in the blank)
Question: Fill in the blank: رَحْمَتِ ___ (Your mercy) — attach the pronoun
Correct answer: کَ
Hint: From the book's dua: أَبْوَابَ رَحْمَتِكَ

**Q11** (MCQ)
Question: What does أَسْأَلُكَ mean?
  1. I ask him
  2. I ask You
  3. You ask me
  4. We ask You
Correct answer: I ask You
Hint: Dua: اللَّهُمَّ إِنِّي أَسْأَلُكَ مِنْ فَضْلِكَ

**Q12** (Q&A)
Question: Define attached pronouns with an example from the book's dua.
Model answer (teacher only): Attached pronouns join a word, e.g. لِي (ل+ي = for me), رَحْمَتِكَ (Your mercy), أَسْأَلُكَ (I ask You).


## Lesson 4: Attached Pronouns Practice

**Q13** (MCQ)
Question: What does كِتَابُهُ mean?
  1. My book
  2. Your book
  3. His book
  4. Our book
Correct answer: His book

**Q14** (Fill in the blank)
Question: Fill in the blank: دِينُ ___ (Our religion)
Correct answer: نَا
Hint: نَا is the first-person plural pronoun

**Q15** (MCQ)
Question: How do you say 'Your Lord' in Arabic?
  1. رَبُّهُ
  2. رَبُّكَ
  3. رَبِّي
  4. رَبُّهُمْ
Correct answer: رَبُّكَ

**Q16** (Q&A)
Question: What is the difference between رَسُولُهُ and رَسُولُكَ?
Model answer (teacher only): رَسُولُهُ = His messenger (third-person pronoun هُ), رَسُولُكَ = Your messenger (second-person pronoun کَ).


## Lesson 5: More Words with Attached Pronouns

**Q17** (MCQ)
Question: What does أَبُوهُ mean?
  1. His mother
  2. His father
  3. His brother
  4. His son
Correct answer: His father
Hint: Book: six well-known relations

**Q18** (Fill in the blank)
Question: Fill in the blank: أُخْتُ ___ (His sister)
Correct answer: هُ
Hint: Third-person pronoun

**Q19** (MCQ)
Question: How do you say 'My mother' in Arabic?
  1. أُمُّهُ
  2. أُمِّي
  3. أُمُّكَ
  4. أُمُّهُمْ
Correct answer: أُمِّي

**Q20** (Q&A)
Question: Write the book's six well-known relations in Arabic.
Model answer (teacher only): أَب (father), أُمّ (mother), اِبْن (son), بِنْت (daughter), أَخ (brother), أُخْت (sister).


## Lesson 6: Feminine Pronouns and Plurals

**Q21** (MCQ)
Question: What does هِيَ mean?
  1. He
  2. She
  3. They (dual)
  4. They (feminine plural)
Correct answer: She

**Q22** (Fill in the blank)
Question: Fill in the blank: هُنَّ ___ (They [women] are Muslims)
Correct answer: مُسْلِمَاتٌ
Hint: Feminine plural

**Q23** (MCQ)
Question: What is the plural of مُسْلِمَۃ?
  1. مُسْلِمُونَ
  2. مُسْلِمَاتٌ
  3. مُسْلِمَانِ
  4. مُسْلِمَتَانِ
Correct answer: مُسْلِمَاتٌ

**Q24** (Q&A)
Question: Explain the difference between masculine and feminine pronouns with examples.
Model answer (teacher only): Masculine: هُوَ (he), هُمْ (they). Feminine: هِيَ (she), هُنَّ (they feminine).


## Lesson 7: Seven Prepositions

**Q25** (MCQ)
Question: In السَّلَامُ عَلَيْكُمْ, what does عَلَى mean?
  1. In
  2. From
  3. Upon
  4. Towards
Correct answer: Upon

**Q26** (Fill in the blank)
Question: Fill in the blank: فِي سَبِيلِ ___ (In the path of Allah)
Correct answer: اللَّهِ
Hint: The book's example

**Q27** (MCQ)
Question: In وَإِنَّا إِلَيْهِ رَاجِعُونَ, what does إِلَى mean?
  1. From
  2. In
  3. Upon
  4. Towards
Correct answer: Towards

**Q28** (Q&A)
Question: List the book's seven prepositions with one example.
Model answer (teacher only): بِ، لِ، مِنْ، عَنْ، إِلَى، عَلَى، فِي. Example: رَضِيَ اللَّهُ عَنْهُ (Allah is pleased with him). They occur 6,861 times in the Quran.


## Lesson 8: Six Special Particles

**Q29** (MCQ)
Question: What does إِنَّ mean?
  1. Perhaps
  2. Indeed / Verily
  3. But
  4. As if
Correct answer: Indeed / Verily

**Q30** (Fill in the blank)
Question: Fill in the blank: ___ زَيْدٌ قَائِمٌ (As if Zaid is standing)
Correct answer: کَأَنَّ
Hint: One of the six special particles

**Q31** (MCQ)
Question: Which particle means 'if only' (wish)?
  1. لَعَلَّ
  2. لٰکِنَّ
  3. لَيْتَ
  4. أَنَّ
Correct answer: لَيْتَ

**Q32** (Q&A)
Question: What are the six special particles?
Model answer (teacher only): إِنَّ (indeed), أَنَّ (that), کَأَنَّ (as if), لٰکِنَّ (but), لَيْتَ (if only), لَعَلَّ (perhaps).


## Lesson 9: Past Tense Verb

**Q33** (MCQ)
Question: Which time does the past tense verb indicate?
  1. Happening now
  2. Will happen
  3. Completed action (past)
  4. Command
Correct answer: Completed action (past)
Hint: Perfect tense

**Q34** (Fill in the blank)
Question: In the conjugation of فَعَلَ, 'you all did' is ___
Correct answer: فَعَلْتُمْ
Hint: Remember the book's table

**Q35** (MCQ)
Question: Which is one of the book's famous past-tense patterns?
  1. یَفْتَحُ
  2. فَتَحَ
  3. اِفْتَحْ
  4. مَفْتُوح
Correct answer: فَتَحَ

**Q36** (Q&A)
Question: Write the full conjugation (14 forms) of فَعَلَ.
Model answer (teacher only): فَعَلَ، فَعَلَا، فَعَلُوا، فَعَلَتْ، فَعَلَتَا، فَعَلْنَ، فَعَلْتَ، فَعَلْتُمَا، فَعَلْتُمْ، فَعَلْتِ، فَعَلْتُمَا، فَعَلْتُنَّ، فَعَلْتُ، فَعَلْنَا.


## Lesson 10: Past Tense with Negation

**Q37** (MCQ)
Question: What does مَا فَعَلَ mean?
  1. He did
  2. He did not do
  3. He is doing
  4. He will do
Correct answer: He did not do

**Q38** (Fill in the blank)
Question: Fill in the blank: ___ عَلِمَ (He did not know)
Correct answer: مَا
Hint: Negation particle for past tense

**Q39** (MCQ)
Question: How do you say 'We did not hear' in Arabic?
  1. لَا نَسْمَعُ
  2. مَا سَمِعْنَا
  3. لَمْ نَسْمَعْ
  4. لَنْ نَسْمَعَ
Correct answer: مَا سَمِعْنَا

**Q40** (Q&A)
Question: How is the past tense negated? Give an example.
Model answer (teacher only): Put مَا before the past verb: مَا فَعَلَ (he did not do), مَا عَلِمَ (he did not know).


## Lesson 11: Present Tense Verb

**Q41** (MCQ)
Question: Which time does the present tense verb indicate?
  1. Already done
  2. Happening now / will happen
  3. Completed
  4. Command
Correct answer: Happening now / will happen

**Q42** (Fill in the blank)
Question: Fill in the blank: ___ يَفْعَلُ (He does) — the opening letter
Correct answer: يَ
Hint: Sign of the present tense

**Q43** (MCQ)
Question: How do you say 'I am writing' in Arabic?
  1. کَتَبَ
  2. أَکْتُبُ
  3. اُکْتُبْ
  4. مَکْتُوب
Correct answer: أَکْتُبُ

**Q44** (Q&A)
Question: What are the present-tense prefix letters?
Model answer (teacher only): Four letters: ی، ت، ا، ن — e.g. یَفْعَلُ (he does), تَفْعَلُ (you do), أَفْعَلُ (I do), نَفْعَلُ (we do).


## Lesson 12: Present Tense with Negation

**Q45** (MCQ)
Question: What does لَا يَفْعَلُ mean?
  1. He does
  2. He does not do / will not do
  3. He did not do
  4. He will never do
Correct answer: He does not do / will not do

**Q46** (Fill in the blank)
Question: Fill in the blank: ___ يَعْلَمُ (He does not know)
Correct answer: لَا
Hint: Negation for present tense

**Q47** (MCQ)
Question: How do you say 'You (plural) do not write'?
  1. مَا کَتَبْتُمْ
  2. لَا تَکْتُبُونَ
  3. لَمْ تَکْتُبُوا
  4. لَنْ تَکْتُبُوا
Correct answer: لَا تَکْتُبُونَ

**Q48** (Q&A)
Question: What is the difference between the negation of مَا and لَا?
Model answer (teacher only): مَا negates the past (مَا فَعَلَ = he did not do); لَا negates the present (لَا یَفْعَلُ = he does not do).


## Lesson 13: Two Special Negation Particles

**Q49** (MCQ)
Question: What does لَنْ يَفْعَلَ mean?
  1. He does not do
  2. He did not do
  3. He will never do
  4. He is doing
Correct answer: He will never do
Hint: Book: لَنْ = will never

**Q50** (Fill in the blank)
Question: Fill in the blank: ___ يَفْعَلْ (He did not do)
Correct answer: لَمْ
Hint: Special negation particle for the past

**Q51** (MCQ)
Question: According to the book, what does the لَنْ 'hammer' do?
  1. It adds a ن
  2. It drops the ن
  3. It does nothing
  4. It makes it past tense
Correct answer: It drops the ن (يَفْعَلُونَ → لَنْ يَفْعَلُوا)

**Q52** (Q&A)
Question: What is the difference between لَنْ and لَمْ?
Model answer (teacher only): لَنْ is for emphatic future negation (لَنْ یَفْعَلَ = he will never do); لَمْ is for past negation (لَمْ یَفْعَلْ = he did not do).


## Lesson 14: Command and Prohibition

**Q53** (MCQ)
Question: What does اِفْعَلْ mean?
  1. He did
  2. He does
  3. Do!
  4. Don't do
Correct answer: Do!

**Q54** (Fill in the blank)
Question: Fill in the blank: ___ تَفْعَلْ (Don't do!)
Correct answer: لَا
Hint: Particle of prohibition

**Q55** (MCQ)
Question: How do you say 'Write!' in Arabic?
  1. کَتَبَ
  2. یَکْتُبُ
  3. اُکْتُبْ
  4. لَا تَکْتُبْ
Correct answer: اُکْتُبْ

**Q56** (Q&A)
Question: Define command and prohibition with examples.
Model answer (teacher only): Command (امر) is an order: اِفْعَلْ (do!). Prohibition (نہی) is forbidding: لَا تَفْعَلْ (don't do!).


## Lesson 15: Active and Passive Participles

**Q57** (MCQ)
Question: What does فَاعِل mean?
  1. Done
  2. Doer
  3. Doing (verb)
  4. Place
Correct answer: Doer

**Q58** (Fill in the blank)
Question: From کَتَبَ, the passive participle is ___
Correct answer: مَکْتُوب
Hint: Written

**Q59** (MCQ)
Question: What does نَاصِر mean?
  1. Helped
  2. Helper
  3. To help
  4. Place of help
Correct answer: Helper

**Q60** (Q&A)
Question: What is the difference between active and passive participles?
Model answer (teacher only): Active participle is the doer (کَاتِب = writer); passive participle is what was done (مَکْتُوب = written).


## Lesson 16: Four Basic Verb Patterns

**Q61** (MCQ)
Question: Which is the first of the book's four basic patterns?
  1. ضَرَبَ يَضْرِبُ
  2. فَتَحَ يَفْتَحُ
  3. نَصَرَ يَنْصُرُ
  4. سَمِعَ يَسْمَعُ
Correct answer: فَتَحَ يَفْتَحُ

**Q62** (Fill in the blank)
Question: Fill in the blank: the present of ضَرَبَ is ___
Correct answer: يَضْرِبُ
Hint: Second pattern

**Q63** (MCQ)
Question: Which pattern is سَمِعَ يَسْمَعُ?
  1. First
  2. Second
  3. Third
  4. Fourth
Correct answer: Fourth

**Q64** (Q&A)
Question: Write the four basic patterns (past and present).
Model answer (teacher only): 1st: فَتَحَ یَفْتَحُ, 2nd: ضَرَبَ یَضْرِبُ, 3rd: نَصَرَ یَنْصُرُ, 4th: سَمِعَ یَسْمَعُ.


## Lesson 17: Revision of the Four Patterns

**Q65** (MCQ)
Question: What is the present tense of فَعَلَ?
  1. فَعَلَ
  2. يَفْعَلُ
  3. اِفْعَلْ
  4. فَاعِل
Correct answer: يَفْعَلُ

**Q66** (Fill in the blank)
Question: From نَصَرَ, the active participle is ___
Correct answer: نَاصِر
Hint: Helper

**Q67** (MCQ)
Question: What does مَا فَتَحَ mean?
  1. He opened
  2. He did not open
  3. He is opening
  4. Open!
Correct answer: He did not open

**Q68** (Q&A)
Question: What is the benefit of knowing the verb patterns?
Model answer (teacher only): Once you know the pattern, you can form the present, command, and participles from the past — the key to understanding Quranic words.


## Lesson 18: Passive Voice

**Q69** (MCQ)
Question: What does فُعِلَ mean?
  1. He did
  2. It was done
  3. He does
  4. Do!
Correct answer: It was done

**Q70** (Fill in the blank)
Question: کُتِبَ means ___
Correct answer: it was written
Hint: Passive form

**Q71** (MCQ)
Question: Difference between active and passive voice?
  1. No difference
  2. Active: doer known; passive: doer hidden/unknown
  3. Passive has no past
  4. Active is a command
Correct answer: Active: doer known; passive: doer hidden/unknown

**Q72** (Q&A)
Question: Define the passive voice with an example.
Model answer (teacher only): When the doer is unknown, the passive is used: فُعِلَ (it was done), کُتِبَ (it was written).


## Lesson 19: Demonstrative Pronouns

**Q73** (MCQ)
Question: What does هٰذَا mean?
  1. That (far)
  2. This (near)
  3. Which
  4. Who
Correct answer: This (near)

**Q74** (Fill in the blank)
Question: Fill in the blank: ___ کِتَابٌ (That is a book — for far)
Correct answer: ذٰلِكَ
Hint: Far demonstrative

**Q75** (MCQ)
Question: How do you say 'This is a pen' in Arabic?
  1. ذٰلِكَ قَلَمٌ
  2. هٰذَا قَلَمٌ
  3. اَلَّذِي قَلَمٌ
  4. مَا قَلَمٌ
Correct answer: هٰذَا قَلَمٌ

**Q76** (Q&A)
Question: Write the near and far demonstratives.
Model answer (teacher only): Near: هٰذَا (this masc.), هٰذِهِ (this fem.). Far: ذٰلِكَ (that masc.), تِلْكَ (that fem.).


## Lesson 20: Relative Pronouns

**Q77** (MCQ)
Question: What does اَلَّذِي mean?
  1. Who (feminine)
  2. This
  3. That
  4. Who / which (masculine singular)
Correct answer: Who / which (masculine singular)

**Q78** (Fill in the blank)
Question: اَلْمَرْأَۃُ ___ قَامَتْ (The woman who stood) — fill in
Correct answer: اَلَّتِي
Hint: Feminine relative

**Q79** (MCQ)
Question: In 'those who believed', the Arabic for 'who' (plural) is?
  1. اَلَّذِي
  2. اَلَّتِي
  3. اَلَّذِينَ
  4. مَا
Correct answer: اَلَّذِينَ

**Q80** (Q&A)
Question: What are the relative pronouns?
Model answer (teacher only): اَلَّذِي (who — masc. sing.), اَلَّتِي (who — fem. sing.), اَلَّذِينَ (who — plural).


## Lesson 1: The Doubled Verb (Muda'af)

**Q81** (MCQ)
Question: What is a muda'af verb?
  1. A verb with a hamzah
  2. A verb in which one letter is doubled
  3. A verb with a weak letter
  4. A verb with an extra alif
Correct answer: A verb in which one letter is doubled

**Q82** (Fill in the blank)
Question: Fill in the blank: عَزَّ originally was ___
Correct answer: عَزَزَ
Hint: The book shows the doubled letter opened up

**Q83** (MCQ)
Question: How many times does عَزَّ appear in the Quran according to the book?
  1. 33
  2. 118
  3. 20
  4. 8
Correct answer: 118

**Q84** (Q&A)
Question: Explain the muda'af verb with the book's examples.
Model answer (teacher only): A muda'af verb is one in which a letter is doubled, e.g. عَزَّ (= عَزَزَ), مَرَّ (= مَرَرَ), ضَلَّ (= ضَلَلَ), ھَمَّ (= ھَمَمَ). The book counts 99 such verbs used 2013 times in the Quran.


## Lesson 2: The Hamzah Verb (Mahmuz)

**Q85** (MCQ)
Question: What is a mahmuz verb?
  1. A verb with a doubled letter
  2. A verb containing a hamzah
  3. A verb with a weak letter
  4. A passive verb
Correct answer: A verb containing a hamzah

**Q86** (MCQ)
Question: أَکَلَ is an example of which type?
  1. Mahmuz al-fa (hamzah first)
  2. Mahmuz al-ain (hamzah middle)
  3. Mahmuz al-lam (hamzah last)
  4. Muda'af
Correct answer: Mahmuz al-fa (hamzah first)

**Q87** (Fill in the blank)
Question: Fill in the blank: the imperative of أَخَذَ is ___
Correct answer: خُذْ
Hint: The book shows the hamzah drops in the imperative

**Q88** (Q&A)
Question: What are the three natural types of mahmuz verbs? Give the book's examples.
Model answer (teacher only): Mahmuz al-fa: أَکَلَ (he ate). Mahmuz al-ain: سَأَلَ (he asked). Mahmuz al-lam: قَرَأَ (he read). The book counts 62 mahmuz verbs used 3085 times in the Quran.


## Lesson 3: Weak First Letter (Mithal)

**Q89** (MCQ)
Question: What is a mithal verb?
  1. A verb with a weak letter at the start
  2. A verb with a weak letter in the middle
  3. A verb with a weak letter at the end
  4. A doubled verb
Correct answer: A verb with a weak letter at the start

**Q90** (MCQ)
Question: وَجَدَ is an example of:
  1. Mithal
  2. Ajwaf
  3. Naqis
  4. Mahmuz
Correct answer: Mithal

**Q91** (Fill in the blank)
Question: The weak letters (huruf 'illah) are: ا, و, ___
Correct answer: ی
Hint: Three weak letters

**Q92** (Q&A)
Question: Define the mithal verb with an example from the book.
Model answer (teacher only): A mithal verb has a weak letter (ا، و، ی) as its first root letter, e.g. وَجَدَ (he found). The book notes it appears 108 times in the Quran.


## Lesson 4: Mithal - More Examples

**Q93** (MCQ)
Question: In وَجَدَ, which letter is the weak letter?
  1. و (first letter)
  2. ج (middle letter)
  3. د (last letter)
  4. None
Correct answer: و (first letter)

**Q94** (Fill in the blank)
Question: Mithal verbs begin with one of the weak letters, for example وَجَدَ begins with ___
Correct answer: و

**Q95** (MCQ)
Question: Which of these is a mithal verb?
  1. قَالَ
  2. دَعَا
  3. وَجَدَ
  4. عَزَّ
Correct answer: وَجَدَ

**Q96** (Q&A)
Question: How do you recognize a mithal verb in the Quran?
Model answer (teacher only): Look for a verb whose first root letter is و, ا, or ی, like وَجَدَ. The weak first letter often changes or drops in different forms.


## Lesson 5: Weak Middle Letter (Ajwaf)

**Q97** (MCQ)
Question: What is an ajwaf verb?
  1. A verb with a weak letter at the start
  2. A verb with a weak letter in the middle
  3. A verb with a weak letter at the end
  4. A hamzah verb
Correct answer: A verb with a weak letter in the middle

**Q98** (MCQ)
Question: قَالَ یَقُولُ is an example of:
  1. Ajwaf wawi
  2. Ajwaf ya'i
  3. Mithal
  4. Naqis
Correct answer: Ajwaf wawi

**Q99** (Fill in the blank)
Question: Fill in the blank: قَالَ becomes ___ in the present tense
Correct answer: یَقُولُ
Hint: The book's conjugation table

**Q100** (Q&A)
Question: Explain ajwaf wawi and ajwaf ya'i with the book's examples.
Model answer (teacher only): Ajwaf wawi: middle letter is و, e.g. قَالَ یَقُولُ (he said / he says). Ajwaf ya'i: middle letter is ی, e.g. بَاعَ یَبِیعُ (he sold / he sells). The book counts 116 ajwaf-wawi verbs used 5366 times. Example: وَقُولُوا لِلنَّاسِ حُسْنًا (and speak to people kindly).


## Lesson 6: Weak Last Letter (Naqis)

**Q101** (MCQ)
Question: What is a naqis verb?
  1. A verb with a weak letter at the start
  2. A verb with a weak letter in the middle
  3. A verb with a weak letter at the end
  4. A doubled verb
Correct answer: A verb with a weak letter at the end

**Q102** (MCQ)
Question: دَعَا is an example of:
  1. Mithal
  2. Ajwaf
  3. Naqis
  4. Mahmuz
Correct answer: Naqis

**Q103** (Fill in the blank)
Question: In دَعَا the weak letter at the end is ___
Correct answer: ا
Hint: The last root letter

**Q104** (Q&A)
Question: Define the naqis verb with the book's example.
Model answer (teacher only): A naqis verb has a weak letter (ا، و، ی) as its last root letter, e.g. دَعَا (he called/prayed). The book notes 207 occurrences in the Quran.


## Lesson 7: Naqis - More Examples

**Q105** (MCQ)
Question: Which letter pattern marks a naqis verb?
  1. Weak letter as the first root letter
  2. Doubled middle letter
  3. Weak letter as the last root letter
  4. Hamzah in the middle
Correct answer: Weak letter as the last root letter

**Q106** (Fill in the blank)
Question: دَعَا is naqis because its ___ letter is weak
Correct answer: last

**Q107** (MCQ)
Question: Which of these is naqis?
  1. وَجَدَ
  2. قَالَ
  3. دَعَا
  4. سَأَلَ
Correct answer: دَعَا

**Q108** (Q&A)
Question: How does a naqis verb change in conjugation? Use دَعَا as an example.
Model answer (teacher only): The final weak letter of دَعَا changes with pronouns: دَعَا (he called), دَعَوَا (they two called), دَعَوْا (they called). The weak ending drops or changes - this is the key sign of naqis verbs.


## Lesson 8: The If'al Pattern (Bab Af'al)

**Q109** (MCQ)
Question: What is the pattern of Bab Af'al?
  1. فَعَّلَ
  2. أَفْعَلَ
  3. فَاعَلَ
  4. اِفْتَعَلَ
Correct answer: أَفْعَلَ

**Q110** (MCQ)
Question: أَسْلَمَ (he submitted/accepted Islam) belongs to which bab?
  1. Bab Af'al
  2. Bab Taf'il
  3. Bab Mufa'ala
  4. Bab Istif'al
Correct answer: Bab Af'al

**Q111** (Fill in the blank)
Question: Bab Af'al adds a ___ at the beginning of the three-letter root
Correct answer: hamzah (أ)
Hint: أَفْعَلَ pattern

**Q112** (Q&A)
Question: Explain Bab Af'al with the book's example.
Model answer (teacher only): Bab Af'al follows the pattern أَفْعَلَ, formed by adding a hamzah before the root. Example: أَسْلَمَ (he submitted). The book counts 186 occurrences in the Quran. It often gives a causative or transitive meaning.


## Lesson 9: If'al - More Examples

**Q113** (MCQ)
Question: Which of these follows the أَفْعَلَ pattern?
  1. سَبَّحَ
  2. أَسْلَمَ
  3. قَاتَلَ
  4. اِسْتَغْفَرَ
Correct answer: أَسْلَمَ

**Q114** (Fill in the blank)
Question: The present tense of أَسْلَمَ is ___
Correct answer: یُسْلِمُ
Hint: Bab Af'al present tense

**Q115** (MCQ)
Question: What does the extra hamzah in Bab Af'al usually add to the meaning?
  1. Past tense only
  2. Causative/transitive force
  3. Plural meaning
  4. Negation
Correct answer: Causative/transitive force

**Q116** (Q&A)
Question: Give two Quranic words from Bab Af'al and their meanings.
Model answer (teacher only): Examples from the book's method: أَسْلَمَ (he submitted), آمَنَ (he believed - from أَفْعَلَ pattern). Both show the hamzah of Af'al added to the root.


## Lesson 10: If'al - Pattern Practice

**Q117** (MCQ)
Question: Identify the bab: أَنْزَلَ
  1. Bab Af'al
  2. Bab Taf'il
  3. Bab Infi'al
  4. Bab Istif'al
Correct answer: Bab Af'al

**Q118** (Fill in the blank)
Question: أَنْزَلَ means 'he sent down'. Its root letters are ن ز ___
Correct answer: ل
Hint: Three root letters

**Q119** (MCQ)
Question: The imperative of أَسْلَمَ is:
  1. سَلِّمْ
  2. أَسْلِمْ
  3. اِسْتَسْلِمْ
  4. سَالِمْ
Correct answer: أَسْلِمْ

**Q120** (Q&A)
Question: How do you identify a Bab Af'al verb in the Quran?
Model answer (teacher only): Look for the أَ prefix with a sukoon on the first root letter: أَفْعَلَ pattern, e.g. أَسْلَمَ، أَنْزَلَ، آمَنَ. The present tense is یُفْعِلُ and imperative is أَفْعِلْ.


## Lesson 11: If'al - Examples Practice

**Q121** (MCQ)
Question: آمَنَ belongs to which bab?
  1. Bab Af'al
  2. Bab Fa'ala (simple)
  3. Bab Taf'il
  4. Bab Mufa'ala
Correct answer: Bab Af'al

**Q122** (Fill in the blank)
Question: آمَنَ is originally أَأْمَنَ on the pattern ___
Correct answer: أَفْعَلَ

**Q123** (MCQ)
Question: What is the verbal noun (masdar) pattern of Bab Af'al?
  1. تَفْعِیل
  2. إِفْعَال
  3. مُفَاعَلَۃ
  4. اِفْتِعَال
Correct answer: إِفْعَال

**Q124** (Q&A)
Question: Why does آمَنَ look different from أَسْلَمَ though both are Bab Af'al?
Model answer (teacher only): آمَنَ comes from the root ا-م-ن where the first root letter is a hamzah; two hamzahs merge (أَأْمَنَ → آمَنَ). The pattern is still أَفْعَلَ - this is the mahmuz + Af'al combination the book teaches.


## Lesson 12: If'al - More Practice

**Q125** (MCQ)
Question: Which sentence contains a Bab Af'al verb: إِنَّ الَّذِینَ آمَنُوا...?
  1. الَّذِینَ
  2. آمَنُوا
  3. إِنَّ
  4. No Af'al verb
Correct answer: آمَنُوا

**Q126** (Fill in the blank)
Question: In وَأَقِیمُوا الصَّلَاۃَ, أَقِیمُوا is Bab ___
Correct answer: Af'al
Hint: أَفْعَلَ pattern imperative

**Q127** (MCQ)
Question: The ism fa'il (doer noun) of Bab Af'al follows which pattern?
  1. فَاعِل
  2. مُفْعِل
  3. مُفَعِّل
  4. مُفْتَعِل
Correct answer: مُفْعِل

**Q128** (Q&A)
Question: Write the full pattern set of Bab Af'al using أَسْلَمَ.
Model answer (teacher only): Past: أَسْلَمَ, present: یُسْلِمُ, imperative: أَسْلِمْ, doer: مُسْلِم, done-to: مُسْلَم, verbal noun: إِسْلَام. The book teaches all forms together so students recognize them in the Quran.


## Lesson 13: The Taf'il Pattern (Bab Taf'il)

**Q129** (MCQ)
Question: What is the pattern of Bab Taf'il?
  1. أَفْعَلَ
  2. فَعَّلَ
  3. فَاعَلَ
  4. تَفَعَّلَ
Correct answer: فَعَّلَ

**Q130** (MCQ)
Question: سَبَّحَ (he glorified) belongs to which bab?
  1. Bab Af'al
  2. Bab Taf'il
  3. Bab Mufa'ala
  4. Bab Tafa'ul
Correct answer: Bab Taf'il

**Q131** (Fill in the blank)
Question: Bab Taf'il doubles the ___ root letter
Correct answer: middle
Hint: فَعَّلَ - shaddah on the middle letter

**Q132** (Q&A)
Question: Explain Bab Taf'il with the book's five examples.
Model answer (teacher only): Bab Taf'il follows فَعَّلَ with a shaddah on the middle letter. The book's five examples: صَدَّقَ (33 times), سَبَّحَ (48), سَخَّرَ (26), سَلَّمَ (12), زَوَّجَ (5). Example ayah: وَاذْکُرْ رَبَّکَ کَثِیرًا وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْکَارِ (3:41) - glorify your Lord morning and evening.


## Lesson 14: Taf'il - Practice

**Q133** (MCQ)
Question: وَسَبِّحْ in وَسَبِّحْ بِالْعَشِيِّ is:
  1. Past tense
  2. Imperative of Bab Taf'il
  3. Present tense
  4. Verbal noun
Correct answer: Imperative of Bab Taf'il

**Q134** (Fill in the blank)
Question: زَوَّجَ means 'he married (someone) off'. Its bab is ___
Correct answer: Taf'il

**Q135** (MCQ)
Question: The verbal noun pattern of Bab Taf'il is:
  1. إِفْعَال
  2. تَفْعِیل
  3. مُفَاعَلَۃ
  4. اِسْتِفْعَال
Correct answer: تَفْعِیل

**Q136** (Q&A)
Question: What meaning does the shaddah (doubling) add in Bab Taf'il?
Model answer (teacher only): The doubled middle letter in فَعَّلَ adds intensity or causation: سَبَّحَ (he glorified repeatedly), صَدَّقَ (he confirmed firmly), کَذَّبَ (he denied strongly). Compare simple سَبَحَ (he swam).


## Lesson 15: The Mufa'ala Pattern (Bab Mufa'ala)

**Q137** (MCQ)
Question: What is the pattern of Bab Mufa'ala?
  1. فَعَّلَ
  2. فَاعَلَ
  3. تَفَاعَلَ
  4. أَفْعَلَ
Correct answer: فَاعَلَ

**Q138** (MCQ)
Question: قَاتَلَ (he fought) belongs to which bab?
  1. Bab Af'al
  2. Bab Taf'il
  3. Bab Mufa'ala
  4. Bab Ifti'al
Correct answer: Bab Mufa'ala

**Q139** (Fill in the blank)
Question: Bab Mufa'ala adds an ___ after the first root letter
Correct answer: alif (ا)
Hint: فَاعَلَ pattern

**Q140** (Q&A)
Question: Explain Bab Mufa'ala with its meaning.
Model answer (teacher only): Bab Mufa'ala follows فَاعَلَ with an alif after the first root letter, e.g. قَاتَلَ (he fought), جَاھَدَ (he struggled). It usually shows mutual or shared action between two sides. The book counts 44 occurrences in the Quran.


## Lesson 16: The Tafa''ul Pattern (Bab Tafa''ul)

**Q141** (MCQ)
Question: What is the pattern of Bab Tafa''ul?
  1. تَفَاعَلَ
  2. تَفَعَّلَ
  3. اِفْتَعَلَ
  4. اِنْفَعَلَ
Correct answer: تَفَعَّلَ

**Q142** (MCQ)
Question: تَذَکَّرَ (he reminded himself / took heed) belongs to which bab?
  1. Bab Taf'il
  2. Bab Tafa''ul
  3. Bab Istif'al
  4. Bab Af'al
Correct answer: Bab Tafa''ul

**Q143** (Fill in the blank)
Question: Bab Tafa''ul is the reflexive of Bab ___
Correct answer: Taf'il
Hint: تَفَعَّلَ relates to فَعَّلَ

**Q144** (Q&A)
Question: Explain the relationship between Bab Taf'il and Bab Tafa''ul.
Model answer (teacher only): Bab Tafa''ul (تَفَعَّلَ) is the reflexive of Bab Taf'il (فَعَّلَ): the action comes back on the doer. E.g. عَلَّمَ (he taught) → تَعَلَّمَ (he learned/taught himself). The book counts 63 occurrences.


## Lesson 17: The Tafa'ul Pattern (Bab Tafa'ul)

**Q145** (MCQ)
Question: What is the pattern of Bab Tafa'ul?
  1. تَفَعَّلَ
  2. تَفَاعَلَ
  3. اِفْتَعَلَ
  4. اِسْتَفْعَلَ
Correct answer: تَفَاعَلَ

**Q146** (MCQ)
Question: تَقَاتَلَ (they fought one another) belongs to which bab?
  1. Bab Mufa'ala
  2. Bab Tafa'ul
  3. Bab Tafa''ul
  4. Bab Infi'al
Correct answer: Bab Tafa'ul

**Q147** (Fill in the blank)
Question: Bab Tafa'ul is the mutual form of Bab ___
Correct answer: Mufa'ala
Hint: تَفَاعَلَ relates to فَاعَلَ

**Q148** (Q&A)
Question: Explain the relationship between Bab Mufa'ala and Bab Tafa'ul.
Model answer (teacher only): Bab Tafa'ul (تَفَاعَلَ) is the mutual/reflexive of Bab Mufa'ala (فَاعَلَ): قَاتَلَ (he fought someone) → تَقَاتَلَ (they fought one another). It shows shared action. The book counts 23 occurrences.


## Lesson 18: The Ifti'al Pattern (Bab Ifti'al)

**Q149** (MCQ)
Question: What is the pattern of Bab Ifti'al?
  1. اِنْفَعَلَ
  2. اِفْتَعَلَ
  3. اِسْتَفْعَلَ
  4. أَفْعَلَ
Correct answer: اِفْتَعَلَ

**Q150** (MCQ)
Question: آتَى (he gave) - its masdar إِیتَاء belongs to which bab?
  1. Bab Af'al
  2. Bab Ifti'al
  3. Bab Taf'il
  4. Bab Istif'al
Correct answer: Bab Ifti'al

**Q151** (Fill in the blank)
Question: In وَآتُوا الزَّکَاۃَ (and give zakah), آتُوا is the ___ of آتَى
Correct answer: imperative (plural)
Hint: Al-Baqarah 2:43

**Q152** (Q&A)
Question: Explain Bab Ifti'al with the book's example of آتَى.
Model answer (teacher only): Bab Ifti'al follows اِفْتَعَلَ. The book's example: آتَى یُؤْتِي إِیتَاء (he gave). Quranic example: وَآتُوا الصَّلَاۃَ... وَآتُوا الزَّکَاۃَ وَارْکَعُوا مَعَ الرَّاکِعِینَ (2:43) - establish prayer, give zakah, bow with those who bow. Also: إِنَّ الَّذِینَ آمَنُوا... وَآتَوُا الزَّکَاۃَ (2:277).


## Lesson 19: The Infi'al Pattern (Bab Infi'al)

**Q153** (MCQ)
Question: What is the pattern of Bab Infi'al?
  1. اِفْتَعَلَ
  2. اِنْفَعَلَ
  3. اِسْتَفْعَلَ
  4. تَفَعَّلَ
Correct answer: اِنْفَعَلَ

**Q154** (MCQ)
Question: اِنْقَطَعَ (it was cut off) belongs to which bab?
  1. Bab Ifti'al
  2. Bab Infi'al
  3. Bab Istif'al
  4. Bab Af'al
Correct answer: Bab Infi'al

**Q155** (Fill in the blank)
Question: Bab Infi'al usually gives a ___ (passive-like) meaning
Correct answer: reflexive/passive
Hint: The action happens by itself

**Q156** (Q&A)
Question: Explain the meaning of Bab Infi'al.
Model answer (teacher only): Bab Infi'al (اِنْفَعَلَ) shows the action happening to the subject by itself, like a reflexive passive: قَطَعَ (he cut) → اِنْقَطَعَ (it got cut off). The book counts 63 occurrences in the Quran.


## Lesson 20: The Istif'al Pattern (Bab Istif'al)

**Q157** (MCQ)
Question: What is the pattern of Bab Istif'al?
  1. اِسْتَفْعَلَ
  2. اِفْتَعَلَ
  3. اِنْفَعَلَ
  4. تَفَاعَلَ
Correct answer: اِسْتَفْعَلَ

**Q158** (MCQ)
Question: اِسْتَغْفَرَ (he sought forgiveness) belongs to which bab?
  1. Bab Af'al
  2. Bab Ifti'al
  3. Bab Istif'al
  4. Bab Taf'il
Correct answer: Bab Istif'al

**Q159** (Fill in the blank)
Question: Bab Istif'al usually means seeking or ___ something
Correct answer: requesting
Hint: اِسْتَغْفَرَ = he sought forgiveness

**Q160** (Q&A)
Question: Explain the meaning of Bab Istif'al with examples.
Model answer (teacher only): Bab Istif'al (اِسْتَفْعَلَ) usually means seeking or requesting: اِسْتَغْفَرَ (he sought forgiveness), اِسْتَعَانَ (he sought help - as in إِیَّاکَ نَسْتَعِینُ, You alone we ask for help). The book counts 55 occurrences in the Quran.


## Lesson 1: Mufrad & Murakkab — Possessive and Adjective Phrases

**Q161** (MCQ)
Question: What is the meaning of بَیْتُ اللَّهِ?
  1. The houses of Allah
  2. The house of Allah
  3. Allah's houses
  4. A house
Correct answer: The house of Allah
Hint: Book example: Mudaf + Mudaf Ilaih

**Q162** (Fill in the blank)
Question: Fill in: رَبُّ ___ = 'your Lord' (attached pronoun)
Correct answer: کَ
Hint: Book: رَبُّکَ — مخاطب کی ضمیر

**Q163** (MCQ)
Question: Which of these is a MURAKKAB (phrase)?
  1. رَبٌّ
  2. عَلَی
  3. رَبُّ الْعَالَمِینَ
  4. أَنْعَمْتَ
Correct answer: رَبُّ الْعَالَمِینَ

**Q164** (Q&A)
Question: Explain Mudaf + Mudaf Ilaih with a book example.
Model answer (teacher only): Two words joined by possession: first word = Mudaf, second = Mudaf Ilaih. Example: بَیْتُ اللَّهِ (the house of Allah), دُعَاءُ الرَّسُولِ (the call of the Messenger).


## Lesson 2: Nominal (Ismiyyah) and Verbal (Fi'liyyah) Sentences

**Q165** (MCQ)
Question: اللَّهُ أَحَدٌ is which type of sentence?
  1. Jumlah Ismiyyah (nominal)
  2. Jumlah Fi'liyyah (verbal)
  3. Murakkab Naqis
  4. Idafah phrase
Correct answer: Jumlah Ismiyyah (nominal)

**Q166** (Fill in the blank)
Question: In a Jumlah Ismiyyah, the two parts are Mubtada and ___
Correct answer: Khabar
Hint: Subject and predicate

**Q167** (MCQ)
Question: صَدَقَ اللَّهُ is a Jumlah Fi'liyyah because it starts with:
  1. A noun
  2. A verb (Fi'l)
  3. A particle
  4. A pronoun
Correct answer: A verb (Fi'l)

**Q168** (Q&A)
Question: What are the parts of خَلَقَ اللَّهُ السَّمَاوَاتِ?
Model answer (teacher only): Fi'l (خَلَقَ - created) + Fa'il (اللَّهُ - Allah) + Maf'ool (السَّمَاوَاتِ - the heavens). This is a Jumlah Fi'liyyah.


## Lesson 3: Masculine (Muzakkar) and Feminine (Muannas)

**Q169** (MCQ)
Question: Which word is MUANNAS (feminine)?
  1. زَیْدٌ
  2. کِتَابٌ
  3. جَنَّۃٌ
  4. قَلَمٌ
Correct answer: جَنَّۃٌ
Hint: Look for the feminine sign

**Q170** (Fill in the blank)
Question: The feminine of مُسْلِم is ___
Correct answer: مُسْلِمَۃٌ
Hint: Add ة at the end

**Q171** (MCQ)
Question: بُشْرَی is feminine because of:
  1. Round ta (ۃ)
  2. Alif Maqsoorah (ی)
  3. Alif Mamdoodah (اء)
  4. No sign — it is masculine
Correct answer: Alif Maqsoorah (ی)

**Q172** (Q&A)
Question: Name the three signs of feminine (Muannas) with one example each.
Model answer (teacher only): 1. Round ta (ۃ): مُسْلِمَۃٌ. 2. Alif Maqsoorah (ی): بُشْرَی. 3. Alif Mamdoodah (اء): حَمْرَاءُ.


## Lesson 4: Sound Plural (Jam' Salim) and Broken Plural (Jam' Mukassar)

**Q173** (MCQ)
Question: مُسْلِمُونَ is which type of plural?
  1. Jam' Salim (sound plural)
  2. Jam' Mukassar (broken plural)
  3. Tasniyah
  4. Mufrad
Correct answer: Jam' Salim (sound plural)

**Q174** (Fill in the blank)
Question: The broken plural of کِتَاب is ___
Correct answer: کُتُب
Hint: Book example: the singular pattern is broken

**Q175** (MCQ)
Question: Which pair shows Jam' Mukassar?
  1. مُسْلِم → مُسْلِمُونَ
  2. مُفْلِح → مُفْلِحُونَ
  3. قَلْب → قُلُوب
  4. کَاتِب → کَاتِبُونَ
Correct answer: قَلْب → قُلُوب

**Q176** (Q&A)
Question: What is the difference between Jam' Salim and Jam' Mukassar?
Model answer (teacher only): In Jam' Salim the singular pattern stays intact (مُسْلِم → مُسْلِمُونَ). In Jam' Mukassar the singular pattern is broken (کِتَاب → کُتُب، قَلْب → قُلُوب).


## Lesson 5: Definite (Ma'rifah) and Indefinite (Nakirah)

**Q177** (MCQ)
Question: Which word is MA'RIFAH (definite)?
  1. کِتَاب
  2. اَلْکِتَاب
  3. قَلَم
  4. بَیْت
Correct answer: اَلْکِتَاب
Hint: Definite = specific

**Q178** (Fill in the blank)
Question: Add ___ at the start of کِتَاب to make it definite
Correct answer: اَلْ
Hint: The definite article

**Q179** (MCQ)
Question: مَکَّۃ is Ma'rifah because it is:
  1. Has ال
  2. A specific place name
  3. A pronoun
  4. A verb
Correct answer: A specific place name

**Q180** (Q&A)
Question: How does a Nakirah become a Ma'rifah? Give an example.
Model answer (teacher only): By adding ال at the beginning: کِتَاب (a book, Nakirah) → اَلْکِتَاب (the book, Ma'rifah).


## Lesson 6: Intensive Noun (Mubalaghah) and Comparative Noun (Tafdeel)

**Q181** (MCQ)
Question: What does اَکْبَر mean?
  1. Big
  2. The biggest / greater
  3. Bigness
  4. To enlarge
Correct answer: The biggest / greater

**Q182** (Fill in the blank)
Question: اَرْحَم means 'more ___ than all the merciful'
Correct answer: merciful
Hint: Book: تمام رحم والوں سے زیادہ رحم کرنے والا

**Q183** (MCQ)
Question: Ism Tafdeel is made on which pattern?
  1. فَاعِل
  2. مَفْعُول
  3. أَفْعَل
  4. فَعِیل
Correct answer: أَفْعَل

**Q184** (Q&A)
Question: What is Ism Tafdeel? Give two book examples.
Model answer (teacher only): A noun showing one thing has more of a quality than another (comparative/superlative), on the pattern أَفْعَل. Examples: اَکْبَر (biggest), اَحْسَن (best/most excellent).


## Lesson 7: Noun of Time/Place (Zarf) and Noun of Instrument (Aalah)

**Q185** (MCQ)
Question: Ism Zarf is a word used for:
  1. An instrument
  2. A place or time
  3. A person
  4. An action
Correct answer: A place or time

**Q186** (Fill in the blank)
Question: Ism ___ is the word used for an instrument
Correct answer: Aalah
Hint: آلہ = tool/instrument

**Q187** (MCQ)
Question: Which is an Ism Aalah?
  1. مَسْجِد (mosque — a place)
  2. مِفْتَاح (key — a tool)
  3. کِتَاب (book)
  4. قَلَم (pen)
Correct answer: مِفْتَاح (key — a tool)
Hint: Think: which is a tool?

**Q188** (Q&A)
Question: Define Ism Zarf and Ism Aalah.
Model answer (teacher only): Ism Zarf: a word used for a place or time (e.g., مَسْجِد — place of prostration). Ism Aalah: a word used for an instrument/tool (e.g., مِفْتَاح — key).


## Lesson 8: Four Types of Object (Maf'ool)

**Q189** (MCQ)
Question: How many types of Maf'ool does the book teach?
  1. Two
  2. Three
  3. Four
  4. Five
Correct answer: Four

**Q190** (Fill in the blank)
Question: Maf'ool ___ is the object on which the action falls (e.g., السَّمَاوَاتِ in خَلَقَ اللَّهُ السَّمَاوَاتِ)
Correct answer: bihi (بہ)
Hint: The direct object

**Q191** (MCQ)
Question: In رَتِّلِ الْقُرْآنَ تَرْتِیلًا, تَرْتِیلًا is:
  1. Maf'ool bihi
  2. Maf'ool feehi
  3. Maf'ool Mutlaq (absolute object for emphasis)
  4. Haal
Correct answer: Maf'ool Mutlaq (absolute object for emphasis)

**Q192** (Q&A)
Question: Name the four types of Maf'ool with their meanings.
Model answer (teacher only): 1. Maf'ool bihi — the thing the action falls on. 2. Maf'ool feehi — the time/place of the action. 3. Maf'ool lahu — the reason for the action. 4. Maf'ool mutlaq — the verbal noun for emphasis (e.g., تَرْتِیلًا).


## Lesson 9: Haal (Circumstantial Accusative)

**Q193** (MCQ)
Question: What does HAAL describe?
  1. The time of action
  2. The state of the doer or the object
  3. The reason for action
  4. The place of action
Correct answer: The state of the doer or the object

**Q194** (Fill in the blank)
Question: In قُومُوا لِلَّهِ قَانِتِینَ, the word قَانِتِینَ is the ___
Correct answer: Haal
Hint: It describes the state: 'obediently'

**Q195** (MCQ)
Question: Haal is usually in which grammatical state?
  1. Raf' (nominative)
  2. Nasb (accusative)
  3. Jarr (genitive)
  4. Jazm
Correct answer: Nasb (accusative)

**Q196** (Q&A)
Question: Define Haal with the book's example.
Model answer (teacher only): Haal is the word that describes the state of the Fa'il or Maf'ool at the time of the action. Example: قُومُوا لِلَّهِ قَانِتِینَ — 'Stand for Allah in a state of obedience'; قَانِتِینَ is the Haal.


## Lesson 10: Tamyeez (Specification)

**Q197** (MCQ)
Question: What does TAMYEEZ do?
  1. Shows time
  2. Removes ambiguity (وضح)
  3. Shows emphasis
  4. Joins sentences
Correct answer: Removes ambiguity (وضح)

**Q198** (Fill in the blank)
Question: In رَأَیْتُ أَحَدَ عَشَرَ کَوْکَبًا, the Tamyeez is ___
Correct answer: کَوْکَبًا
Hint: It clarifies 'eleven what?'

**Q199** (MCQ)
Question: Tamyeez commonly clarifies ambiguity of:
  1. Only verbs
  2. Number, quantity, or manner
  3. Only pronouns
  4. Only prepositions
Correct answer: Number, quantity, or manner

**Q200** (Q&A)
Question: Explain Tamyeez with the book's example رَأَیْتُ أَحَدَ عَشَرَ کَوْکَبًا.
Model answer (teacher only): 'I saw eleven...' — eleven what? The word کَوْکَبًا (stars) removes the ambiguity of the number. Tamyeez clarifies ambiguity of number (عدد), quantity (مقدار), or manner (کیفیت).


## Lesson 11: Near Past (Madi Qareeb with QAD)

**Q201** (MCQ)
Question: What does قَدْ before a past verb mean?
  1. Maybe
  2. Certainly / surely
  3. Never
  4. If
Correct answer: Certainly / surely

**Q202** (Fill in the blank)
Question: قَدْ أَفْلَحَ الْمُؤْمِنُونَ means '___ the believers have succeeded'
Correct answer: Certainly
Hint: Book: یقیناً، ضرور

**Q203** (MCQ)
Question: How many times does قَدْ come in the Quran (per the book)?
  1. 12
  2. 122
  3. 1220
  4. 22
Correct answer: 122

**Q204** (Q&A)
Question: What is Madi Qareeb? Give an example.
Model answer (teacher only): The past tense with قَدْ before it, giving certainty: قَدْ ضَرَبَ = 'he certainly struck'. Example: قَدْ أَفْلَحَ الْمُؤْمِنُونَ — 'Certainly the believers have succeeded'.


## Lesson 12: Continuous Past (Madi Istimrari with KAANA)

**Q205** (MCQ)
Question: کَانَ یَفْعَلُ means:
  1. He will do
  2. He used to do / was doing
  3. He did once
  4. Do!
Correct answer: He used to do / was doing

**Q206** (Fill in the blank)
Question: کَانَ + ___ gives the continuous past meaning
Correct answer: یَفْعَلُ (mudari')
Hint: Kaana + present-tense verb

**Q207** (MCQ)
Question: Which gives 'he was writing'?
  1. قَدْ کَتَبَ
  2. کَانَ یَکْتُبُ
  3. سَیَکْتُبُ
  4. اُکْتُبْ
Correct answer: کَانَ یَکْتُبُ

**Q208** (Q&A)
Question: How is the continuous past (Madi Istimrari) formed?
Model answer (teacher only): By putting کَانَ before the mudari' verb: کَانَ یَفْعَلُ = 'he used to do / was doing'. It describes a repeated or ongoing action in the past.


## Lesson 13: Future Tense (Mudari' with SA / SAWFA)

**Q209** (MCQ)
Question: سَیَفْعَلُ means:
  1. He did
  2. He is doing
  3. He will do (near future)
  4. He would do
Correct answer: He will do (near future)

**Q210** (Fill in the blank)
Question: سَوْفَ is used for the ___ future
Correct answer: distant
Hint: سَ = near, سَوْفَ = far

**Q211** (MCQ)
Question: Which is the near-future marker?
  1. سَ
  2. سَوْفَ
  3. قَدْ
  4. لَنْ
Correct answer: سَ

**Q212** (Q&A)
Question: What is the difference between سَ and سَوْفَ?
Model answer (teacher only): Both make the mudari' future. سَ is for the near future (سَیَفْعَلُ = he will do soon), سَوْفَ for the distant future (سَوْفَ یَفْعَلُ = he will do later).


## Lesson 14: Emphatic Mudari' (Khafeef & Saqeel with NOON)

**Q213** (MCQ)
Question: لَیَفْعَلَنَّ shows:
  1. Past tense
  2. Strong emphasis (he will SURELY do)
  3. Prohibition
  4. Question
Correct answer: Strong emphasis (he will SURELY do)

**Q214** (Fill in the blank)
Question: The heavy noon (نَّ) at the end gives ___ emphasis
Correct answer: strong (saqeel)
Hint: ثقیل = heavy

**Q215** (MCQ)
Question: Khafeef (light) emphasis uses which noon?
  1. نَّ (doubled, heavy)
  2. نْ (single, light)
  3. No noon
  4. Two noons
Correct answer: نْ (single, light)

**Q216** (Q&A)
Question: Explain the emphatic mudari' (Khafeef and Saqeel).
Model answer (teacher only): Adding لَ + ن at the end of the mudari' gives strong emphasis. Khafeef (light): لَیَفْعَلَنْ with single نْ. Saqeel (heavy): لَیَفْعَلَنَّ with doubled نَّ — 'he will surely do'.


## Lesson 15: Intransitive (Lazim) and Transitive (Muta'addi) Verbs

**Q217** (MCQ)
Question: Fi'l Lazim is a verb that:
  1. Needs doer + object
  2. Needs only a doer (Fa'il)
  3. Needs two objects
  4. Has no doer
Correct answer: Needs only a doer (Fa'il)

**Q218** (Fill in the blank)
Question: نَزَلَ (he descended) is Fi'l ___
Correct answer: Lazim
Hint: Book example: needs only a Fa'il

**Q219** (MCQ)
Question: أَنْزَلَ (he sent down) is Muta'addi because:
  1. It has no object
  2. It needs an object too
  3. It is past tense
  4. It is feminine
Correct answer: It needs an object too

**Q220** (Q&A)
Question: Define Fi'l Lazim and Fi'l Muta'addi with examples.
Model answer (teacher only): Lazim: needs only a Fa'il, e.g., نَزَلَ (he descended). Muta'addi: needs Fa'il + Maf'ool, e.g., أَنْزَلَ (he sent down [something]).


## Lesson 16: Deficient Verbs (Af'aal Naqisah — KAANA etc.)

**Q221** (MCQ)
Question: How many Af'aal Naqisah are there (per the book)?
  1. 7
  2. 11
  3. 17
  4. 10
Correct answer: 17

**Q222** (Fill in the blank)
Question: The most famous Naqis verb is ___
Correct answer: کَانَ
Hint: Means 'was'

**Q223** (MCQ)
Question: Why are they called 'Naqisah' (deficient)?
  1. They have no meaning
  2. They need a subject AND a predicate to complete meaning
  3. They are always past
  4. They have no doer
Correct answer: They need a subject AND a predicate to complete meaning

**Q224** (Q&A)
Question: Name five Af'aal Naqisah with meanings.
Model answer (teacher only): کَانَ (was), ظَلَّ (became/remained), بَاتَ (spent the night), أَصْبَحَ (became morning), أَمْسَی (became evening), لَیْسَ (is not). The book says 17 exist, 11 come in the Quran, 1533 times.


## Lesson 17: Verbs of Proximity (Af'aal Muqarabah — KAADA)

**Q225** (MCQ)
Question: کَادَ means:
  1. He did
  2. He was near (to doing)
  3. He hoped
  4. He began
Correct answer: He was near (to doing)

**Q226** (Fill in the blank)
Question: عَسَی gives the meaning of ___
Correct answer: hope (امید ہے)
Hint: Book: امید ہے

**Q227** (MCQ)
Question: How many Af'aal Muqarabah come in the Quran?
  1. 10
  2. 7
  3. 3
  4. 17
Correct answer: 3

**Q228** (Q&A)
Question: What are Af'aal Muqarabah? Name the three in the Quran.
Model answer (teacher only): Verbs showing nearness to an action, hope, or beginning. Three come in the Quran (57 times): کَادَ (he was near), عَسَی (it is hoped), طَفِقَ (he began).


## Lesson 18: Verbs of Praise and Blame (NI'MA, BI'SA)

**Q229** (MCQ)
Question: نِعْمَ is used for:
  1. Blame (ذم)
  2. Praise (مدح)
  3. Hope
  4. Prohibition
Correct answer: Praise (مدح)

**Q230** (Fill in the blank)
Question: بِئْسَ means 'how ___' (used for blame)
Correct answer: evil
Hint: Opposite of نِعْمَ

**Q231** (MCQ)
Question: نِعْمَ الْمَوْلَی وَنِعْمَ النَّصِیرُ means:
  1. How evil the protector
  2. How excellent the Protector and how excellent the Helper
  3. The protector helped
  4. Allah is one
Correct answer: How excellent the Protector and how excellent the Helper

**Q232** (Q&A)
Question: Name the four Af'aal of Madh and Zamm.
Model answer (teacher only): For praise (مدح): نِعْمَ (how excellent). For blame (ذم): بِئْسَ (how evil), سَاءَ (how evil). The book says 4 verbs, coming 79 times in the Quran.


## Lesson 19: Verbs of the Heart (Af'aal Quloob)

**Q233** (MCQ)
Question: Af'aal Quloob are verbs of:
  1. The hands
  2. The heart — certainty and doubt
  3. The feet
  4. The eyes
Correct answer: The heart — certainty and doubt

**Q234** (Fill in the blank)
Question: عَلِمَ (he knew) is a verb of ___
Correct answer: certainty (یقین)
Hint: 484 times in the Quran

**Q235** (MCQ)
Question: Which verb is for DOUBT (شک)?
  1. عَلِمَ
  2. ظَنَّ
  3. وَجَدَ
  4. رَأَی
Correct answer: ظَنَّ

**Q236** (Q&A)
Question: Name the Af'aal Quloob for certainty and doubt.
Model answer (teacher only): Certainty (یقین): عَلِمَ (knew), وَجَدَ (found), رَأَی (saw). Doubt (شک): حَسِبَ (thought), ظَنَّ (assumed). One verb (زَعَمَ) is used for both. 7 verbs, 864 times in the Quran.


## Lesson 20: Quadrilateral Verbs (Fi'l Ruba'i)

**Q237** (MCQ)
Question: A Ruba'i verb has how many root letters?
  1. Three
  2. Four
  3. Five
  4. Two
Correct answer: Four

**Q238** (Fill in the blank)
Question: The pattern of the Ruba'i verb is ___
Correct answer: فَعْلَلَ
Hint: Like فَعَلَ but with 4 letters

**Q239** (MCQ)
Question: Which is a Ruba'i verb?
  1. ضَرَبَ
  2. زَلْزَلَ
  3. کَتَبَ
  4. فَتَحَ
Correct answer: زَلْزَلَ

**Q240** (Q&A)
Question: How many Ruba'i verbs come in the Quran? Name them.
Model answer (teacher only): Five verbs, 13 times: زَحْزَحَ (moved away), عَسْعَسَ (covered), دَمْدَمَ (destroyed), وَسْوَسَ (whispered), زَلْزَلَ (shook). Pattern: فَعْلَلَ.


# Arabic Language

## Madinah 1: Demonstrative Pronouns (هذا، ذلك، هذه، تلك)

**Q241** (MCQ)
Question: What does هَذَا mean?
  1. this (masculine)
  2. that (masculine)
  3. this (feminine)
  4. these
Correct answer: this (masculine)
Hint: Book Lesson 1: مَا هَذَا؟ هَذَا مَسْجِدٌ

**Q242** (MCQ)
Question: In the book: مَا هَذَا؟ هَذَا مَسْجِدٌ. What does هَذَا مَسْجِدٌ mean?
  1. This is a mosque
  2. That is a house
  3. What is this?
  4. This is a book
Correct answer: This is a mosque

**Q243** (Fill in the blank)
Question: Fill in the blank: ___ نَجْمٌ (That is a star).
Correct answer: ذَلِكَ
Hint: Book Lesson 2: مَا ذَلِكَ؟ ذَلِكَ نَجْمٌ

**Q244** (Q&A)
Question: Explain the difference between هَذَا and ذَلِكَ using examples from the book.
Model answer (teacher only): هَذَا means 'this' (near): هَذَا مَسْجِدٌ (this is a mosque). ذَلِكَ means 'that' (far): ذَلِكَ نَجْمٌ (that is a star). The book contrasts them: هَذَا مَسْجِدٌ وَذَلِكَ بَيْتٌ (this is a mosque and that is a house).


## Madinah 1: Personal & Possessive Pronouns (هو، هي، لي، لك...)

**Q245** (MCQ)
Question: أَيْنَ زَيْنَبُ؟ هِيَ فِي الْغُرْفَةِ. Who does هِيَ refer to?
  1. Zainab (she)
  2. The teacher (he)
  3. The students
  4. The room
Correct answer: Zainab (she)

**Q246** (MCQ)
Question: What does هَذَا قَلَمِي mean?
  1. This is my pen
  2. This is your pen
  3. This is his pen
  4. This is her pen
Correct answer: This is my pen
Hint: Book: هَذَا قَلَمِي، هَذَا قَلَمُكَ، هَذَا قَلَمُهُ، هَذَا قَلَمُهَا

**Q247** (Fill in the blank)
Question: Fill in: ___ أَخٌ؟ لَا، مَا لِي أَخٌ (Do YOU have a brother? No, I have no brother).
Correct answer: أَلَكَ
Hint: Book: أَلَكَ أَخٌ؟ لَا، مَا لِي أَخٌ

**Q248** (Q&A)
Question: What do the endings in هَذَا قَلَمِي / قَلَمُكَ / قَلَمُهُ / قَلَمُهَا mean?
Model answer (teacher only): ي = my (قَلَمِي = my pen), كَ = your (masc.) (قَلَمُكَ = your pen), هُ = his (قَلَمُهُ = his pen), هَا = her (قَلَمُهَا = her pen). The book teaches these as attached possessive pronouns.


## Madinah 1: Prepositions (في، على، من، إلى، أمام، خلف)

**Q249** (MCQ)
Question: What does الْقَلَمُ عَلَى الْمَكْتَبِ mean?
  1. The pen is on the desk
  2. The pen is in the bag
  3. The book is on the desk
  4. The pen is under the desk
Correct answer: The pen is on the desk
Hint: Book: مَاذَا عَلَى الْمَكْتَبِ؟

**Q250** (MCQ)
Question: ذَهَبَ حَامِدٌ إِلَى فَرَنْسَا. What does إِلَى mean here?
  1. to
  2. from
  3. in
  4. on
Correct answer: to
Hint: Hamid went TO France

**Q251** (Fill in the blank)
Question: Fill in: آمِنَةُ ___ الْغُرْفَةِ (Amina is IN the room).
Correct answer: فِي
Hint: Book: آمِنَةُ فِي الْغُرْفَةِ

**Q252** (Q&A)
Question: Translate into English: بَيْتُ الْإِمَامِ خَلْفَ الْمَسْجِدِ
Model answer (teacher only): The imam's house is behind the mosque. (خَلْفَ = behind; أَمَامَ = in front of, e.g. السَّبُّورَةُ أَمَامَ الطَّالِبِ — the blackboard is in front of the student.)


## Madinah 1: Nominal Sentences (الجملة الاسمية)

**Q253** (MCQ)
Question: What does الطَّالِبُ مَرِيضٌ mean?
  1. The student is sick
  2. The student is standing
  3. The teacher is sick
  4. The student went
Correct answer: The student is sick
Hint: Book: الطَّالِبُ مَرِيضٌ

**Q254** (MCQ)
Question: Which of these is a nominal sentence from the book?
  1. ذَهَبَ حَامِدٌ
  2. الدُّكَّانُ مَفْتُوحٌ
  3. خَرَجَ مُحَمَّدٌ
  4. أَيْنَ السَّاعَةُ؟
Correct answer: الدُّكَّانُ مَفْتُوحٌ
Hint: A nominal sentence starts with a noun: الدُّكَّانُ مَفْتُوحٌ (the shop is open)

**Q255** (Fill in the blank)
Question: Fill in: ___ حُلْوٌ (The sugar is sweet).
Correct answer: السُّكَّرُ
Hint: Book: السُّكَّرُ حُلْوٌ

**Q256** (Q&A)
Question: What are the two parts of a nominal sentence? Give one example from the book.
Model answer (teacher only): A nominal sentence has a subject (مبتدأ) and a predicate (خبر). Example from the book: الرَّجُلُ وَاقِفٌ — الرَّجُلُ (the man) is the subject, وَاقِفٌ (standing) is the predicate.


## Madinah 1: The Definite Article (ال)

**Q257** (MCQ)
Question: What does adding ال to a noun do?
  1. Makes it definite ("the")
  2. Makes it plural
  3. Makes it feminine
  4. Makes it a verb
Correct answer: Makes it definite ("the")
Hint: بَيْتٌ (a house) → الْبَيْتُ (the house)

**Q258** (MCQ)
Question: بَيْتٌ means 'a house'. What does الْبَيْتُ mean?
  1. the house
  2. a house
  3. houses
  4. my house
Correct answer: the house

**Q259** (Fill in the blank)
Question: Write 'the mosque' in Arabic.
Correct answer: الْمَسْجِدُ
Hint: مَسْجِدٌ → الْمَسْجِدُ

**Q260** (Q&A)
Question: The book writes النَّجْمُ بَعِيدٌ. Break it into ال + noun and translate.
Model answer (teacher only): النَّجْمُ = ال + نَجْم (the star), بَعِيدٌ = far. Full meaning: The star is far.


## Madinah 1: Plurals (الجمع)

**Q261** (MCQ)
Question: What is the plural of طَالِبٌ (student)?
  1. طُلَّابٌ
  2. طَالِبَانِ
  3. طَالِبَةٌ
  4. طَالِبُونَ
Correct answer: طُلَّابٌ
Hint: Book: الطُّلَّابُ فِي الْفَصْلِ (the students are in the classroom)

**Q262** (MCQ)
Question: مَنْ هَؤُلَاءِ الرِّجَالُ؟ هُمْ ضُيُوفٌ. What does هُمْ ضُيُوفٌ mean?
  1. They are guests
  2. They are students
  3. We are guests
  4. They are farmers
Correct answer: They are guests

**Q263** (Fill in the blank)
Question: Fill in the plural: أُمٌّ (mother) → ___ (mothers).
Correct answer: أُمَّهَاتٌ
Hint: Book: أُمٌّ → أُمَّهَاتٌ

**Q264** (Q&A)
Question: Give three broken plurals from the book with their singular forms.
Model answer (teacher only): طَالِبٌ → طُلَّابٌ (students), بَيْتٌ → بُيُوتٌ (houses), قَلَمٌ → أَقْلَامٌ (pens). Also: بَابٌ → أَبْوَابٌ, نَجْمٌ → نُجُومٌ, أَخٌ → إِخْوَةٌ.


## Madinah 1: Numbers (الأعداد)

**Q265** (MCQ)
Question: What does ثَلَاثُ طَالِبَاتٍ mean?
  1. three students (female)
  2. three students (male)
  3. thirty students
  4. the third student
Correct answer: three students (female)
Hint: Book: ثَلَاثُ طَالِبَاتٍ، أَرْبَعُ طَالِبَاتٍ، خَمْسُ طَالِبَاتٍ...

**Q266** (MCQ)
Question: لِي خَمْسَةُ إِخْوَةٍ وَسِتُّ أَخَوَاتٍ. What does it mean?
  1. I have five brothers and six sisters
  2. I have six brothers and five sisters
  3. He has five brothers
  4. My brother has six sisters
Correct answer: I have five brothers and six sisters

**Q267** (Fill in the blank)
Question: Fill in: فِي بَيْتِنَا ___ غُرَفٍ (In our house there are THREE rooms).
Correct answer: ثَلَاثُ
Hint: Book: فِي بَيْتِنَا ثَلَاثُ غُرَفٍ

**Q268** (Q&A)
Question: The book writes لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ وَأَرْبَعُ بَنَاتٍ. Why ثَلَاثَةُ for sons but أَرْبَعُ for daughters?
Model answer (teacher only): In Arabic, the numbers 3–10 take the OPPOSITE gender of the counted noun: أَبْنَاء (sons, masculine) → ثَلَاثَةُ (feminine form), بَنَات (daughters, feminine) → أَرْبَعُ (masculine form). Meaning: Khalid has three sons and four daughters.


## Madinah 1: Adjectives (الصفة)

**Q269** (MCQ)
Question: الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ. What does it mean?
  1. The doctor is tall and the teacher is short
  2. The doctor is short and the teacher is tall
  3. The doctor is sick
  4. The teacher is tall
Correct answer: The doctor is tall and the teacher is short

**Q270** (MCQ)
Question: Which word means 'new'?
  1. جَدِيدٌ
  2. قَدِيمٌ
  3. كَبِيرٌ
  4. جَمِيلٌ
Correct answer: جَدِيدٌ
Hint: Book: الدَّفْتَرُ جَدِيدٌ (the notebook is new), هَذَا طَالِبٌ جَدِيدٌ

**Q271** (Fill in the blank)
Question: Fill in: السِّكِّينُ الْكَبِيرُ ___ جِدًّا (The big knife is very sharp).
Correct answer: حَادٌّ
Hint: Book: السِّكِّينُ الْكَبِيرُ حَادٌّ جِدًّا

**Q272** (Q&A)
Question: In هَذَا طَالِبٌ جَدِيدٌ, why does جَدِيدٌ have no ال?
Model answer (teacher only): The adjective matches the noun in definiteness: طَالِبٌ is indefinite (a student), so the adjective is also indefinite: جَدِيدٌ (new). Compare الطَّالِبُ الْجَدِيدُ (the new student) where both have ال.


## Madinah 1: Past Tense Verbs (الفعل الماضي)

**Q273** (MCQ)
Question: خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ. What does it mean?
  1. Muhammad left the house
  2. Muhammad entered the house
  3. Amina left the house
  4. Muhammad is leaving
Correct answer: Muhammad left the house
Hint: Book: خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ

**Q274** (MCQ)
Question: What is the feminine form of ذَهَبَ (he went)?
  1. ذَهَبَتْ
  2. ذَهَبُوا
  3. ذَهَبْتَ
  4. يَذْهَبُ
Correct answer: ذَهَبَتْ
Hint: Book: خَرَجَتْ آمِنَةُ مِنَ الْبَيْتِ (Amina left the house)

**Q275** (Fill in the blank)
Question: Fill in: أَنْتَ ___ إِلَى الْمَدْرَسَةِ (YOU went to the school).
Correct answer: ذَهَبْتَ
Hint: Book: أَنْتَ ذَهَبْتَ إِلَى الْمَدْرَسَةِ

**Q276** (Q&A)
Question: Conjugate خَرَجَ (to leave) for 'he' and 'she' with the book's example sentences.
Model answer (teacher only): He: خَرَجَ — خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ (Muhammad left the house). She: خَرَجَتْ — خَرَجَتْ آمِنَةُ مِنَ الْبَيْتِ (Amina left the house). The ة/ت marks the feminine.


## Madinah 1: Conjunctions (حروف العطف)

**Q277** (MCQ)
Question: In الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ, what does وَ mean?
  1. and
  2. or
  3. but
  4. then
Correct answer: and
Hint: Book: الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ

**Q278** (MCQ)
Question: الْفَلَّاحُونَ فِي الْحُقُولِ وَأَبْنَاؤُهُمْ فِي الْمَدْرَسَةِ. What does it mean?
  1. The farmers are in the fields and their sons are in the school
  2. The farmers and their sons are in the fields
  3. The farmers went to the school
  4. The sons are farmers
Correct answer: The farmers are in the fields and their sons are in the school

**Q279** (Fill in the blank)
Question: Fill in: لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ ___ أَرْبَعُ بَنَاتٍ (Khalid has three sons AND four daughters).
Correct answer: وَ
Hint: Book: لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ وَأَرْبَعُ بَنَاتٍ

**Q280** (Q&A)
Question: How is وَ attached to the following word in the book's examples?
Model answer (teacher only): وَ is written attached to the next word with no space: وَالْمُدَرِّسُ, وَأَبْنَاؤُهُمْ, وَأَرْبَعُ. It means 'and' and joins two sentences or phrases, e.g. فِي الْمُسْتَشْفَى عَشْرُ طَبِيبَاتٍ وَأَرْبَعُ مُمَرِّضَاتٍ (in the hospital are ten female doctors and four nurses).


## Qasas 1: Ibrahim (AS) — Smashing the Idols

**Q281** (MCQ)
Question: In the book, what was Azar's (آزر) famous profession?
  1. He sold idols (بائع الأصنام)
  2. He built houses
  3. He was a shepherd
  4. He taught children
Correct answer: He sold idols (بائع الأصنام)
Hint: Book section 1: بائع الأصنام

**Q282** (Fill in the blank)
Question: Fill in the blank: Ibrahim knew the idols were only ______ (حجارة) — they cannot speak or hear.
Correct answer: stones
Hint: The book repeats: الأصنام حجارة

**Q283** (MCQ)
Question: On the Eid day, what excuse did Ibrahim give to stay behind while everyone left?
  1. He said: 'I am sick' (أنا سقيم)
  2. He said he was travelling
  3. He hid in the well
  4. He went to the market
Correct answer: He said: 'I am sick' (أنا سقيم)
Hint: Book section 4: إبراهيم يكسر الأصنام

**Q284** (Q&A)
Question: When the people asked Ibrahim 'Did you do this to our gods?', what clever answer did he give (from the book)?
Model answer (teacher only): He said: 'Rather the biggest one did it — ask them, if they can speak!' (بل فعله كبيرهم هذا فاسألوهم إن كانوا ينطقون). He had left the biggest idol unbroken and hung the axe (الفأس) on its neck.
Hint: Book section 5: من فعل هذا؟


## Qasas 1: Ibrahim (AS) — The Cool Fire and Finding Allah

**Q285** (MCQ)
Question: What punishment did the people choose for Ibrahim after he broke the idols?
  1. 'Forgive him'
  2. 'Burn him and help your gods!' (حرقوه وانصروا آلهتكم)
  3. 'Send him to Egypt'
  4. 'Make him king'
Correct answer: 'Burn him and help your gods!' (حرقوه وانصروا آلهتكم)
Hint: Book section 6: نار باردة

**Q286** (Fill in the blank)
Question: Fill in the blank: Allah commanded the fire: 'O fire, be cool and ______ upon Ibrahim' (برداً وسلاماً).
Correct answer: safe
Hint: Book: يا نار كوني برداً وسلاماً على إبراهيم

**Q287** (MCQ)
Question: Ibrahim looked at the star, the moon and the sun, then rejected each as his lord. Why?
  1. They were too small
  2. Each one sets/disappears — but Allah is Living and never dies (حي لا يموت), Everlasting and never disappears (باق لا يغيب)
  3. He could not see them clearly
  4. His father told him to
Correct answer: Each one sets/disappears — but Allah is Living and never dies (حي لا يموت), Everlasting and never disappears (باق لا يغيب)
Hint: Book section 7: من ربي

**Q288** (Q&A)
Question: According to the book, why can't the star, moon or sun help Ibrahim?
Model answer (teacher only): Because each is weak (ضعيف): the morning overcomes the star, the sun overcomes the moon, and the night and clouds overcome the sun. Only Allah helps him, for Allah is Living (لا يموت), Everlasting (لا يغيب) and Strong — nothing overcomes Him (لا يغلبه شيء).


## Qasas 1: Ibrahim (AS) — The Call, Makkah and the Kaaba

**Q289** (MCQ)
Question: When Ibrahim asked his people 'What do you worship?' and they said 'idols', what was their only reason?
  1. 'The idols speak to us'
  2. 'We found our fathers doing so' (بل وجدنا آباءنا كذلك يفعلون)
  3. 'The king ordered us'
  4. 'They give us food'
Correct answer: 'We found our fathers doing so' (بل وجدنا آباءنا كذلك يفعلون)
Hint: Book section 9: دعوة إبراهيم

**Q290** (Fill in the blank)
Question: Fill in the blank: Ibrahim silenced the king by saying: 'Allah brings the sun from the east — bring it from the ______!'
Correct answer: west
Hint: Book: فأت بها من المغرب

**Q291** (MCQ)
Question: In Makkah, Hajar ran between which two hills searching for water?
  1. Safa and Marwa (الصفا والمروة)
  2. Arafat and Mina
  3. Uhud and Badr
  4. Taur and Hira
Correct answer: Safa and Marwa (الصفا والمروة)
Hint: Book section 13: بئر زمزم

**Q292** (Q&A)
Question: What did Ismail (عليه السلام) reply when Ibrahim told him about the dream of sacrifice?
Model answer (teacher only): He said: 'O my father, do what you are commanded — you will find me, if Allah wills, among the patient.' (يا أبت افعل ما تؤمر ستجدني إن شاء الله من الصابرين). Allah then sent a ram (كبش) from Paradise instead, and commanded the sacrifice on Eid al-Adha.


## Qasas 1: Yusuf (AS) — The Dream and the Well

**Q293** (MCQ)
Question: What did Yusuf see in his strange dream (الرؤيا العجيبة)?
  1. Eleven stars, the sun and the moon prostrating to him
  2. Seven fat cows eating seven lean cows
  3. A big fire in the desert
  4. Birds carrying bread
Correct answer: Eleven stars, the sun and the moon prostrating to him
Hint: Book: رأى أحد عشر كوكباً والشمس والقمر كل يسجد له

**Q294** (Fill in the blank)
Question: Fill in the blank: Yaqub warned Yusuf: 'Do not tell your dream to your brothers — they will ______ you.' (يحسدونك)
Correct answer: envy
Hint: Book: فإنهم يحسدونك ويكونون لك عدواً

**Q295** (MCQ)
Question: What excuse did the brothers give Yaqub for taking Yusuf with them?
  1. 'We want him to work in the fields'
  2. 'Send him with us tomorrow to enjoy and play — we will guard him' (أرسله معنا غداً يرتع ويلعب وإنا له لحافظون)
  3. 'The king invited him'
  4. 'He wants to travel to Egypt'
Correct answer: 'Send him with us tomorrow to enjoy and play — we will guard him' (أرسله معنا غداً يرتع ويلعب وإنا له لحافظون)
Hint: Book section 3: وفد إلى يعقوب

**Q296** (Q&A)
Question: How did Yaqub (عليه السلام) know the 'wolf ate Yusuf' story was a lie?
Model answer (teacher only): He knew that if a wolf eats a man, it tears him and rips his shirt — but Yusuf's shirt (قميص) was intact (سالماً), only stained with false blood (دم كذب). So he said: 'This is a story you made up — beautiful patience!' (فصبر جميل).


## Qasas 1: Yusuf (AS) — From Prison to the Throne

**Q297** (MCQ)
Question: When the Aziz's wife tried to seduce him, what did Yusuf say?
  1. 'I agree, but keep it secret'
  2. 'No! I will not betray my master — he treated me well. I fear Allah.' (إني أخاف الله)
  3. 'Let me think about it'
  4. 'I will tell the king'
Correct answer: 'No! I will not betray my master — he treated me well. I fear Allah.' (إني أخاف الله)
Hint: Book section 8: الوفاء والأمانة

**Q298** (Fill in the blank)
Question: Fill in the blank: In prison Yusuf preached Tawhid: 'Are many different lords better, or Allah, the One, the ______?' (الواحد القهار)
Correct answer: Irresistible
Hint: Book: أأرباب متفرقون خير أم الله الواحد القهار

**Q299** (MCQ)
Question: What position did Yusuf request from the king, and why?
  1. To be the army commander
  2. 'Put me over the storehouses of the land — I am a knowing guardian' (اجعلني على خزائن الأرض إني حفيظ عليم) — because rulers wasted the storehouses while people starved
  3. To be the king's cupbearer
  4. To return to Canaan immediately
Correct answer: 'Put me over the storehouses of the land — I am a knowing guardian' (اجعلني على خزائن الأرض إني حفيظ عليم) — because rulers wasted the storehouses while people starved
Hint: Book section 16: على خزائن الأرض

**Q300** (Q&A)
Question: How did Yusuf finally reveal himself to his brothers, and what did he say to forgive them?
Model answer (teacher only): When they came a third time complaining of poverty, he could not control himself and said: 'Do you know what you did to Yusuf and his brother when you were ignorant?' (هل علمتم ما فعلتم بيوسف وأخيه إذ أنتم جاهلون). They realised he was Yusuf. He forgave them saying: 'May Allah forgive you — He is the most merciful.' (يغفر الله لكم وهو أرحم الراحمين). His dream then came true when his parents and brothers prostrated to him.


## Madinah 2: The Present Tense Verb (الفعل المضارع)

**Q301** (MCQ)
Question: What does «يَذْهَبُ» mean?
  1. He went
  2. He goes / he is going
  3. Go!
  4. He did not go
Correct answer: He goes / he is going
Hint: From the book's conjugation tables

**Q302** (Fill in the blank)
Question: Complete the sentence: هُمْ ___ (they go).
Correct answer: يَذْهَبُونَ
Hint: Look at the book's table: هم يذهبون

**Q303** (MCQ)
Question: In «لَمْ يَذْهَبْ» (he did not go), what is the sign of jazm?
  1. Fatha on the last letter
  2. Sukoon on the last letter
  3. Damma on the last letter
  4. Dropping the noon
Correct answer: Sukoon on the last letter
Hint: Book: علامة الجزم السكون

**Q304** (Q&A)
Question: What is the difference between «لَمْ يَفْعَلْ» and «لَنْ يَفْعَلَ»? Give the book's examples.
Model answer (teacher only): «لَمْ يَفْعَلْ» = he did not do (past negation), e.g. لَمْ يَذْهَبْ. «لَنْ يَفْعَلَ» = he will never do (future emphatic negation), e.g. إِنِّي لَنْ أَذْهَبَ إِلى الهِنْدِ (I will never go to India) from Lesson 19.


## Madinah 2: Command and Prohibition (الأمر والنهي)

**Q305** (MCQ)
Question: What is the command form of «يَكْتُبُ» (he writes)?
  1. يَكْتُبُ
  2. اُكْتُبْ
  3. كَتَبَ
  4. كِتَاب
Correct answer: اُكْتُبْ
Hint: Book: أنت تكتب ← اكتب

**Q306** (Fill in the blank)
Question: Complete: ___ هُنا يا بِلالُ (Sit here, Bilal).
Correct answer: اِجْلِسْ
Hint: From the book: اجلس هنا يا بلال

**Q307** (MCQ)
Question: What does «يا أَحْمَدُ لا تَذْهَبْ» mean?
  1. O Ahmad, go
  2. O Ahmad, do not go
  3. Ahmad went
  4. Ahmad will go
Correct answer: O Ahmad, do not go
Hint: لا الناهية = prohibition

**Q308** (Q&A)
Question: How is the prohibition (النهي) formed in the book? Give two examples.
Model answer (teacher only): Prohibition is formed with لا الناهية + present tense: e.g. لا تَدْخُلْ (do not enter), لا تَسْمَعْ (do not listen). From the book: يا أحمد لا تذهب (O Ahmad, don't go).


## Madinah 2: The Direct Object (المفعول به)

**Q309** (MCQ)
Question: In «رَأَيْتُ حامِدًا» (I saw Hamid), what is «حامِدًا»?
  1. Subject (marfoo)
  2. Direct object (mansoob)
  3. Possessive (majroor)
  4. Adjective
Correct answer: Direct object (mansoob)
Hint: Book: اجعل كلّا من الكلمات الآتية مفعولا به

**Q310** (Fill in the blank)
Question: Complete the answer: أَرَأَيْتَ زَيْنَبَ؟ نَعَمْ، ___ (Yes, I saw her).
Correct answer: رَأَيْتُها
Hint: Book: نعم، رأيتُها

**Q311** (MCQ)
Question: What does «نَعَمْ، رَأَيْتُهُمْ» mean?
  1. Yes, I saw him
  2. Yes, I saw her
  3. Yes, I saw them
  4. No, I did not see them
Correct answer: Yes, I saw them
Hint: Book exercise: أرأيت حامدا وهشاما وعليا؟ نعم، رأيتُهم

**Q312** (Q&A)
Question: What is المفعول به (the direct object)? Give an example from the book.
Model answer (teacher only): المفعول به is the object on which the action falls; it is mansoob (accusative). Example from the book: كَتَبَ المُدَرِّسُ الدَّرْسَ عَلَى السَّبُّورَةِ (The teacher wrote the lesson on the board) — الدَّرْسَ is the direct object.


## Madinah 2: Adverbs of Time and Place (الظرف)

**Q313** (MCQ)
Question: What does «مُبَكِّرًا» mean?
  1. Late
  2. Early
  3. Always
  4. Quickly
Correct answer: Early
Hint: Opposite: مُتَأَخِّرًا (late)

**Q314** (Fill in the blank)
Question: Complete: ذَهَبْتُ إِلَى المَدْرَسَةِ اليَوْمَ ___ وَرَجَعْتُ إِلَى البَيْتِ مُتَأَخِّرًا (I went to school early today and returned home late).
Correct answer: مُبَكِّرًا
Hint: Book: ذهبت إلى المدرسة اليوم مبكرا

**Q315** (MCQ)
Question: What does «هُوَ غائِبٌ مُنْذُ أُسْبُوعٍ» mean?
  1. He was absent a week ago
  2. He has been absent for a week
  3. He will be absent for a week
  4. He is absent every week
Correct answer: He has been absent for a week
Hint: Book: منذ = since/for

**Q316** (Q&A)
Question: Explain the use of «مُنْذُ» with an example from the book.
Model answer (teacher only): مُنْذُ means 'since' or 'for' (duration). Example from the book: نَسْكُنُ فِي هٰذَا البَيْتِ مُنْذُ سَنَةٍ (We have lived in this house for a year).


## Madinah 2: The Circumstantial Clause (الحال)

**Q317** (MCQ)
Question: In «جاءَ الطَّالِبُ راكِبًا» (The student came riding), what is «راكِبًا»?
  1. Subject
  2. Haal (circumstantial clause, mansoob)
  3. Direct object
  4. Adjective of الطالب
Correct answer: Haal (circumstantial clause, mansoob)
Hint: الحال describes the state of the subject during the action

**Q318** (Fill in the blank)
Question: Complete: خَرَجَ المُدِيرُ ___ (The director went out smiling).
Correct answer: مُبْتَسِمًا
Hint: The haal is mansoob

**Q319** (MCQ)
Question: What is the case (إعراب) of the الحال?
  1. Marfoo
  2. Mansoob (accusative)
  3. Majroor
  4. Majzoom
Correct answer: Mansoob (accusative)
Hint: الحال is always mansoob

**Q320** (Q&A)
Question: What is الحال? Give an example and explain its case.
Model answer (teacher only): الحال is a word describing the state of the subject or object during the action, and it is always mansoob. Example: جاءَ الطَّالِبُ راكِبًا (The student came riding) — راكِبًا is the haal.


## Madinah 2: Adjectives (النعت)

**Q321** (MCQ)
Question: In «القَمِيصُ الأَصْفَرُ» (the yellow shirt), what is «الأَصْفَرُ»?
  1. The subject
  2. An adjective (نعت) describing the shirt
  3. The direct object
  4. A possessive
Correct answer: An adjective (نعت) describing the shirt
Hint: Book: اسأل ذاك الرجلَ القميصَ الأصفرَ

**Q322** (Fill in the blank)
Question: Complete: هٰذا بَيْتٌ ___ (This is a beautiful house).
Correct answer: جَمِيلٌ
Hint: The adjective matches the noun

**Q323** (MCQ)
Question: What does «صُوَرٌ مُلَوَّنَةٌ» mean?
  1. Beautiful pictures
  2. Colored pictures
  3. Big pictures
  4. Old pictures
Correct answer: Colored pictures
Hint: Book: عندي معجمٌ صورٌ ملونةٌ

**Q324** (Q&A)
Question: What is the rule of النعت (adjective)? Give a book example.
Model answer (teacher only): النعت follows and matches the described noun (المنعوت) in definiteness, gender, number and case. Example from the book: القَمِيصُ الأَصْفَرُ (the yellow shirt) — both definite, masculine, singular, marfoo.


## Madinah 2: Possessive Construction (الإضافة)

**Q325** (MCQ)
Question: In «أَبْناءُ المُدَرِّسِ» (the teacher's sons), what is the case of «المُدَرِّسِ»?
  1. Marfoo
  2. Mansoob
  3. Majroor (genitive)
  4. Majzoom
Correct answer: Majroor (genitive)
Hint: The second part of idafa (المضاف إليه) is always majroor

**Q326** (Fill in the blank)
Question: Complete: ___ المُهَنْدِسِينَ (the engineers' houses).
Correct answer: بُيُوتُ
Hint: Book: بيوت المهندسين

**Q327** (MCQ)
Question: What does «دِينُ الكافِرِينَ» mean?
  1. The disbelievers' religion book
  2. The religion of the disbelievers
  3. The religious disbelievers
  4. A disbeliever's religion (singular)
Correct answer: The religion of the disbelievers
Hint: Book exercise on idafa

**Q328** (Q&A)
Question: Explain الإضافة (possessive construction) with a book example.
Model answer (teacher only): الإضافة joins two nouns: the first (المضاف) loses tanween, the second (المضاف إليه) is majroor. Example from the book: أَبْناءُ المُدَرِّسِ (the teacher's sons).


## Madinah 2: Compound Numbers (الأعداد المركبة)

**Q329** (MCQ)
Question: In «جاءَ اليَوْمَ ٢٢ طالِبًا جَدِيدًا» (22 new students came today), why is «طالِبًا» mansoob?
  1. It is the subject
  2. It is تمييز (specification) after the number
  3. It is the direct object
  4. It is an adjective
Correct answer: It is تمييز (specification) after the number
Hint: Numbers 11-99 take a mansoob tamyeez

**Q330** (Fill in the blank)
Question: Complete in Arabic words: فِي هٰذَا الكِتابِ ___ دَرْسًا (In this book are 21 lessons).
Correct answer: أَحَدٌ وَعِشْرُونَ
Hint: Book: في هذا الكتاب ٢١ درسا

**Q331** (MCQ)
Question: What does «هٰذَا المَلْعَبُ طُولُهُ ٢٨ مِتْرًا» mean?
  1. This playground is 28 years old
  2. This playground's length is 28 meters
  3. This playground costs 28 meters
  4. 28 playgrounds
Correct answer: This playground's length is 28 meters
Hint: Book: هذا الملعب طوله ٢٨ مترا وعرضه ٢٤ مترا

**Q332** (Q&A)
Question: Explain the rule of تمييز with numbers 11-99, with a book example.
Model answer (teacher only): Numbers 11 to 99 are followed by a singular mansoob noun called تمييز (specification). Example from the book: جاءَ اليَوْمَ ٢٢ طالِبًا جَدِيدًا (22 new students came today) — طالِبًا is the tamyeez.


## Madinah 2: Inna and Its Sisters (إنَّ وأخواتها)

**Q333** (MCQ)
Question: In «إِنَّكَ طالِبٌ ذَكِيٌّ» (Indeed you are a clever student), what did «إِنَّ» do to the pronoun?
  1. Made it marfoo
  2. Made it mansoob (إِنَّكَ)
  3. Made it majroor
  4. Nothing
Correct answer: Made it mansoob (إِنَّكَ)
Hint: From Lesson 1 dialogue: إنك طالب ذكي ومجتهد

**Q334** (Fill in the blank)
Question: Complete: ___ اللّٰهَ رَبِّي (Indeed, Allah is my Lord).
Correct answer: إِنَّ
Hint: Book: إن الله ربي

**Q335** (MCQ)
Question: What does «أَظُنُّ أَنَّكَ مِنْ باكِسْتانَ» mean?
  1. I know you are from Pakistan
  2. I think that you are from Pakistan
  3. You are from Pakistan, I swear
  4. Are you from Pakistan?
Correct answer: I think that you are from Pakistan
Hint: Book: أظن أنك من باكستان

**Q336** (Q&A)
Question: List إِنَّ and its sisters with their meanings.
Model answer (teacher only): إِنَّ (indeed/verily), أَنَّ (that), كَأَنَّ (as if), لٰكِنَّ (but), لَيْتَ (if only/would that), لَعَلَّ (hopefully/perhaps). Example from the book: كَيْفَ حالُكَ يا أُسْتاذُ؟ لَعَلَّكَ بِخَيْرٍ (How are you, teacher? Hopefully you are well).


## Madinah 2: Dialogue Practice (المحادثة)

**Q337** (MCQ)
Question: In the book's first dialogue, where is Hashim from?
  1. Pakistan
  2. India (الهِنْد)
  3. Japan
  4. Bangladesh
Correct answer: India (الهِنْد)
Hint: هاشم: إني من الهند

**Q338** (Fill in the blank)
Question: Complete the teacher's greeting: كَيْفَ حالُكَ يا أُسْتاذُ؟ لَعَلَّكَ ___ (Hopefully you are well).
Correct answer: بِخَيْرٍ
Hint: From الدرس الأول

**Q339** (MCQ)
Question: In Lesson 19, why won't Ayyub go to India in the summer vacation?
  1. He is sick
  2. He wants to go to Baghdad to visit his uncle
  3. He has exams
  4. He has no money
Correct answer: He wants to go to Baghdad to visit his uncle
Hint: أريد أن أذهب إلى بغداد لأزور خالي

**Q340** (Q&A)
Question: In Lesson 19, what do Ayyub's brothers and sisters plan to do in the vacation?
Model answer (teacher only): His brothers will stay in Madinah to memorize the Quran (يُرِيدُونَ أَنْ يَبْقَوْا بِالمَدِينَةِ لِيَحْفَظُوا القُرْآنَ الكَرِيمَ). His sisters will go to Makkah for Umrah, stay a month with their aunt, then go to Riyadh to visit their paternal aunt.


## Qasas 2: Nuh (AS) — The Call to His People

**Q341** (MCQ)
Question: According to the book, how did idol worship begin among Nuh's people?
  1. People always worshipped idols
  2. Satan suggested making images of righteous men, which later became idols
  3. Nuh himself told them to make idols
  4. The idols fell from the sky
Correct answer: Satan suggested making images of righteous men, which later became idols
Hint: Read the sections حسد الشيطان and فكرة الشيطان

**Q342** (fill)
Question: Fill in the blank: Allah sent Nuh as a messenger to his ___ (people).
Correct answer: people
Hint: The book says: أن يُرسل نوحًا إلى قومه

**Q343** (MCQ)
Question: What did Nuh call his people to?
  1. To worship Allah alone
  2. To build more idols
  3. To leave their city
  4. To fight the neighboring tribe
Correct answer: To worship Allah alone

**Q344** (Q&A)
Question: The book says there were rich and leading men among Nuh's people, yet Allah chose Nuh. What does this teach?
Model answer (teacher only): Allah chooses whom He wills for His message — not the richest or most powerful. The book says: كان في القوم أغنياء ورؤساء، ولكن الله اختار نوحًا لرسالته (there were rich men and leaders, but Allah chose Nuh for His message).


## Qasas 2: Nuh (AS) — The Ark and the Flood

**Q345** (MCQ)
Question: What did Allah command Nuh to take with him into the Ark (السفينة)?
  1. Only his family
  2. The believers, his family, and a male-and-female pair of every animal and bird
  3. Gold and treasure
  4. Only the animals
Correct answer: The believers, his family, and a male-and-female pair of every animal and bird

**Q346** (fill)
Question: Fill in the blank: After the Flood, the Ark rested on Mount ___ .
Correct answer: Judi
Hint: واستوت السفينة على جبل الجودي

**Q347** (MCQ)
Question: The book says the Ark sailed “in waves like ___ ”.
  1. mountains
  2. hills
  3. clouds
  4. rivers
Correct answer: mountains
Hint: في موج كالجبال

**Q348** (Q&A)
Question: What dua did Nuh make after the Flood, as quoted in the book?
Model answer (teacher only): Model answer: رب إني أعوذ بك أن أسألك ما ليس لي به علم وإلا تغفر لي وترحمني أكن من الخاسرين — “My Lord, I seek refuge in You from asking You about what I have no knowledge of; if You do not forgive me and have mercy on me, I will be among the losers.”


## Qasas 2: Hud (AS) — The People of ‘Ad

**Q349** (MCQ)
Question: To which people was Hud (AS) sent?
  1. Thamud (ثمود)
  2. ‘Ad (عاد)
  3. Madyan (مدين)
  4. Banu Isra’il
Correct answer: ‘Ad (عاد)

**Q350** (fill)
Question: Fill in the blank: Hud said to his people, “I am your ___ and your friend.”
Correct answer: brother
Hint: يا قوم أنا أخوكم وصديقكم

**Q351** (MCQ)
Question: How did the people of ‘Ad look after their punishment, according to the book?
  1. Like fallen palm trunks; birds ate the dead and owls lived in the ruined houses
  2. They turned into stone statues
  3. They were swallowed by the sea
  4. They simply disappeared
Correct answer: Like fallen palm trunks; birds ate the dead and owls lived in the ruined houses

**Q352** (Q&A)
Question: What did Hud say when his people accused him of wanting their wealth?
Model answer (teacher only): Model answer: يا قوم لا أسألكم عليه مالًا إن أجري إلا على الله — “O my people, I do not ask you for any wealth for this; my reward is only from Allah.” He also promised that belief would bring blessing in provision and strength.


## Qasas 2: Salih (AS) — The People of Thamud

**Q353** (MCQ)
Question: What did Salih remind his people about their palaces, gardens and rivers?
  1. They will not last forever — their forefathers died though they had palaces too
  2. They should build even bigger palaces
  3. The gardens belong to him
  4. They should worship the rivers
Correct answer: They will not last forever — their forefathers died though they had palaces too

**Q354** (fill)
Question: Fill in the blank: The people of Thamud killed the ___ (she-camel), the sign of Salih.
Correct answer: she-camel
Hint: الناقة

**Q355** (MCQ)
Question: How did Salih call his people to Allah, according to the book?
  1. With wisdom and gentleness
  2. With harsh threats only
  3. With an army
  4. He did not call them at all
Correct answer: With wisdom and gentleness
Hint: بحكمة ورفق

**Q356** (Q&A)
Question: Salih asked his people several “Do you think...?” questions. Mention two of them.
Model answer (teacher only): Model answer: أتظنون أنكم هنا إلى الأبد؟ (“Do you think you are here forever?”) and أتظنون أنكم تسكنون في هذه القصور دائمًا؟ (“Do you think you will live in these palaces forever?”) — also about gardens, rivers, crops, and houses carved from mountains.


## Qasas 2: Review — Nuh, Hud and Salih

**Q357** (MCQ)
Question: Which three prophets’ stories are told in Qasas al-Nabiyyin Part 2?
  1. Nuh, Hud and Salih
  2. Yusuf, Musa and Shuayb
  3. Ibrahim, Isma‘il and Ishaq
  4. Adam, Idris and Nuh
Correct answer: Nuh, Hud and Salih

**Q358** (fill)
Question: Fill in the blank (Quranic verse quoted in the book): “ألا إن عادًا كفروا ربهم، ألا بعدًا لعاد قوم ___”
Correct answer: Hud
Hint: The people of ‘Ad — قوم هود

**Q359** (MCQ)
Question: Where did the disbelievers try to escape when the Flood came?
  1. They climbed every high place and hill
  2. They hid in caves
  3. They built another ark
  4. They fled to Egypt
Correct answer: They climbed every high place and hill

**Q360** (Q&A)
Question: What is the common lesson from the stories of Nuh, Hud and Salih in this book?
Model answer (teacher only): Model answer: In each story, the prophet called his people to worship Allah alone with wisdom and gentleness; those who believed were saved, and those who persisted in disbelief and arrogance perished — ونجا ... بإيمانهم، وهلكت ... بكفرها (saved by their faith, destroyed by their disbelief).


## Madinah 3: The Five Verbs (الأفعال الخمسة)

**Q361** (MCQ)
Question: In the five verbs (الأفعال الخمسة), what is the sign of raf' (nominative)?
  1. The nūn is retained (ثبوت النون)
  2. The nūn is dropped (حذف النون)
  3. A ḍammah appears
  4. A fatḥah appears
Correct answer: The nūn is retained (ثبوت النون)
Hint: Book: علامة الرفع فيها ثبوت النون

**Q362** (Fill in the blank)
Question: Complete the book's example: أَتُرِيدُونَ أَنْ ___؟ (Do you all want to go?)
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 1
  9. 8
  10. :
  11.  
  12. أ
  13. ن
  14.  
  15. +
  16.  
  17. f
  18. i
  19. v
  20. e
  21. -
  22. v
  23. e
  24. r
  25. b
  26.  
  27. →
  28.  
  29. n
  30. ū
  31. n
  32.  
  33. d
  34. r
  35. o
  36. p
  37. p
  38. e
  39. d
Correct answer: تَذْهَبُوا

**Q363** (MCQ)
Question: In the book's example «أَمْ تَذْهَبْنَ إِلَى الْمَدْرَسَةِ يَا مَرْيَمُ؟», why is the nūn kept in تَذْهَبْنَ?
  1. It is the feminine plural nūn (نُون النسوة), not the inflectional nūn
  2. Because it is marfū'
  3. Because of أم
  4. It is a mistake in the book
Correct answer: It is the feminine plural nūn (نُون النسوة), not the inflectional nūn

**Q364** (Q&A)
Question: What are the five verbs (الأفعال الخمسة), and what are their signs of inflection?
Model answer (teacher only): The five verbs are the present-tense forms attached to: ألف الاثنين (e.g. يَذْهَبَانِ)، واو الجماعة (يَذْهَبُونَ)، ياء المخاطبة (تَذْهَبِينَ). Sign of raf': retention of nūn (ثبوت النون). Signs of naṣb and jazm: dropping the nūn (حذف النون).


## Madinah 3: Inflection of the Present Tense

**Q365** (MCQ)
Question: What are the three original signs of inflection (علامات الإعراب الأصلية) for the present-tense verb?
  1. Ḍammah for raf', fatḥah for naṣb, sukūn for jazm
  2. Wāw, alif, yā'
  3. Nūn for all cases
  4. Fatḥah for raf', ḍammah for naṣb
Correct answer: Ḍammah for raf', fatḥah for naṣb, sukūn for jazm

**Q366** (Fill in the blank)
Question: In the book's example «لَمْ يَمْشِ», the sign of jazm is ___ (the last letter is dropped).
  1. B
  2. o
  3. o
  4. k
  5. :
  6.  
  7. ا
  8. ل
  9. ف
  10. ع
  11. ل
  12.  
  13. ا
  14. ل
  15. ن
  16. ا
  17. ق
  18. ص
  19.  
  20. —
  21.  
  22. ع
  23. ل
  24. ا
  25. م
  26. ة
  27.  
  28. ا
  29. ل
  30. ج
  31. ز
  32. م
  33.  
  34. ف
  35. ي
  36. ه
  37.  
  38. ح
  39. ذ
  40. ف
  41.  
  42. آ
  43. خ
  44. ر
  45. ه
Correct answer: حَذْفُ الْآخِر

**Q367** (MCQ)
Question: The book gives «لَمْ يَدْعُ» and «لَمْ يَنْسَ» as examples of:
  1. The sound verb — jazm by sukūn
  2. The defective verb (الفعل الناقص) — jazm by dropping the final weak letter
  3. The five verbs
  4. The passive verb
Correct answer: The defective verb (الفعل الناقص) — jazm by dropping the final weak letter

**Q368** (Q&A)
Question: Explain the book's three examples of the defective verb in jazm: لَمْ يَمْشِ، لَمْ يَدْعُ، لَمْ يَنْسَ.
Model answer (teacher only): These are defective verbs (آخرها حرف علة). In jazm, the sign is dropping the final weak letter: يَمْشِي → لَمْ يَمْشِ، يَدْعُو → لَمْ يَدْعُ، يَنْسَى → لَمْ يَنْسَ.


## Madinah 3: Declinable and Indeclinable (المعرب والمبني)

**Q369** (MCQ)
Question: According to the book, which of these is معرب (declinable)?
  1. هذا
  2. هذان (dual of هذا)
  3. الذي
  4. أَيْنَ
Correct answer: هذان (dual of هذا)
Hint: Book: «هذان» وهاتان معربان — the rest are مبني

**Q370** (Fill in the blank)
Question: The book defines المقصور as the declinable noun ending in a fixed alif, e.g. ___ (the hospital).
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 9
  9. :
  10.  
  11. ن
  12. ح
  13. و
  14.  
  15. ا
  16. ل
  17. م
  18. س
  19. ت
  20. ش
  21. ف
  22. ى
  23. ،
  24.  
  25. ا
  26. ل
  27. ف
  28. ت
  29. ى
  30. ،
  31.  
  32. ا
  33. ل
  34. ع
  35. ص
  36. ا
Correct answer: الْمُسْتَشْفَى

**Q371** (MCQ)
Question: In the book's example «قَتَلَ الْفَتَى الْأَفْعَى بِالْعَصَا», why does الفتى not show its case endings?
  1. It is مبني
  2. It is مقصور — all three case signs are assumed (مقدرة)
  3. It is منقوص
  4. It has no case
Correct answer: It is مقصور — all three case signs are assumed (مقدرة)

**Q372** (Q&A)
Question: The book lists seven groups of indeclinable (مبني) words. Name them with one example each.
Model answer (teacher only): 1. Accusative pronouns: رَأَيْتُهُ 2. Genitive pronouns: كِتَابُهُ 3. Demonstratives: هٰذَا 4. Relative pronouns: اَلَّذِي 5. Interrogatives: مَنْ 6. Some adverbs: أَمْسِ 7. Compound numbers: أَحَدَ عَشَرَ. (Book p.6)


## Madinah 3: The Followers (التوابع)

**Q373** (MCQ)
Question: The followers (التوابع) are four. Which is NOT one of them?
  1. النعت (adjective)
  2. العطف (conjunction)
  3. البدل (apposition)
  4. الحال (the circumstantial accusative)
Correct answer: الحال (the circumstantial accusative)
Hint: Book: التوابع أربعة — النعت، العطف، البدل، التوكيد

**Q374** (Fill in the blank)
Question: The follower takes the same ___ as the word it follows.
  1. ا
  2. ل
  3. ت
  4. ا
  5. ب
  6. ع
  7.  
  8. ي
  9. ت
  10. ب
  11. ع
  12.  
  13. ا
  14. ل
  15. م
  16. ت
  17. ب
  18. و
  19. ع
  20.  
  21. ف
  22. ي
  23.  
  24. ا
  25. ل
  26. إ
  27. ع
  28. ر
  29. ا
  30. ب
Correct answer: case (إعراب)

**Q375** (MCQ)
Question: In «جَاءَ الطَّالِبُ الْمُجْتَهِدُ», الْمُجْتَهِدُ is:
  1. نعت (adjective) — marfū' like الطالب
  2. حال — manṣūb
  3. بدل — majrūr
  4. توكيد
Correct answer: نعت (adjective) — marfū' like الطالب

**Q376** (Q&A)
Question: Define each of the four followers with a short example.
Model answer (teacher only): النعت (adjective): جاء الطالب المجتهد — describes. العطف (conjunction): جاء محمد وخالد — joined by a particle. البدل (apposition): قرأت الكتاب نصفه — substitutes. التوكيد (emphasis): جاء الطلاب كلهم — emphasizes. Each follows its noun in case.


## Madinah 3: Diptotes (الممنوع من الصرف)

**Q377** (MCQ)
Question: The book gives قَنَادِيل، قَرَاطِيس، عَصَافِير، فَنَاجِين as examples of:
  1. صيغ منتهى الجموع (patterns of ultimate plurals) — diptotes
  2. Sound plurals
  3. Dual forms
  4. Diminutives
Correct answer: صيغ منتهى الجموع (patterns of ultimate plurals) — diptotes

**Q378** (Fill in the blank)
Question: مَسْجِدٌ → ___ (the book's example of شبه فعالل).
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 2
  9. 9
  10. 2
  11. :
  12.  
  13. م
  14. س
  15. ج
  16. د
  17.  
  18. →
  19.  
  20. م
  21. س
  22. ا
  23. ج
  24. د
Correct answer: مَسَاجِدُ

**Q379** (MCQ)
Question: مِفْتَاحٌ → مَفَاتِيحُ is an example of which pattern?
  1. فعالل
  2. شبه فعالل
  3. شبه فعاليل
  4. فعول
Correct answer: شبه فعاليل

**Q380** (Q&A)
Question: What is الممنوع من الصرف, and how does the book illustrate it with broken plurals?
Model answer (teacher only): The diptote is the noun that does not take tanwīn and takes fatḥah instead of kasrah in jarr. The book illustrates it with صيغ منتهى الجموع: فعالل (قناديل)، فعاليل (فناجين)، and their likes: مساجد، منابر، أسابيع، مفاتيح.


## Madinah 3: Numbers and Counted Nouns

**Q381** (MCQ)
Question: The book's example «اِشْتَرَيْتُ هٰذَا بِخَمْسَةَ عَشَرَ رِيَالاً» shows that with 11–99, the counted noun is:
  1. Majrūr and plural
  2. Manṣūb and singular (تمييز)
  3. Marfū' and singular
  4. Manṣūb and plural
Correct answer: Manṣūb and singular (تمييز)

**Q382** (Fill in the blank)
Question: Complete the book's exercise: أَكَلْتُ ثَلَاثَ ___ (I ate three dates).
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 2
  9. 9
  10. 6
  11. :
  12.  
  13. أ
  14. ك
  15. ل
  16. ت
  17.  
  18. ث
  19. ل
  20. ا
  21. ث
  22.  
  23. ت
  24. م
  25. ر
  26. ا
  27. ت
Correct answer: تَمَرَاتٍ

**Q383** (MCQ)
Question: In «كَمْ رِيَالاً عِنْدَكَ؟» (book's exercise), رِيَالاً is:
  1. مفعول به
  2. تمييز — manṣūb after كم
  3. حال
  4. مبتدأ
Correct answer: تمييز — manṣūb after كم

**Q384** (Q&A)
Question: Using the book's exercises, explain the rule of the counted noun with the number 3.
Model answer (teacher only): With 3–10, the counted noun (معدود) is plural and majrūr: ثلاث تمراتٍ، ثلاث طبعاتٍ، ثلاث ساعاتٍ، ثلاث أخواتٍ. (Book p.296)


## Madinah 3: Conditional Sentences

**Q385** (MCQ)
Question: In the āyah «وَمَنْ يَبْتَغِ غَيْرَ الْإِسْلَامِ دِينًا فَلَنْ يُقْبَلَ مِنْهُ» (cited in the book), the conditional particle is:
  1. إِنْ
  2. مَنْ
  3. مَا
  4. لَنْ
Correct answer: مَنْ

**Q386** (Fill in the blank)
Question: Complete the ḥadīth cited in the book: «مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ ___».
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 1
  9. 2
  10. 6
Correct answer: لِيَصْمُتْ

**Q387** (MCQ)
Question: In «إِنْ يَكُنْ مِنْكُمْ عِشْرُونَ صَابِرُونَ يَغْلِبُوا مِائَتَيْنِ» (book's example), يَغْلِبُوا is:
  1. The protasis (فعل الشرط)
  2. The apodosis (جواب الشرط) — majzūm by dropping the nūn
  3. A ḥāl
  4. Marfū'
Correct answer: The apodosis (جواب الشرط) — majzūm by dropping the nūn

**Q388** (Q&A)
Question: Identify the three parts of a conditional sentence using the book's example «فَمَنْ تَطَوَّعَ خَيْرًا فَهُوَ خَيْرٌ لَهُ».
Model answer (teacher only): أداة الشرط: مَنْ. فعل الشرط: تَطَوَّعَ. جواب الشرط: فَهُوَ خَيْرٌ لَهُ (a nominal sentence, hence joined with فَ).


## Madinah 3: Relative Pronouns

**Q389** (MCQ)
Question: The book lists اَلَّذِي، اَلَّتِي، اَلَّذِينَ as:
  1. أسماء الإشارة
  2. الأسماء الموصولة — indeclinable (مبنية)
  3. أسماء الاستفهام
  4. الضمائر
Correct answer: الأسماء الموصولة — indeclinable (مبنية)

**Q390** (Fill in the blank)
Question: Complete the āyah cited in the book: «وَلَدَيْنَا كِتَابٌ يَنْطِقُ ___» (الجاثية: 29).
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 2
  9. 6
Correct answer: بِالْحَقِّ

**Q391** (MCQ)
Question: In «وَكُلُّ حِزْبٍ بِمَا لَدَيْهِمْ فَرِحُونَ» (book's example), لَدَيْهِمْ means:
  1. 'to them'
  2. 'with them' — لَدَى is an adverb of place meaning عِنْدَ
  3. 'from them'
  4. 'about them'
Correct answer: 'with them' — لَدَى is an adverb of place meaning عِنْدَ

**Q392** (Q&A)
Question: The book teaches لَدَى as a ظرف مكان. Give its meaning and two examples from the book.
Model answer (teacher only): لَدَى means عِنْدَ ('at/with'). Examples: وَجَدْتُهُ لَدَى الْبَابِ (I found him at the door)، مَاذَا لَدَيْكَ؟ (What do you have?).


## Madinah 3: The Interpreted Infinitive (المصدر المؤول)

**Q393** (MCQ)
Question: In the book's exercise «تَنَاوُلُ هٰذَا مِنَ الْغَلَّةِ أَحْسَنُ لَكَ», the student must convert the maṣdar into:
  1. A ṣifah
  2. A مصدر مؤول (e.g. أَنْ تَتَنَاوَلَ)
  3. A ḥāl
  4. A plural
Correct answer: A مصدر مؤول (e.g. أَنْ تَتَنَاوَلَ)

**Q394** (Fill in the blank)
Question: The maṣdar of عَفَا يَغْفِرُ (book's example) is ___.
  1. B
  2. o
  3. o
  4. k
  5.  
  6. p
  7. .
  8. 8
  9. 6
  10. :
  11.  
  12. ع
  13. ف
  14. ا
  15.  
  16. م
  17. ص
  18. د
  19. ر
  20. ه
  21.  
  22. ع
  23. ف
  24. و
Correct answer: عَفْوٌ

**Q395** (MCQ)
Question: The book says طَفِقَ، جَعَلَ، أَخَذَ (when meaning شَرَعَ) work like كَانَ except that their khabar must be:
  1. A single word
  2. A verbal sentence whose verb is in the present tense (جملة فعلية فعلها مضارع)
  3. A prepositional phrase
  4. In the past tense
Correct answer: A verbal sentence whose verb is in the present tense (جملة فعلية فعلها مضارع)

**Q396** (Q&A)
Question: What is the المصدر المؤول? Illustrate with the book's exercise.
Model answer (teacher only): It is أَنْ + present-tense verb (or أَنَّ + its sentence), interpreted as a maṣdar. E.g. سَكَنُكَ فِي الْمَهْجَعِ أَفْضَلُ لَنَا → أَنْ تَسْكُنَ فِي الْمَهْجَعِ أَفْضَلُ لَنَا.


## Madinah 3: Dialogue Practice

**Q397** (MCQ)
Question: In the book's dialogue, the manager says: «أَدْعُوكَ لِزِيَارَةِ مَعْهَدِنَا، هٰذِهِ بِطَاقَتِي». بِطَاقَتِي means:
  1. My office
  2. My card
  3. My book
  4. My car
Correct answer: My card

**Q398** (Fill in the blank)
Question: Complete the ḥadīth quoted in Lesson 20 of the book: «خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَ___».
  1. ر
  2. و
  3. ا
  4. ه
  5.  
  6. ا
  7. ل
  8. ب
  9. خ
  10. ا
  11. ر
  12. ي
  13.  
  14. —
  15.  
  16. b
  17. o
  18. o
  19. k
  20.  
  21. p
  22. .
  23. 1
  24. 7
  25. 2
Correct answer: عَلَّمَهُ

**Q399** (MCQ)
Question: In the shop dialogue (book p.70), the customer quotes: «مَا عِنْدَكُمْ يَنْفَدُ وَمَا عِنْدَ اللَّهِ بَاقٍ». This is from:
  1. Sūrah al-Baqarah
  2. Sūrah al-Naḥl (16:96)
  3. Sūrah al-Fātiḥah
  4. A ḥadīth
Correct answer: Sūrah al-Naḥl (16:96)

**Q400** (Q&A)
Question: The book's Lesson 20 dialogue teaches the kunyah ذُو النُّورَيْنِ. Who was called by it and why?
Model answer (teacher only): ʿUthmān ibn ʿAffān (رضي الله عنه). He was called ذو النورين (the one with two lights) because he married two of the Prophet's ﷺ daughters: Ruqayyah, then after her death, Umm Kulthūm.


## Qasas 3: The Birth of Musa - In Pharaoh's Palace

**Q401** (MCQ)
Question: What did Allah command the mother of Musa to do when she feared for him?
  1. Hide him in the palace
  2. Nurse him, then cast him into the river
  3. Flee to Midian with him
  4. Give him to the queen
Correct answer: Nurse him, then cast him into the river
Hint: From the verse: أن أرضعيه فإذا خفت عليه فألقيه في اليم

**Q402** (Fill in the blank)
Question: Musa's mother placed her beautiful baby in a ___ (Arabic: صندوق) and cast it into the Nile.
Correct answer: box
Hint: صندوق means box

**Q403** (MCQ)
Question: According to the book, where did Pharaoh have his large palaces?
  1. In the desert
  2. On the bank of the Nile
  3. In Midian
  4. On a mountain
Correct answer: On the bank of the Nile
Hint: كان فرعون له قصور كبيرة على شاطئ النيل

**Q404** (Q&A)
Question: Why did Musa's mother trust Allah's command even though casting a baby into the river seemed dangerous?
Model answer (teacher only): She trusted in Allah and relied on His revelation (توكلت على الله واعتمدت على وحي الله). She reasoned that the house was not safer than the box, because the police were everywhere and the enemy of children was watching. After her grief, she was patient and trusted Allah.


## Qasas 3: The Fatal Blow and the Flight to Midian

**Q405** (MCQ)
Question: When Musa was a strong young man, what did Allah grant him?
  1. Wealth and palaces
  2. Wisdom and knowledge (حكماً وعلماً)
  3. An army of followers
  4. The Torah
Correct answer: Wisdom and knowledge (حكماً وعلماً)
Hint: ولما كان موسى شاباً قوياً آتاه الله حكماً وعلماً

**Q406** (Fill in the blank)
Question: The two men fighting in the city were one from Bani Israel and one from the ___ (الأقباط).
Correct answer: Copts
Hint: الأقباط = the Copts, the native Egyptians

**Q407** (MCQ)
Question: What did Musa say after the Copt died from his blow?
  1. I did nothing wrong
  2. This is from the work of Satan, he is an enemy
  3. Pharaoh ordered me
  4. The man deserved it
Correct answer: This is from the work of Satan, he is an enemy
Hint: قال: هذا من عمل الشيطان إنه عدو

**Q408** (Q&A)
Question: What does this chapter teach about Musa's character before prophethood?
Model answer (teacher only): Musa hated the wrongdoers (يبغض الظالمين) and loved the weak and the oppressed, helping them — as does every prophet. When he made a mistake, he regretted it deeply and repented to Allah at once (فتاب موسى إلى الله وأناب).


## Qasas 3: Musa's Call - Before Pharaoh

**Q409** (MCQ)
Question: What was Allah's command to Musa concerning Pharaoh?
  1. Avoid Pharaoh completely
  2. Go to Pharaoh, for he has transgressed
  3. Fight Pharaoh's army
  4. Flee Egypt at once
Correct answer: Go to Pharaoh, for he has transgressed
Hint: اذهب إلى فرعون إنه طغى

**Q410** (Fill in the blank)
Question: Musa said: 'Knowledge of them is with my Lord in a Book; my Lord neither errs nor ___.'
Correct answer: forgets
Hint: لا يضل ربي ولا ينسى (Quran 20:52)

**Q411** (MCQ)
Question: How does the book describe Musa in comparison to Pharaoh during the debate?
  1. Pharaoh was wiser than Musa
  2. Musa was wiser than Pharaoh
  3. They were equally wise
  4. Neither was wise
Correct answer: Musa was wiser than Pharaoh
Hint: ولكن موسى كان أعقل من فرعون — and Musa was upon light from his Lord

**Q412** (Q&A)
Question: How did Pharaoh's council react when Musa spoke about their forefathers?
Model answer (teacher only): The people of the council became angry and said that Musa had insulted their forefathers (غضب أهل المجلس وقالوا إن موسى سب آباءنا). Pharaoh himself tried to escape from Musa's words rather than answer them.


## Qasas 3: The Five Signs and the Exodus

**Q413** (MCQ)
Question: Which of the following was NOT among the five distinct signs sent upon Pharaoh's people?
  1. Flood (الطوفان)
  2. Locusts (الجراد)
  3. Frogs (الضفادع)
  4. Earthquake
Correct answer: Earthquake
Hint: The five: الطوفان والجراد والقمل والضفادع والدم — flood, locusts, lice, frogs, blood

**Q414** (Fill in the blank)
Question: Each time Allah removed the affliction from them, they ___ their promise (نكثوا عهدهم).
Correct answer: broke
Hint: نكثوا عهدهم = they broke their covenant

**Q415** (MCQ)
Question: What did the people promise Musa whenever they saw a sign?
  1. We will fight you
  2. We will repent, believe, and let Bani Israel go with you
  3. We will build you a palace
  4. We will worship your Lord forever
Correct answer: We will repent, believe, and let Bani Israel go with you
Hint: قالوا لموسى: ادع لنا ربك أن يكشف عنا البلاء ونتوب ونؤمن ونرسل معك بني إسرائيل

**Q416** (Q&A)
Question: Why did the signs not benefit Pharaoh's people?
Model answer (teacher only): Because they were arrogant (فاستكبروا) and were a criminal people (قوماً مجرمين). Every time a sign came they promised to believe, but when Allah removed the affliction they broke their promise (نكثوا عهدهم).


## Qasas 3: In the Wilderness - The Tablets and the Forty Years

**Q417** (MCQ)
Question: What did the seventy men demand when Musa brought them the Tablets?
  1. Give us more tablets
  2. We will not believe until we see Allah openly
  3. Let us return to Egypt
  4. Forgive our sins first
Correct answer: We will not believe until we see Allah openly
Hint: قالوا: لن نؤمن حتى نرى الله جهرة

**Q418** (Fill in the blank)
Question: Allah decreed the holy land forbidden to them for ___ years, wandering in the earth.
Correct answer: forty
Hint: أربعين سنة يتيهون في الأرض (Quran 5:26)

**Q419** (MCQ)
Question: What seized the seventy men when they made their insolent demand?
  1. A flood
  2. The thunderbolt (الصاعقة)
  3. An army
  4. A famine
Correct answer: The thunderbolt (الصاعقة)
Hint: فأخذتهم الصاعقة وهم ينظرون

**Q420** (Q&A)
Question: What did Bani Israel say when asked to enter the holy land?
Model answer (teacher only): They said: 'O Musa, we will never enter it while they are in it. Go, you and your Lord, and fight; we are sitting here.' (قالوا يا موسى إنا لن ندخلها أبداً ما داموا فيها فاذهب أنت وربك فقاتلا إنا هاهنا قاعدون). Musa despaired of them and prayed to Allah.


# Spoken Arabic

## Conversation 1: Greetings

**Q421** (MCQ)
Question: What do you say in the morning?
  1. صباح الخیر
  2. مساء الخیر
  3. تصبح علی خیر
Correct answer: صباح الخیر

**Q422** (MCQ)
Question: What is "وعلیکم السلام" a reply to?
  1. السلام علیکم
  2. صباح الخیر
  3. مع السلامۃ
Correct answer: السلام علیکم

**Q423** (Fill in the blank)
Question: ___ علیکم (Say salam)
Correct answer: السلام

**Q424** (Fill in the blank)
Question: When leaving, say: مع ___
Correct answer: السلامۃ

**Q425** (Q&A)
Question: What do you say when you meet someone in the morning?
Model answer (teacher only): صباح الخیر، کیف حالک؟

**Q426** (Q&A)
Question: If someone says "السلام علیکم" to you, how do you reply?
Model answer (teacher only): وعلیکم السلام ورحمۃ اللہ وبرکاتہ


## Conversation 2: Introductions

**Q427** (MCQ)
Question: “What is your name?” in Arabic?
  1. ما اسمک؟
  2. کیف حالک؟
  3. من أین أنت؟
Correct answer: ما اسمک؟

**Q428** (MCQ)
Question: “I am from Pakistan” in Arabic?
  1. أنا من باکستان
  2. أنا فی باکستان
  3. أنا إلی باکستان
Correct answer: أنا من باکستان

**Q429** (Fill in the blank)
Question: ___ اسمک؟ (What is your name?)
Correct answer: ما

**Q430** (Fill in the blank)
Question: أنا ___ باکستان (I am from Pakistan)
Correct answer: من

**Q431** (Q&A)
Question: Introduce yourself briefly in Arabic
Model answer (teacher only): اسمی ... وأنا من باکستان، وأسکن فی ...

**Q432** (Q&A)
Question: Ask a new friend how they are
Model answer (teacher only): کیف حالک؟ الحمد للہ، وأنت؟


## Conversation 3: Numbers

**Q433** (MCQ)
Question: “three” in Arabic?
  1. ثلاثۃ
  2. أربعۃ
  3. خمسۃ
Correct answer: ثلاثۃ

**Q434** (MCQ)
Question: “عشرۃ” mean?
  1. ten
  2. نو
  3. آٹھ
Correct answer: ten

**Q435** (Fill in the blank)
Question: واحد، اثنان، ___ (three)
Correct answer: ثلاثۃ

**Q436** (Fill in the blank)
Question: خمسۃ کے بعد آتا ہے: ___ (six)
Correct answer: ستۃ

**Q437** (Q&A)
Question: ایک سے پانچ تک عربی میں گنو
Model answer (teacher only): واحد، اثنان، ثلاثۃ، أربعۃ، خمسۃ

**Q438** (Q&A)
Question: چھ سے دس تک عربی میں گنو
Model answer (teacher only): ستۃ، سبعۃ، ثمانیۃ، تسعۃ، عشرۃ


## Conversation 4: Family

**Q439** (MCQ)
Question: “والد” mean?
  1. باپ
  2. ماں
  3. بھائی
Correct answer: باپ

**Q440** (MCQ)
Question: “بہن” in Arabic?
  1. أخت
  2. أخ
  3. بنت
Correct answer: أخت

**Q441** (Fill in the blank)
Question: میرا بھائی: ___ (my brother)
Correct answer: أخی

**Q442** (Fill in the blank)
Question: “میری ماں” in Arabic: ___
Correct answer: أمی

**Q443** (Q&A)
Question: اپنے خاندان کے بارے میں دو جملے بولو
Model answer (teacher only): عندی أب وأم، وعندی أخ وأخت

**Q444** (Q&A)
Question: Ask: تمہارے کتنے بھائی ہیں؟
Model answer (teacher only): کم عدد إخوتک؟


## Conversation 5: Time and Days

**Q445** (MCQ)
Question: “What time is it?” in Arabic?
  1. کم الساعۃ؟
  2. أین الساعۃ؟
  3. متی الساعۃ؟
Correct answer: کم الساعۃ؟

**Q446** (MCQ)
Question: “today” in Arabic?
  1. الیوم
  2. أمس
  3. غدا
Correct answer: الیوم

**Q447** (Fill in the blank)
Question: ___ الساعۃ؟ (What time is it?)
Correct answer: کم

**Q448** (Fill in the blank)
Question: کل: ___ ، پرسوں: غدا
Correct answer: أمس

**Q449** (Q&A)
Question: Ask: What day is it today?
Model answer (teacher only): أی یوم الیوم؟

**Q450** (Q&A)
Question: Say: کل میں بازار جاؤں گا
Model answer (teacher only): غدا سأذہب إلی السوق


## Conversation 6: Daily Routine

**Q451** (MCQ)
Question: “I wake up in the morning” in Arabic?
  1. أستيقظ صباحا
  2. أنام صباحا
  3. آکل صباحا
Correct answer: أستيقظ صباحا

**Q452** (MCQ)
Question: “food” (فعل) in Arabic?
  1. یأکل
  2. یشرب
  3. ینام
Correct answer: یأکل

**Q453** (Fill in the blank)
Question: میں پانی پیتا ہوں: أنا ___ الماء
Correct answer: أشرب

**Q454** (Fill in the blank)
Question: وہ سوتا ہے: ہو ___
Correct answer: ینام

**Q455** (Q&A)
Question: اپنے دن کا معمول تین جملوں میں بتاؤ
Model answer (teacher only): أستيقظ صباحا، ثم آکل الفطور، ثم أذہب إلی العمل

**Q456** (Q&A)
Question: Ask: تم کب سوتے ہو؟
Model answer (teacher only): متی تنام؟


## Conversation 7: Colors and Things

**Q457** (MCQ)
Question: “سفید” in Arabic?
  1. أبیض
  2. أسود
  3. أحمر
Correct answer: أبیض

**Q458** (MCQ)
Question: “What is this?” in Arabic?
  1. ما هذا؟
  2. من هذا؟
  3. أین هذا؟
Correct answer: ما هذا؟

**Q459** (Fill in the blank)
Question: کالا رنگ: ___
Correct answer: أسود

**Q460** (Fill in the blank)
Question: ___ کتاب؟ (Is this a book?)
Correct answer: ہل هذه

**Q461** (Q&A)
Question: تین رنگوں کے نام عربی میں بتاؤ
Model answer (teacher only): أبیض، أسود، أحمر

**Q462** (Q&A)
Question: Ask: What is that? (a far thing)
Model answer (teacher only): ما ذلک؟


## Conversation 8: Food and Drink

**Q463** (MCQ)
Question: “bread” in Arabic?
  1. خبز
  2. أرز
  3. لحم
Correct answer: خبز

**Q464** (MCQ)
Question: “I like tea” in Arabic?
  1. أحب الشای
  2. أرید الشای
  3. عندی شای
Correct answer: أحب الشای

**Q465** (Fill in the blank)
Question: پانی: ___
Correct answer: ماء

**Q466** (Fill in the blank)
Question: میں گوشت نہیں کھاتا: أنا لا ___ اللحم
Correct answer: آکل

**Q467** (Q&A)
Question: Say: Which food do you like?
Model answer (teacher only): أحب الأرز والدجاج

**Q468** (Q&A)
Question: Ask: Do you like milk?
Model answer (teacher only): ہل تحب الحلیب؟


## Conversation 9: Home

**Q469** (MCQ)
Question: “room” in Arabic?
  1. غرفۃ
  2. باب
  3. نافذۃ
Correct answer: غرفۃ

**Q470** (MCQ)
Question: “This is my house” in Arabic?
  1. ہذا بیتی
  2. ہذا بیتک
  3. ہذا بیتہ
Correct answer: ہذا بیتی

**Q471** (Fill in the blank)
Question: دروازہ: ___
Correct answer: باب

**Q472** (Fill in the blank)
Question: کھڑکی: ___
Correct answer: نافذۃ

**Q473** (Q&A)
Question: اپنے گھر کے تین کمروں کے نام بتاؤ
Model answer (teacher only): غرفۃ النوم، والمطبخ، والحمام

**Q474** (Q&A)
Question: Ask: Where is your house?
Model answer (teacher only): أین بیتک؟


## Conversation 10: Friends and Meetings

**Q475** (MCQ)
Question: “میرا دوست” in Arabic?
  1. صدیقی
  2. أخی
  3. زمیلی
Correct answer: صدیقی

**Q476** (MCQ)
Question: “Will you meet tomorrow?” in Arabic?
  1. ہل نلتقی غدا؟
  2. أین نلتقی؟
  3. متی التقینا؟
Correct answer: ہل نلتقی غدا؟

**Q477** (Fill in the blank)
Question: آؤ میرے گھر: ___ إلی بیتی
Correct answer: تعال

**Q478** (Fill in the blank)
Question: خوش آمدید: ___
Correct answer: أہلا وسہلا

**Q479** (Q&A)
Question: دوست کو چائے کی دعوت دو
Model answer (teacher only): تفضل، اشرب الشای معی

**Q480** (Q&A)
Question: Ask: تم کل کہاں ہو گے؟
Model answer (teacher only): أین ستکون غدا؟


## Conversation 11: At the Market

**Q481** (MCQ)
Question: “How much is this?” in Arabic?
  1. بکم ہذا؟
  2. ما ہذا؟
  3. أین ہذا؟
Correct answer: بکم ہذا؟

**Q482** (MCQ)
Question: “It is very expensive” in Arabic?
  1. ہذا غال جدا
  2. ہذا رخِیص
  3. ہذا جمیل
Correct answer: ہذا غال جدا

**Q483** (Fill in the blank)
Question: بکم ___؟ (How much is this?)
Correct answer: ہذا

**Q484** (Fill in the blank)
Question: تھوڑا سستا کرو: ___ السعر
Correct answer: خفّض

**Q485** (Q&A)
Question: دکاندار سے قیمت پوچھو اور سودا کرو
Model answer (teacher only): بکم ہذا؟ ہذا غال جدا، خفّض السعر من فضلک

**Q486** (Q&A)
Question: Say: میں نے دو کتابیں خریدیں
Model answer (teacher only): اشتریت کتابین


## Conversation 12: At the Restaurant

**Q487** (MCQ)
Question: “I want a tea” in Arabic?
  1. أرید شایا
  2. عندی شای
  3. أحب الشای
Correct answer: أرید شایا

**Q488** (MCQ)
Question: “The food is delicious” in Arabic?
  1. الطعام لذیذ
  2. الطعام کثیر
  3. الطعام حار
Correct answer: الطعام لذیذ

**Q489** (Fill in the blank)
Question: میں بھوکا ہوں: أنا ___
Correct answer: جائع

**Q490** (Fill in the blank)
Question: بل لاؤ: ___ الحساب
Correct answer: أحضر

**Q491** (Q&A)
Question: ویٹر سے کھانا منگواؤ
Model answer (teacher only): من فضلک، أرید الأرز والدجاج

**Q492** (Q&A)
Question: کھانے کی تعریف کرو
Model answer (teacher only): الطعام لذیذ جدا، شکرا


## Conversation 13: سفر

**Q493** (MCQ)
Question: “airport” in Arabic?
  1. المطار
  2. المحطۃ
  3. المیناء
Correct answer: المطار

**Q494** (MCQ)
Question: “When is my flight?” in Arabic?
  1. متی رحلتی؟
  2. أین رحلتی؟
  3. کیف رحلتی؟
Correct answer: متی رحلتی؟

**Q495** (Fill in the blank)
Question: ٹکٹ: ___
Correct answer: تذکرۃ

**Q496** (Fill in the blank)
Question: میں سفر کر رہا ہوں: أنا ___
Correct answer: مسافر

**Q497** (Q&A)
Question: Ask: When is the Karachi flight?
Model answer (teacher only): متی رحلۃ کراتشی؟

**Q498** (Q&A)
Question: Say: میں کل سفر کروں گا
Model answer (teacher only): سأسافر غدا إن شاء اللہ


## Conversation 14: Asking for Directions

**Q499** (MCQ)
Question: “دائیں” in Arabic?
  1. یمین
  2. یسار
  3. أمام
Correct answer: یمین

**Q500** (MCQ)
Question: “Where is the masjid?” in Arabic?
  1. أین المسجد؟
  2. ما المسجد؟
  3. کم المسجد؟
Correct answer: أین المسجد؟

**Q501** (Fill in the blank)
Question: بائیں: ___
Correct answer: یسار

**Q502** (Fill in the blank)
Question: سیدھا جاؤ: اذہب ___
Correct answer: مستقیما

**Q503** (Q&A)
Question: کسی سے مسجد کا راستہ پوچھو
Model answer (teacher only): عفوا، أین المسجد من فضلک؟

**Q504** (Q&A)
Question: راستہ بتاؤ: دائیں مڑو پھر سیدھا
Model answer (teacher only): انعطف یمینا ثم اذہب مستقیما


## Conversation 15: On the Phone

**Q505** (MCQ)
Question: فون پر “Who is it?” in Arabic?
  1. من معی؟
  2. ما اسمک؟
  3. أین أنت؟
Correct answer: من معی؟

**Q506** (MCQ)
Question: “Wait a minute” in Arabic?
  1. انتظر دقيقۃ
  2. تعال سریعا
  3. اذہب الآن
Correct answer: انتظر دقيقۃ

**Q507** (Fill in the blank)
Question: ہیلو (فون پر): ___
Correct answer: آلو

**Q508** (Fill in the blank)
Question: میں بعد میں کال کروں گا: سأتصل ___
Correct answer: لاحقا

**Q509** (Q&A)
Question: فون پر اپنا تعارف کراؤ
Model answer (teacher only): آلو، السلام علیکم، أنا ...، من معی؟

**Q510** (Q&A)
Question: Say: وہ ابھی مصروف ہے
Model answer (teacher only): ہو مشغول الآن


## Conversation 16: موسم

**Q511** (MCQ)
Question: “How is the weather today?” in Arabic?
  1. کیف الطقس الیوم؟
  2. أین الطقس؟
  3. متی الطقس؟
Correct answer: کیف الطقس الیوم؟

**Q512** (MCQ)
Question: “It is raining” in Arabic?
  1. المطر ینزل
  2. الشمس تشرق
  3. الریح تھب
Correct answer: المطر ینزل

**Q513** (Fill in the blank)
Question: گرمی: ___
Correct answer: حرّ

**Q514** (Fill in the blank)
Question: سردی: ___
Correct answer: برد

**Q515** (Q&A)
Question: موسم کے بارے میں دو جملے بولو
Model answer (teacher only): الطقس جمیل الیوم، والشمس مشرقۃ

**Q516** (Q&A)
Question: Ask: کیا کل بارش ہو گی؟
Model answer (teacher only): ہل سینزل المطر غدا؟


## Conversation 17: صحت

**Q517** (MCQ)
Question: “I am sick” in Arabic?
  1. أنا مریض
  2. أنا صحیح
  3. أنا تعبان فقط
Correct answer: أنا مریض

**Q518** (MCQ)
Question: “doctor” in Arabic?
  1. طبیب
  2. ممرض
  3. صیدلی
Correct answer: طبیب

**Q519** (Fill in the blank)
Question: میرے سر میں درد ہے: رأسی ___
Correct answer: یؤلمنی

**Q520** (Fill in the blank)
Question: دوا: ___
Correct answer: twoاء

**Q521** (Q&A)
Question: ڈاکٹر کو اپنی تکلیف بتاؤ
Model answer (teacher only): یا دکتور، رأسی یؤلمنی وحرارتی مرتفعۃ

**Q522** (Q&A)
Question: Ask: کیا تم ٹھیک ہو؟
Model answer (teacher only): ہل أنت بخیر؟


## Conversation 18: Work and Office

**Q523** (MCQ)
Question: “I am a teacher” in Arabic?
  1. أنا معلم
  2. أنا طالب
  3. أنا مدیر
Correct answer: أنا معلم

**Q524** (MCQ)
Question: “دفتر” in Arabic?
  1. مکتب
  2. مصنع
  3. متجر
Correct answer: مکتب

**Q525** (Fill in the blank)
Question: میٹنگ: ___
Correct answer: اجتماع

**Q526** (Fill in the blank)
Question: میں کام کرتا ہوں: أنا ___
Correct answer: أعمل

**Q527** (Q&A)
Question: اپنے کام کے بارے میں بتاؤ
Model answer (teacher only): أعمل معلما فی مدرسۃ، وأحب عملی

**Q528** (Q&A)
Question: Ask: تم کہاں کام کرتے ہو؟
Model answer (teacher only): أین تعمل؟


## Conversation 19: Shopping Details

**Q529** (MCQ)
Question: “I want a large size” in Arabic?
  1. أرید مقاسا کبیرا
  2. أرید لونا جمیلا
  3. أرید سعرا رخِیصا
Correct answer: أرید مقاسا کبیرا

**Q530** (MCQ)
Question: “Is there another color?” in Arabic?
  1. ہل یوجد لون آخر؟
  2. ما السعر؟
  3. أین المتجر؟
Correct answer: ہل یوجد لون آخر؟

**Q531** (Fill in the blank)
Question: قمیض: ___
Correct answer: قمیص

**Q532** (Fill in the blank)
Question: یہ مجھ پر اچھا لگتا ہے: ہذا ___ علیّ
Correct answer: جمیل

**Q533** (Q&A)
Question: دکاندار سے نیلا قمیض مانگو
Model answer (teacher only): أرید قمیصا أزرق من فضلک

**Q534** (Q&A)
Question: Ask: Can this be washed?
Model answer (teacher only): ہل یمکن غسلہ؟


## Conversation 20: Hospitality

**Q535** (MCQ)
Question: “Please come in” in Arabic?
  1. تفضل
  2. اذہب
  3. انتظر
Correct answer: تفضل

**Q536** (MCQ)
Question: “The food is ready” in Arabic?
  1. الطعام جاہز
  2. الطعام کثیر
  3. الطعام حار
Correct answer: الطعام جاہز

**Q537** (Fill in the blank)
Question: مہمان: ___
Correct answer: ضیف

**Q538** (Fill in the blank)
Question: Thanks (in reply): ___
Correct answer: عفوا

**Q539** (Q&A)
Question: مہمان کا استقبال کرو
Model answer (teacher only): أہلا وسہلا، تفضل، البیت بیتک

**Q540** (Q&A)
Question: مہمان سے کھانے کو کہو
Model answer (teacher only): تفضل، کل معنا


## Conversation 21: Giving Opinions

**Q541** (MCQ)
Question: “In my opinion” in Arabic?
  1. فی رأیی
  2. فی بیتي
  3. فی وقتِی
Correct answer: فی رأیی

**Q542** (MCQ)
Question: “I agree” in Arabic?
  1. أنا متفق
  2. أنا مختلف
  3. أنا نادم
Correct answer: أنا متفق

**Q543** (Fill in the blank)
Question: میرے خیال میں یہ اچھا ہے: فی ___ ہذا جید
Correct answer: رأیی

**Q544** (Fill in the blank)
Question: میں متفق نہیں ہوں: أنا ___ متفق
Correct answer: لست

**Q545** (Q&A)
Question: Give your opinion: Is learning Arabic easy?
Model answer (teacher only): فی رأیی تعلم العربیۃ سہل وممتع

**Q546** (Q&A)
Question: کسی کی رائے سے اختلاف کرو (نرمی سے)
Model answer (teacher only): أحترم رأیک، لکن لی رأی آخر


## Conversation 22: Telling Stories

**Q547** (MCQ)
Question: “once” in Arabic?
  1. ذات یوم
  2. کل یوم
  3. ہذا الیوم
Correct answer: ذات یوم

**Q548** (MCQ)
Question: “What happened next?” in Arabic?
  1. ثم ماذا حدث؟
  2. أین حدث؟
  3. متی حدث؟
Correct answer: ثم ماذا حدث؟

**Q549** (Fill in the blank)
Question: کہانی: ___
Correct answer: قصۃ

**Q550** (Fill in the blank)
Question: پھر: ___
Correct answer: ثم

**Q551** (Q&A)
Question: اپنے بچپن کی ایک یاد سناؤ
Model answer (teacher only): عندما کنت صغیرا، کنت ألعب مع أصدقائی

**Q552** (Q&A)
Question: کہانی شروع کرو: ایک دفعہ ایک آدمی تھا...
Model answer (teacher only): ذات یوم کان رجل یعیش فی قریۃ صغیرۃ


## Conversation 23: Formal Meetings

**Q553** (MCQ)
Question: “Pleased to meet you” in Arabic?
  1. تشرفت بلقائک
  2. أہلا بک فقط
  3. مع السلامۃ
Correct answer: تشرفت بلقائک

**Q554** (MCQ)
Question: رسمی “آپ” کے لیے؟
  1. حضرتک
  2. أنت
  3. یا أخی
Correct answer: حضرتک

**Q555** (Fill in the blank)
Question: تشریف رکھیں (بیٹھیں): ___
Correct answer: تفضل بالجلوس

**Q556** (Fill in the blank)
Question: آپ کی مہربانی: ___
Correct answer: کرمک

**Q557** (Q&A)
Question: کسی بزرگ سے رسمی ملاقات کرو
Model answer (teacher only): السلام علیکم، تشرفت بلقائک یا شیخ

**Q558** (Q&A)
Question: رسمی انداز میں شکریہ ادا کرو
Model answer (teacher only): أشکرک شکرا جزیلا علی کرمک


## Conversation 24: خبر اور حالات

**Q559** (MCQ)
Question: “What's up?” in Arabic?
  1. ما الأخبار؟
  2. أین الأخبار؟
  3. کم الأخبار؟
Correct answer: ما الأخبار؟

**Q560** (MCQ)
Question: “Good news!” in Arabic?
  1. أخبار سارۃ!
  2. أخبار سیئۃ!
  3. لا أخبار!
Correct answer: أخبار سارۃ!

**Q561** (Fill in the blank)
Question: خبر (واحد): ___
Correct answer: خبر

**Q562** (Fill in the blank)
Question: سنا ہے کہ: ___ أن
Correct answer: سمعت

**Q563** (Q&A)
Question: کوئی اچھی خبر سناؤ
Model answer (teacher only): عندی أخبار سارۃ! نجحت فی الامتحان

**Q564** (Q&A)
Question: Ask: ملک کے حالات کیسے ہیں؟
Model answer (teacher only): کیف أحوال البلد؟


## Conversation 25: مشورہ

**Q565** (MCQ)
Question: “I advise you” in Arabic?
  1. أنصحک
  2. آمرک
  3. أسألک
Correct answer: أنصحک

**Q566** (MCQ)
Question: “What is your opinion?” in Arabic?
  1. ما رأیک؟
  2. ما اسمک؟
  3. أین بیتک؟
Correct answer: ما رأیک؟

**Q567** (Fill in the blank)
Question: مشورہ: ___
Correct answer: نصیحۃ

**Q568** (Fill in the blank)
Question: تمہیں چاہیے کہ: ___ أن
Correct answer: ینبغی

**Q569** (Q&A)
Question: دوست کو پڑھائی کا مشورہ دو
Model answer (teacher only): أنصحک أن تدرس کل یوم، فالعلم نور

**Q570** (Q&A)
Question: Ask: میں کیا کروں؟
Model answer (teacher only): ماذا أفعل برأیک؟


## Conversation 26: Apologies and Thanks

**Q571** (MCQ)
Question: “Excuse me” (رسمی) in Arabic?
  1. أعتذر إلیک
  2. لا بأس
  3. انس الأمر
Correct answer: أعتذر إلیک

**Q572** (MCQ)
Question: “No problem” in Arabic?
  1. لا بأس
  2. لا شکر
  3. لا عفو
Correct answer: لا بأس

**Q573** (Fill in the blank)
Question: معذرت خواہ ہوں: أنا ___
Correct answer: آسف

**Q574** (Fill in the blank)
Question: اللہ تمہیں جزا دے: ___ اللہ خیرا
Correct answer: جزاک

**Q575** (Q&A)
Question: دیر سے آنے پر معذرت کرو
Model answer (teacher only): أعتذر عن التأخیر، کان عندی ظرف طارئ

**Q576** (Q&A)
Question: کسی کے احسان کا شکریہ ادا کرو
Model answer (teacher only): جزاک اللہ خیرا، لن أنسی فضلک


## Conversation 27: Plans

**Q577** (MCQ)
Question: “I intend” in Arabic?
  1. أنوی أن
  2. أحب أن
  3. أخاف أن
Correct answer: أنوی أن

**Q578** (MCQ)
Question: “ان شاء اللہ” do you say it?
  1. مستقبل کے ارادے پر
  2. ماضی پر
  3. حال پر
Correct answer: مستقبل کے ارادے پر

**Q579** (Fill in the blank)
Question: منصوبہ: ___
Correct answer: خطۃ

**Q580** (Fill in the blank)
Question: میں اگلے سال حج کروں گا: سأحج ___ القادم
Correct answer: العام

**Q581** (Q&A)
Question: اپنے مستقبل کے تین منصوبے بتاؤ
Model answer (teacher only): أنوی أن أتعلم العربیۃ، وأن أسافر، وأن أعمل معلما

**Q582** (Q&A)
Question: Ask: تمہارے گرمیوں کے منصوبے کیا ہیں؟
Model answer (teacher only): ما خططک لعطلۃ الصیف؟


## Conversation 28: Memories

**Q583** (MCQ)
Question: “When I was young” in Arabic?
  1. عندما کنت صغیرا
  2. عندما سأکبر
  3. أنا صغیر الآن
Correct answer: عندما کنت صغیرا

**Q584** (MCQ)
Question: “یاد” in Arabic?
  1. ذکریات
  2. أحلام
  3. آمال
Correct answer: ذکریات

**Q585** (Fill in the blank)
Question: پرانی یادیں: ذکریات ___
Correct answer: قدیمۃ

**Q586** (Fill in the blank)
Question: مجھے یاد ہے: ___
Correct answer: أتذکر

**Q587** (Q&A)
Question: بچپن کی کوئی یاد سناؤ
Model answer (teacher only): أتذکر عندما کنا نلعب فی الحدیقۃ کل مساء

**Q588** (Q&A)
Question: Ask: Do you remember your first teacher?
Model answer (teacher only): ہل تتذکر معلمک الأول؟


## Conversation 29: بحث

**Q589** (MCQ)
Question: “دلیل” in Arabic?
  1. دلیل
  2. قصۃ
  3. مثل
Correct answer: دلیل

**Q590** (MCQ)
Question: “The reason is” in Arabic?
  1. السبب فی ذلک
  2. الخبر فی ذلک
  3. السؤال فی ذلک
Correct answer: السبب فی ذلک

**Q591** (Fill in the blank)
Question: بحث و مباحثہ: ___
Correct answer: نقاش

**Q592** (Fill in the blank)
Question: میرے پاس دلیل ہے: عندی ___
Correct answer: دلیل

**Q593** (Q&A)
Question: اپنی بات کی دلیل دو
Model answer (teacher only): السبب فی ذلک أن التجارب أثبتت ذلک

**Q594** (Q&A)
Question: بحث میں نرمی سے اختلاف کرو
Model answer (teacher only): أفہم وجہۃ نظرک، ولکن عندی رأی مختلف


## Conversation 30: Speeches

**Q595** (MCQ)
Question: “Respected audience” in Arabic?
  1. أیہا الحضور الکرام
  2. یا أصدقائی فقط
  3. أیہا الناس کلہم
Correct answer: أیہا الحضور الکرام

**Q596** (MCQ)
Question: تقریر کے آخر میں کیا کہتے ہیں؟
  1. والسلام علیکم
  2. صباح الخیر
  3. إلی اللقاء قریبا
Correct answer: والسلام علیکم

**Q597** (Fill in the blank)
Question: خطاب: ___
Correct answer: خطاب

**Q598** (Fill in the blank)
Question: میں بات کروں گا عن: سأتحدث ___
Correct answer: عن

**Q599** (Q&A)
Question: عربی سیکھنے کی اہمیت پر دو جملے بولو
Model answer (teacher only): أیہا الإخوۃ، تعلم العربیۃ مفتاح فہم القرآن

**Q600** (Q&A)
Question: تقریر ختم کرو
Model answer (teacher only): أشکرکم علی حسن استماعکم، والسلام علیکم

---
Total questions: 600