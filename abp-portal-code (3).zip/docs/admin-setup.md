# Creating the Initial Central Administrator

The portal has no default admin account (by design — no hardcoded credentials).
Create the first central administrator on the server with Django's secure
`createsuperuser` command. The password is hashed with PBKDF2 before storage;
it is never stored or logged in plain text.

## Steps

```bash
cd arabic-bridge-program
source .venv/bin/activate
python manage.py createsuperuser
```

You will be asked for:
- **Email** — this becomes the admin login (e.g. your official academy email)
- **First name / Last name**
- **Password** — typed twice, never displayed

Then log in at `/admin/` (full Django admin) or `/accounts/login/`
(role dashboard). The account has the `admin` role.

## Additional administrators (restricted)

The central administrator creates further admin accounts from `/admin/`
(Users → Add user) and assigns the `admin` role. Restricted permissions
for additional administrators are defined in Phase 8 (audit + permissions
hardening); until then, every `admin`-role account has full access, so
create them sparingly.

## Security notes

- Never share the `.env` file or the `SECRET_KEY`.
- Change the temporary student passwords flow: students receive a
  one-time password on approval and should change it after first login
  (self-service change page arrives in Phase 2).
- Password resets are emailed only to the address on file (console
  backend in development; real SMTP configured at deployment, Phase 9).
