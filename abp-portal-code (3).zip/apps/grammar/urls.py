from django.urls import path

from . import views

app_name = "grammar"

urlpatterns = [
    path("", views.home, name="home"),
    path("rule/<int:pk>/", views.rule_detail, name="rule"),
    path("rule/<int:pk>/practice/", views.practice, name="practice"),
    path("lessons/", views.lessons_home, name="lessons"),
    path("lessons/<int:pk>/", views.lesson_detail, name="lesson"),
]
