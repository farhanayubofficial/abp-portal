"""Grammar (Qawaid): rules from Duroos-ul-Lughat-il-Arabiya + tamreen.

Each GrammarRule has explanation (Urdu/English) + examples + 10 MCQ
exercises. No typing — click the correct answer.
"""

from django.conf import settings
from django.db import models


class GrammarRule(models.Model):
    book = models.PositiveSmallIntegerField(
        help_text="Madinah Book 1, 2 or 3")
    lesson_no = models.PositiveIntegerField(default=0)
    title_ar = models.CharField(max_length=200)
    title_ur = models.CharField(max_length=200)
    explanation_ur = models.TextField(blank=True)
    explanation_en = models.TextField(blank=True)
    examples_json = models.TextField(
        default="[]", help_text='[{"ar":..,"ur":..,"en":..}]')
    is_published = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["book", "lesson_no"]

    def __str__(self):
        return f"Book {self.book} L{self.lesson_no}: {self.title_ar}"

    @property
    def examples(self):
        import json
        try:
            return json.loads(self.examples_json or "[]")
        except Exception:
            return []


class BookLesson(models.Model):
    """As-is lesson from Duroos-ul-Lughat-il-Arabiya: dialogue + text."""
    book = models.PositiveSmallIntegerField(
        help_text="Madinah Book 1, 2 or 3")
    lesson_no = models.PositiveIntegerField()
    title = models.CharField(max_length=200, blank=True)
    dialogue_json = models.TextField(
        default="[]",
        help_text='[{"speaker":"..","ar":".."}, ...] — محادثہ')
    text = models.TextField(blank=True, help_text="متن / passage as-is")
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["book", "lesson_no"]
        unique_together = ("book", "lesson_no")

    def __str__(self):
        return f"Book {self.book} — سبق {self.lesson_no}"

    @property
    def dialogue(self):
        import json
        try:
            return json.loads(self.dialogue_json or "[]")
        except Exception:
            return []


class GrammarExercise(models.Model):
    rule = models.ForeignKey(
        GrammarRule, on_delete=models.CASCADE, related_name="exercises")
    question = models.CharField(max_length=500)
    options_json = models.TextField(default="[]")
    answer = models.CharField(max_length=300)
    explain_ur = models.CharField(max_length=500, blank=True)
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.question[:60]

    @property
    def options(self):
        import json
        try:
            return json.loads(self.options_json or "[]")
        except Exception:
            return []
