from django.contrib import admin

from .models import GrammarExercise, GrammarRule


class GrammarExerciseInline(admin.TabularInline):
    model = GrammarExercise
    extra = 0


@admin.register(GrammarRule)
class GrammarRuleAdmin(admin.ModelAdmin):
    list_display = ("book", "lesson_no", "title_ar", "title_ur")
    list_filter = ("book",)
    inlines = [GrammarExerciseInline]
