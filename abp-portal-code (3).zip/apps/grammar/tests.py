"""Grammar app tests."""

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import BookLesson, GrammarExercise, GrammarRule


class GrammarTests(TestCase):
    def setUp(self):
        GrammarExercise.objects.all().delete()
        GrammarRule.objects.all().delete()
        BookLesson.objects.all().delete()  # isolate from seed migration data
        self.student = User.objects.create_user(
            email="g@x.com", password="x", first_name="G",
            last_name="T", role=User.ROLE_STUDENT)
        self.rule = GrammarRule.objects.create(
            book=1, lesson_no=5, title_ar="المذكر والمؤنث",
            title_ur="مذکر و مؤنث",
            explanation_ur="وضاحت", examples_json="[]")
        GrammarExercise.objects.create(
            rule=self.rule, question="سوال؟",
            options_json='["ا", "ب", "ج", "د"]', answer="ا")

    def test_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("grammar:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Madinah Book 1")

    def test_rule_detail(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("grammar:rule", args=[self.rule.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "المذكر والمؤنث")

    def test_practice(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("grammar:practice", args=[self.rule.pk]))
        self.assertEqual(r.status_code, 200)
        # redesigned practice page renders exercises as JS var `exs`
        self.assertContains(r, "var exs")

    def test_lessons(self):
        BookLesson.objects.create(
            book=1, lesson_no=1, title="Test",
            dialogue_json='[{"speaker": "ا", "ar": "السلام عليكم"}]',
            text="نص تجريبي")
        self.client.force_login(self.student)
        r = self.client.get(reverse("grammar:lessons"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "سبق 1")
        lesson = BookLesson.objects.get()
        r = self.client.get(reverse("grammar:lesson", args=[lesson.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "السلام عليكم")
