"""Grammar views: rule library by book, rule detail, practice."""

import json
import random

from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, render

from .models import BookLesson, GrammarExercise, GrammarRule


@login_required
def home(request):
    books = []
    for b in (1, 2, 3):
        rules = GrammarRule.objects.filter(book=b, is_published=True)
        books.append({"n": b, "rules": rules,
                      "count": rules.count()})
    return render(request, "grammar/home.html", {"books": books})


@login_required
def rule_detail(request, pk):
    rule = get_object_or_404(GrammarRule, pk=pk, is_published=True)
    return render(request, "grammar/rule_detail.html", {"rule": rule})


@login_required
def practice(request, pk):
    rule = get_object_or_404(GrammarRule, pk=pk, is_published=True)
    exercises = list(rule.exercises.filter(is_published=True))
    if not exercises:
        return render(request, "grammar/rule_detail.html",
                      {"rule": rule,
                       "error": "Is qaidے ki abhi mashq nahi hai."})
    random.shuffle(exercises)
    data = []
    for e in exercises[:10]:
        opts = e.options[:]
        random.shuffle(opts)
        data.append({"q": e.question, "options": opts, "answer": e.answer,
                     "explain": e.explain_ur})
    return render(request, "grammar/practice.html", {
        "rule": rule,
        "exercises_json": json.dumps(data, ensure_ascii=False),
    })


@login_required
def lessons_home(request):
    books = []
    for b in (1, 2, 3):
        lessons = BookLesson.objects.filter(book=b, is_published=True)
        books.append({"n": b, "lessons": lessons,
                      "count": lessons.count()})
    return render(request, "grammar/lessons_home.html", {"books": books})


@login_required
def lesson_detail(request, pk):
    lesson = get_object_or_404(BookLesson, pk=pk, is_published=True)
    return render(request, "grammar/lesson_detail.html", {"lesson": lesson})
