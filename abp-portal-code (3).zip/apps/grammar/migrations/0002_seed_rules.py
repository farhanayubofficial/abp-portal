"""Seed grammar rules + exercises from JSON."""

import json
from pathlib import Path

from django.db import migrations

DATA_FILE = Path(__file__).parent.parent / "data" / "rules.json"


def seed(apps, schema_editor):
    GrammarRule = apps.get_model("grammar", "GrammarRule")
    GrammarExercise = apps.get_model("grammar", "GrammarExercise")
    if not DATA_FILE.exists():
        return
    GrammarExercise.objects.all().delete()
    GrammarRule.objects.all().delete()
    rules = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    for r in rules:
        rule = GrammarRule.objects.create(
            book=r["book"], lesson_no=r.get("lesson_no", 0),
            title_ar=r["title_ar"], title_ur=r.get("title_ur", ""),
            explanation_ur=r.get("explanation_ur", ""),
            explanation_en=r.get("explanation_en", ""),
            examples_json=json.dumps(r.get("examples", []),
                                     ensure_ascii=False),
            is_published=True)
        for e in r.get("exercises", []):
            GrammarExercise.objects.create(
                rule=rule, question=e["question"],
                options_json=json.dumps(e["options"], ensure_ascii=False),
                answer=e["answer"],
                explain_ur=e.get("explain_ur", ""),
                is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("grammar", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
