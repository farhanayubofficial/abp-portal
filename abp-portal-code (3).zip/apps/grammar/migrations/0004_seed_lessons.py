"""Seed book lessons (dialogues + texts) from JSON."""

import json
from pathlib import Path

from django.db import migrations

DATA_FILE = Path(__file__).parent.parent / "data" / "lessons.json"


def seed(apps, schema_editor):
    BookLesson = apps.get_model("grammar", "BookLesson")
    if not DATA_FILE.exists():
        return
    BookLesson.objects.all().delete()
    lessons = json.loads(DATA_FILE.read_text(encoding="utf-8"))
    for l in lessons:
        BookLesson.objects.create(
            book=l["book"], lesson_no=l["lesson_no"],
            title=l.get("title", ""),
            dialogue_json=json.dumps(l.get("dialogue", []),
                                     ensure_ascii=False),
            text=l.get("text", ""),
            is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("grammar", "0003_booklesson")]
    operations = [migrations.RunPython(seed, unseed)]
