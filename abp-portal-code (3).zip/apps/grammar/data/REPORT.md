# Grammar (قواعد) — Content Report

Generated 2026-10-11 for the Arabic Bridge Program portal (Grammar app).

## SET 4: Grammar rules — `rules.json`

| Book | Rules | MCQ exercises | Examples |
|------|-------|---------------|----------|
| Book 1 | 14 | 140 | 64 |
| Book 2 | 14 | 140 | 56 |
| Book 3 | 13 | 130 | 58 |
| **Total** | **41** | **410** | **178** |

- Format per rule: `book`, `lesson_no`, `title_ar`, `title_ur`, `explanation_ur` (Urdu script),
  `explanation_en`, `examples[]` (ar/ur/en), `exercises[]` (10 MCQs: question, 4 options, answer, explain_ur).
- Verified: JSON parses; every exercise has exactly 4 options with `answer` matching one option.
- Book 1 rules: المذكر والمؤنث، أسماء الإشارة، أدوات الاستفهام، الضمائر، حروف الجر، الإضافة، الظرف، النفي، الصفة والموصوف، الأعداد، الماضي، المضارع...
- Book 2 rules: كان وأخواتها، إن وأخواتها، الأفعال الخمسة، الأسماء الخمسة، الممنوع من الصرف، العدد والمعدود، كم، اللازم والمتعدي، المفعول به، الظرف، الحال، التمييز، الجمع...
- Book 3 rules: الشرط، جواب الشرط، الحال، التمييز، المفعول المطلق، المفعول لأجله، المفعول معه، الاستثناء، النداء، التعجب، أفعال المقاربة، الإغراء والتحذير، التوكيد...

### Unsure items
- Lesson numbers are best-effort reconstructions of the Madinah syllabus order, not verified
  against the printed books — FARHAN/teacher should confirm the table of contents mapping.
- All grammar content is standard and correct per the generating agents, but per FARHAN's rule
  ("curriculum stays draft for teacher review"), a teacher skim is recommended before going live.

## SET 5: Book lessons — `lessons.json`

| Book | Lessons |
|------|---------|
| Book 1 | 23 |
| Book 2 | 31 |
| Book 3 | 20 |
| **Total** | **74** |

- Format per lesson: `book`, `lesson_no`, `title`, `dialogue[]` (speaker + Arabic), `text` (main passage).
- **DRAFT — reconstructed from knowledge.** The 3 Madinah PDFs are scanned images with no
  extractable text, so exact as-is extraction was impossible. Dialogues and texts were
  reconstructed from knowledge of the famous books in their style (vowelled Arabic).
- **FARHAN must review against the physical books** before student use. Least-sure items:
  Book 1 lessons 17–23 wording, lesson 23 (revision?) contents; Book 2 lesson ordering and
  lessons 21/23/25/26/30 existence; Book 3 lessons 15, 16, 18–20 (invented-style passages)
  and lessons 21–28 (not covered — worker stopped at 20).
