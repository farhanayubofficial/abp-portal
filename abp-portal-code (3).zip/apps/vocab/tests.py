"""Vocabulary Game tests: 10 levels, meanings only (no typing)."""

import json
from datetime import timedelta

from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps.accounts.models import User
from apps.courses.models import CourseTrack

from .models import GameSession, StudentBadge, VocabWord
from .views import _check_badges, _make_questions


def make_user(email, role=User.ROLE_STUDENT):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class VocabGameTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com")
        self.track = CourseTrack.objects.create(name="Quranic Arabic")
        for i in range(6):
            VocabWord.objects.create(
                arabic=f"كلمة{i}", meaning_en=f"word{i}",
                meaning_ur=f"لفظ{i}", track=self.track,
                level=1, is_published=True)

    def test_home_lists_levels(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("vocab:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 1")
        self.assertContains(r, "Level 10")

    def test_make_questions_no_typing(self):
        qs = _make_questions(self.track, 1, n=4)
        self.assertEqual(len(qs), 4)
        for q in qs:
            self.assertEqual(q["type"], "mcq")
            self.assertEqual(len(q["options"]), 4)
            self.assertIn(q["answer"], q["options"])

    def test_make_questions_needs_4_words(self):
        VocabWord.objects.all().delete()
        VocabWord.objects.create(arabic="واحد", meaning_en="one",
                                 track=self.track, level=1, is_published=True)
        self.assertEqual(_make_questions(self.track, 1), [])

    def test_play_page_loads(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("vocab:play",
                                    args=[self.track.id, 1]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 1")

    def test_play_bad_level_defaults(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("vocab:play",
                                    args=[self.track.id, 99]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 1")

    def test_submit_awards_first_game_badge(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("vocab:submit", args=[self.track.id, 1]),
            json.dumps({"score": 80, "correct": 8, "wrong": 2,
                        "best_streak": 4}),
            content_type="application/json")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["score"], 80)
        self.assertEqual(data["total_points"], 80)
        keys = {b.badge_key for b in
                StudentBadge.objects.filter(student=self.student)}
        self.assertIn("first_game", keys)
        self.assertIn("streak_3", keys)
        self.assertTrue(any(b["name"] == "Pehla Khel"
                            for b in data["new_badges"]))
        self.assertEqual(GameSession.objects.get().level, 1)

    def test_century_badge(self):
        self.client.force_login(self.student)
        self.client.post(
            reverse("vocab:submit", args=[self.track.id, 1]),
            json.dumps({"score": 120, "correct": 10, "wrong": 0,
                        "best_streak": 10}),
            content_type="application/json")
        keys = {b.badge_key for b in
                StudentBadge.objects.filter(student=self.student)}
        self.assertIn("century", keys)

    def test_profile_and_leaderboard(self):
        GameSession.objects.create(
            student=self.student, track=self.track, score=50,
            correct=5, wrong=1)
        self.client.force_login(self.student)
        r = self.client.get(reverse("vocab:profile"))
        self.assertContains(r, "50")
        r = self.client.get(reverse("vocab:leaderboard"))
        self.assertContains(r, "50")

    def test_week_warrior_badge(self):
        for d in range(7):
            s = GameSession.objects.create(
                student=self.student, track=self.track, score=10,
                correct=1, wrong=0)
            s.created_at = timezone.now() - timedelta(days=6-d)
            s.save(update_fields=["created_at"])
        last = GameSession.objects.filter(student=self.student).latest("id")
        new = _check_badges(self.student, last)
        self.assertTrue(any(b["name"] == "Hafta Warrior" for b in new))
