from django.urls import path

from . import views

app_name = "vocab"

urlpatterns = [
    path("", views.game_home, name="home"),
    path("play/<int:track_id>/<int:level>/", views.play, name="play"),
    path("submit/<int:track_id>/<int:level>/", views.submit_game,
         name="submit"),
    path("profile/", views.profile, name="profile"),
    path("leaderboard/", views.leaderboard, name="leaderboard"),
]
