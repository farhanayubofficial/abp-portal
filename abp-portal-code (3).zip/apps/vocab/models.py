"""Vocabulary Game: 10 levels x 100 words, meanings only (no typing).

Quranic Arabic track: Level 1 (easy) -> Level 10 (hard).
Each game: 10 MCQ questions from the level's word pool.
Modes: Asaan (word -> meaning), Darmiyana (meaning -> word).
Points accumulate; badges awarded automatically.
"""

from django.conf import settings
from django.db import models

DIFF_EASY = 1
DIFF_MEDIUM = 2
DIFF_HARD = 3
DIFFICULTY_CHOICES = [
    (DIFF_EASY, "Asaan"),
    (DIFF_MEDIUM, "Darmiyana"),
    (DIFF_HARD, "Mushkil"),
]
POINTS = {DIFF_EASY: 10, DIFF_MEDIUM: 20, DIFF_HARD: 30}

# Badge catalogue: key -> (name, icon, description)
BADGES = {
    "first_game": ("Pehla Khel", "🎯", "Pehli vocabulary game khelein"),
    "streak_3": ("Tez Raftar", "🔥", "Aik game mein 3 lagatar sahi jawab"),
    "century": ("Century", "💯", "Aik game mein 100+ points"),
    "half_century_words": ("50 Alfaz", "📚", "Kul 50 sahi jawab"),
    "week_warrior": ("Hafta Warrior", "⚔️", "7 din lagatar khelein"),
    "quran_scholar": ("Quran Scholar", "📖", "50 Quranic alfaz sahi"),
    "language_star": ("Language Star", "🗣️", "50 Language alfaz sahi"),
}


class VocabWord(models.Model):
    arabic = models.CharField(max_length=100)
    meaning_en = models.CharField(max_length=200)
    meaning_ur = models.CharField(max_length=200, blank=True)
    root_letters = models.CharField(
        max_length=20, blank=True,
        help_text="Root letters for hard mode, e.g. ع ل م")
    example = models.CharField(max_length=300, blank=True)
    track = models.ForeignKey(
        "courses.CourseTrack", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="vocab_words")
    difficulty = models.PositiveSmallIntegerField(
        choices=DIFFICULTY_CHOICES, default=DIFF_EASY)
    level = models.PositiveSmallIntegerField(
        default=1, help_text="1 (easy) to 10 (hard)")
    is_published = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["arabic"]

    def __str__(self):
        return f"{self.arabic} ({self.meaning_en})"


class GameSession(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="vocab_sessions")
    track = models.ForeignKey(
        "courses.CourseTrack", null=True, blank=True,
        on_delete=models.SET_NULL)
    difficulty = models.PositiveSmallIntegerField(
        choices=DIFFICULTY_CHOICES, default=DIFF_EASY)
    level = models.PositiveSmallIntegerField(default=1)
    score = models.PositiveIntegerField(default=0)
    correct = models.PositiveIntegerField(default=0)
    wrong = models.PositiveIntegerField(default=0)
    best_streak = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — {self.score} pts"


class StudentBadge(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="vocab_badges")
    badge_key = models.CharField(max_length=50)
    awarded_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [("student", "badge_key")]
        ordering = ["-awarded_at"]

    def __str__(self):
        return f"{self.student} — {self.badge_key}"

    @property
    def info(self):
        return BADGES.get(self.badge_key, (self.badge_key, "🏅", ""))
