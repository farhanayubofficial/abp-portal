"""Seed 1000 Quranic vocab words (10 levels x 100) from JSON files."""

import json
from pathlib import Path

from django.db import migrations

DATA_DIR = Path(__file__).parent.parent / "data" / "levels"


def seed(apps, schema_editor):
    VocabWord = apps.get_model("vocab", "VocabWord")
    CourseTrack = apps.get_model("courses", "CourseTrack")
    try:
        track = CourseTrack.objects.get(name="Quranic Arabic")
    except CourseTrack.DoesNotExist:
        return
    # clear old seeded words for clean re-seed
    VocabWord.objects.filter(track=track).delete()
    for lv in range(1, 11):
        path = DATA_DIR / f"level_{lv}.json"
        if not path.exists():
            continue
        words = json.loads(path.read_text(encoding="utf-8"))
        for w in words:
            VocabWord.objects.create(
                arabic=w["arabic"], meaning_en=w["english"],
                meaning_ur=w.get("urdu", ""), track=track,
                level=lv, is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("vocab", "0003_gamesession_level_vocabword_level")]
    operations = [migrations.RunPython(seed, unseed)]
