"""Snake Levels Game: 10 levels, no-repeat sentence pools."""

import json
import random

from django.contrib.auth.decorators import login_required
from django.db.models import Max
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import KIND_LANG, KIND_QURAN, KINDS, SnakeRun, SnakeSentence

VALID_KINDS = (KIND_LANG, KIND_QURAN)


def _pick_sentence(user, kind, level):
    """Random sentence from the level pool, excluding already-played ones.
    Pool resets only when exhausted (no repeats until then)."""
    used = SnakeRun.objects.filter(
        student=user, kind=kind, level=level
    ).values_list("sentence_id", flat=True)
    pool = list(SnakeSentence.objects.filter(
        kind=kind, level=level, is_active=True).exclude(id__in=used))
    if not pool:
        pool = list(SnakeSentence.objects.filter(
            kind=kind, level=level, is_active=True))
    if not pool:
        return None
    return random.choice(pool)


@login_required
def home(request):
    levels = []
    for lvl in range(1, 11):
        row = {"n": lvl, "tracks": {}}
        for kind, _label in KINDS:
            best = SnakeRun.objects.filter(
                student=request.user, kind=kind, level=lvl
            ).aggregate(b=Max("score"))["b"] or 0
            count = SnakeSentence.objects.filter(
                kind=kind, level=lvl, is_active=True).count()
            row["tracks"][kind] = {"best": best, "count": count}
        levels.append(row)
    return render(request, "snake/home.html",
                  {"levels": levels, "kinds": KINDS})


@login_required
def play(request, kind, level):
    if kind not in VALID_KINDS or not 1 <= level <= 10:
        return redirect("snake:home")
    sentence = _pick_sentence(request.user, kind, level)
    if not sentence:
        return render(request, "snake/home.html",
                      {"levels": [], "kinds": KINDS,
                       "error": "Is level ke liye jumle nahi mile."})
    words = sentence.words()
    scrambled = words[:]
    for _ in range(12):
        random.shuffle(scrambled)
        if scrambled != words or len(words) < 2:
            break
    speed = max(200, 420 - level * 22)  # slow & comfortable for kids
    from django.urls import reverse
    next_url = reverse("snake:play", args=[kind, level + 1]) if level < 10 else ""
    return render(request, "snake/play.html", {
        "kind": kind, "level": level, "sentence": sentence,
        "words_json": json.dumps(words, ensure_ascii=False),
        "speed": speed, "next_url": next_url,
    })


@login_required
@require_POST
def submit(request, kind, level):
    if kind not in VALID_KINDS or not 1 <= level <= 10:
        return JsonResponse({"ok": False}, status=400)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False}, status=400)
    sentence = get_object_or_404(SnakeSentence, pk=data.get("sentence_id"))
    if sentence.kind != kind or sentence.level != level:
        return JsonResponse({"ok": False}, status=400)
    # cap: 30 pts/word + level bonus, sanity ceiling
    ceiling = len(sentence.words()) * 30 + 200
    score = max(0, min(int(data.get("score", 0) or 0), ceiling))
    run = SnakeRun.objects.create(
        student=request.user, kind=kind, level=level, sentence=sentence,
        score=score, completed=bool(data.get("completed", False)))
    best = SnakeRun.objects.filter(
        student=request.user, kind=kind, level=level
    ).aggregate(b=Max("score"))["b"] or 0
    return JsonResponse({"ok": True, "best": best, "id": run.id})
