"""Tilawat Practice views."""

import json

from django.contrib.auth.decorators import login_required
from django.db.models import Count, Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.models import User
from apps.maze import quran

from .models import TilawatResult, TilawatSession
from .translations import get_translation

TEACHER_ROLES = (User.ROLE_ADMIN, User.ROLE_TEACHER)


def _is_teacher(user):
    return (user.is_authenticated
            and (user.is_superuser or user.role in TEACHER_ROLES))


@login_required
def home(request):
    if _is_teacher(request.user):
        sessions = TilawatSession.objects.filter(created_by=request.user)
        return render(request, "tilawat/teacher_home.html",
                      {"sessions": sessions})
    assigned = TilawatSession.objects.filter(
        students=request.user, is_active=True)
    return render(request, "tilawat/student_home.html",
                  {"assigned": assigned})


@login_required
def create(request):
    if not _is_teacher(request.user):
        return redirect("tilawat:home")
    if request.method == "POST":
        surah = int(request.POST.get("surah") or 0)
        a_from = int(request.POST.get("ayat_from") or 0)
        a_to = int(request.POST.get("ayat_to") or 0)
        s = quran.surah(surah)
        if not s or not (1 <= a_from <= a_to <= len(s["verses"])):
            return redirect("tilawat:create")
        sess = TilawatSession.objects.create(
            surah_number=surah, ayat_from=a_from, ayat_to=a_to,
            total_marks=int(request.POST.get("total_marks") or 20),
            created_by=request.user)
        ids = request.POST.getlist("students")
        if ids:
            sess.students.set(User.objects.filter(
                id__in=ids, role=User.ROLE_STUDENT))
        return redirect("tilawat:detail", pk=sess.pk)
    students = User.objects.filter(
        role=User.ROLE_STUDENT, is_active=True).order_by("first_name")
    return render(request, "tilawat/create.html",
                  {"surahs": quran.surah_list(), "students": students})


@login_required
def detail(request, pk):
    sess = get_object_or_404(TilawatSession, pk=pk)
    if not _is_teacher(request.user) or sess.created_by != request.user:
        return redirect("tilawat:home")
    results = sess.results.select_related("student")
    totals = (results.values("student__email", "student__first_name",
                             "student__last_name")
              .annotate(total=Sum("score"), done=Count("id")))
    return render(request, "tilawat/detail.html",
                  {"sess": sess, "results": results, "totals": totals})


@login_required
@require_POST
def toggle_active(request, pk):
    sess = get_object_or_404(TilawatSession, pk=pk)
    if _is_teacher(request.user) and sess.created_by == request.user:
        sess.is_active = not sess.is_active
        sess.save()
    return redirect("tilawat:detail", pk=pk)


@login_required
def practice(request, pk):
    sess = get_object_or_404(TilawatSession, pk=pk, is_active=True)
    if request.user not in sess.students.all():
        return redirect("tilawat:home")
    ayahs = []
    for an in sess.ayat_numbers():
        words = quran.ayah_words(sess.surah_number, an)
        ayahs.append({
            "n": an,
            "words": words,
            "audio": quran.qari_audio_url(sess.surah_number, an),
            "en": get_translation(sess.surah_number, an, "en"),
            "ur": get_translation(sess.surah_number, an, "ur"),
        })
    done = {r.ayat_number: r for r in TilawatResult.objects.filter(
        student=request.user, session=sess)}
    total = sum(r.score for r in done.values())
    if request.method == "POST":
        try:
            data = json.loads(request.body.decode("utf-8") or "{}")
        except Exception:
            return JsonResponse({"ok": False}, status=400)
        an = int(data.get("ayat") or 0)
        if an not in sess.ayat_numbers():
            return JsonResponse({"ok": False}, status=400)
        mistakes = max(0, int(data.get("mistakes", 0) or 0))
        score = max(0.0, sess.marks_per_ayat() - mistakes)
        TilawatResult.objects.update_or_create(
            student=request.user, session=sess, ayat_number=an,
            defaults={"mistakes": mistakes, "score": score,
                      "completed_at": timezone.now()})
        new_total = TilawatResult.objects.filter(
            student=request.user, session=sess).aggregate(
            s=Sum("score"))["s"] or 0
        return JsonResponse({"ok": True, "ayat_score": score,
                             "total": new_total})
    s = quran.surah(sess.surah_number)
    return render(request, "tilawat/practice.html", {
        "sess": sess, "surah_name": s["name"] if s else "",
        "ayahs_json": json.dumps(ayahs, ensure_ascii=False),
        "done_map_json": json.dumps(
            {str(k): {"mistakes": v.mistakes, "score": v.score}
             for k, v in done.items()}),
        "total": total,
        "per_ayat": sess.marks_per_ayat(),
    })
