"""Views for accounts. Permissions are enforced server-side on every view."""
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db.models import Sum
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy
from django.views.generic import CreateView, ListView, TemplateView

from .forms import ApplicationForm
from .models import Application, AuditLog, log_action
from .services import approve_application, reject_application


def is_admin(user):
    return user.is_authenticated and user.is_admin


class AdminRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        return is_admin(self.request.user)


class ApplicationCreateView(CreateView):
    """Public registration application. No account is created at this step."""

    model = Application
    form_class = ApplicationForm
    template_name = "accounts/apply.html"
    success_url = reverse_lazy("apply_success")


class ApplicationSuccessView(TemplateView):
    template_name = "accounts/apply_success.html"


class DashboardView(LoginRequiredMixin, TemplateView):
    """Role-specific dashboard (Phase 1: overview cards; features per phase)."""

    def get_template_names(self):
        user = self.request.user
        role = user.role
        # superuser with empty role (e.g. created via createsuperuser)
        # must land on the admin dashboard, not a 404
        if role not in ("admin", "teacher", "student", "guardian"):
            role = "admin" if (user.is_superuser or user.is_admin) else "student"
        return [f"accounts/dashboard_{role}.html"]

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        if user.is_admin:
            ctx["pending_applications"] = Application.objects.filter(
                status=Application.STATUS_PENDING
            ).count()
            ctx["recent_audit"] = AuditLog.objects.all()[:10]
        # Phase 4: upcoming live classes for every role
        from apps.classes.models import LiveClass
        from django.utils import timezone
        ctx["upcoming_classes"] = (
            LiveClass.objects.filter(
                scheduled_at__gte=timezone.now(),
                status__in=[LiveClass.STATUS_SCHEDULED, LiveClass.STATUS_LIVE],
            )
            .select_related("track", "teacher")
            .order_by("scheduled_at")[:5]
        )
        # Phase 5: homework widgets
        from apps.homework.models import Homework, Submission
        if user.is_teacher or user.is_admin:
            ctx["homework_to_grade"] = (
                Submission.objects.filter(status=Submission.STATUS_SUBMITTED)
                .select_related("homework", "student")
                .order_by("-submitted_at")[:5]
            )
        else:
            try:
                tracks = user.student_profile.tracks.all()
            except Exception:
                tracks = []
            submitted_ids = Submission.objects.filter(student=user).values_list(
                "homework_id", flat=True
            )
            qs = Homework.objects.filter(status=Homework.STATUS_PUBLISHED)
            if tracks:
                qs = qs.filter(track__in=tracks)
            ctx["pending_homework"] = qs.exclude(pk__in=submitted_ids).order_by("-created_at")[:5]
        # Phase 6: fees widgets
        from apps.fees.models import Invoice as FeeInvoice, Payment as FeePayment
        if user.is_admin:
            ctx["fee_overdue_count"] = FeeInvoice.objects.filter(
                status=FeeInvoice.STATUS_UNPAID, due_date__lt=timezone.now().date()
            ).count()
            start = timezone.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            ctx["fee_collected_pkr"] = (
                FeePayment.objects.filter(paid_at__gte=start, currency="PKR")
                .aggregate(t=Sum("amount"))["t"]
                or 0
            )
        elif not (user.is_teacher or user.is_admin):
            ctx["my_unpaid_fees"] = FeeInvoice.objects.filter(
                student=user, status=FeeInvoice.STATUS_UNPAID
            ).order_by("due_date")[:5]
        return ctx


class ApplicationListView(AdminRequiredMixin, ListView):
    model = Application
    template_name = "accounts/application_list.html"
    context_object_name = "applications"
    paginate_by = 25


@user_passes_test(is_admin)
def application_approve(request, pk):
    app = get_object_or_404(Application, pk=pk, status=Application.STATUS_PENDING)
    if request.method == "POST":
        user, profile, raw_password = approve_application(app, request.user)
        return render(
            request,
            "accounts/application_approved.html",
            {"application": app, "profile": profile, "raw_password": raw_password},
        )
    return render(request, "accounts/application_confirm_approve.html", {"application": app})


@user_passes_test(is_admin)
def application_reject(request, pk):
    app = get_object_or_404(Application, pk=pk, status=Application.STATUS_PENDING)
    if request.method == "POST":
        notes = request.POST.get("notes", "")
        reject_application(app, request.user, notes)
        return redirect("application_list")
    return render(request, "accounts/application_confirm_reject.html", {"application": app})
