"""Load book lessons + exercises from apps/courses/data/books/*.json.

Usage: python manage.py load_book_lessons [--book slug]
Idempotent: re-running updates existing lessons matched by (book, order).
"""
import json
from pathlib import Path

from django.core.management.base import BaseCommand
from django.db import transaction

from apps.courses.models import Book, Exercise, Lesson


DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data" / "books"


def match_book(book_label):
    """Fuzzy-match a JSON book label to a Book record."""
    label = book_label.strip()
    for b in Book.objects.all():
        if b.title.strip() == label:
            return b
    # fallback: partial match on first distinctive word
    for b in Book.objects.all():
        if label[:8] in b.title or b.title[:8] in label:
            return b
    return None


class Command(BaseCommand):
    help = "Load book lessons + exercises from JSON data files."

    def add_arguments(self, parser):
        parser.add_argument("--book", default="", help="Only load this slug (filename without .json)")

    @transaction.atomic
    def handle(self, *args, **opts):
        only = opts["book"]
        files = sorted(DATA_DIR.glob("*.json"))
        if only:
            files = [f for f in files if f.stem == only]
        total_lessons = total_ex = 0
        for fp in files:
            data = json.loads(fp.read_text(encoding="utf-8"))
            book = match_book(data["book"])
            if not book:
                self.stdout.write(self.style.WARNING(f"SKIP {fp.name}: no Book matches '{data['book']}'"))
                continue
            for ld in data.get("lessons", []):
                content = ld.get("content", "")
                if ld.get("title_ar"):
                    content = ld["title_ar"] + "\n\n" + content
                # Replace any old lesson at this (book, order) — the new
                # book-faithful content supersedes the old curriculum.
                Lesson.objects.filter(book=book, order=ld["number"]).delete()
                lesson = Lesson.objects.create(
                    book=book,
                    order=ld["number"],
                    track=book.track,
                    title=ld.get("title", f"Lesson {ld['number']}"),
                    content=content,
                    summary=ld.get("summary", ""),
                    homework=ld.get("homework", ""),
                    source_reference=f"{book.title} — سبق {ld['number']}",
                    status=Lesson.STATUS_DRAFT,
                )
                for i, ed in enumerate(ld.get("exercises", []), start=1):
                    Exercise.objects.create(
                        lesson=lesson,
                        question_type=ed.get("type", "mcq"),
                        question=ed.get("question", ""),
                        options=ed.get("options", []),
                        correct_answer=ed.get("correct_answer", ""),
                        model_answer=ed.get("model_answer", ""),
                        explanation=ed.get("explanation", ""),
                        sentence_ar=ed.get("sentence_ar", ""),
                        sentence_ur=ed.get("sentence_ur", ""),
                        sentence_en=ed.get("sentence_en", ""),
                        difficulty=max(1, min(10, int(ed.get("difficulty", 1)))),
                        order=i,
                    )
                    total_ex += 1
                total_lessons += 1
            self.stdout.write(self.style.SUCCESS(f"OK {fp.name}: {book.title}"))
        self.stdout.write(self.style.SUCCESS(f"DONE: {total_lessons} lessons, {total_ex} exercises"))
