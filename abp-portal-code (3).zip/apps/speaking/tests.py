"""Speaking Videos tests (Phase 11)."""

from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import SpeakingSubmission, this_week_monday


def make_user(email, role):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class SpeakingTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com", User.ROLE_STUDENT)
        self.teacher = make_user("t@x.com", User.ROLE_TEACHER)

    def test_submit_youtube_link(self):
        self.client.force_login(self.student)
        r = self.client.post(reverse("speaking:submit"), {
            "title": "Meri pehli guftagu",
            "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
        })
        self.assertEqual(r.status_code, 302)
        sub = SpeakingSubmission.objects.get()
        self.assertEqual(sub.student, self.student)
        self.assertEqual(sub.youtube_embed_id(), "dQw4w9WgXcQ")
        self.assertEqual(sub.week_start, this_week_monday())

    def test_submit_requires_media(self):
        self.client.force_login(self.student)
        r = self.client.post(reverse("speaking:submit"), {"title": "Khali"})
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Video record karein")
        self.assertEqual(SpeakingSubmission.objects.count(), 0)

    def test_submit_audio_upload(self):
        self.client.force_login(self.student)
        audio = SimpleUploadedFile("test.mp3", b"fake-audio", "audio/mpeg")
        r = self.client.post(reverse("speaking:submit"),
                             {"title": "Audio", "audio_file": audio})
        self.assertEqual(r.status_code, 302)
        sub = SpeakingSubmission.objects.get()
        self.assertTrue(sub.audio_file)

    def test_weekly_status(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("speaking:my_videos"))
        self.assertContains(r, "baqi hai")  # nothing submitted yet
        SpeakingSubmission.objects.create(
            student=self.student, title="W1",
            youtube_url="https://youtu.be/dQw4w9WgXcQ")
        r = self.client.get(reverse("speaking:my_videos"))
        self.assertContains(r, "ho gayi")

    def test_teacher_review_and_feedback(self):
        sub = SpeakingSubmission.objects.create(
            student=self.student, title="W1",
            youtube_url="https://youtu.be/dQw4w9WgXcQ")
        # student cannot open review page
        self.client.force_login(self.student)
        r = self.client.get(reverse("speaking:teacher_list"))
        self.assertEqual(r.status_code, 302)
        # teacher can
        self.client.force_login(self.teacher)
        r = self.client.get(reverse("speaking:teacher_list"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "W1")
        # feedback
        r = self.client.post(reverse("speaking:feedback", args=[sub.pk]),
                             {"teacher_feedback": "Bohat khoob!"})
        self.assertEqual(r.status_code, 302)
        sub.refresh_from_db()
        self.assertEqual(sub.teacher_feedback, "Bohat khoob!")
        self.assertIsNotNone(sub.feedback_at)

    def test_owner_can_delete_own_video(self):
        from .models import SpeakingSubmission
        sub = SpeakingSubmission.objects.create(
            student=self.student, title="t",
            youtube_url="https://youtube.com/watch?v=dQw4w9WgXcQ")
        self.client.force_login(self.student)
        r = self.client.post(reverse("speaking:delete", args=[sub.pk]))
        self.assertEqual(r.status_code, 302)
        self.assertFalse(SpeakingSubmission.objects.filter(pk=sub.pk).exists())

    def test_stranger_cannot_delete(self):
        from .models import SpeakingSubmission
        from apps.accounts.models import User
        other = User.objects.create_user(
            email="o@x.com", password="x", first_name="O", last_name="T",
            role=User.ROLE_STUDENT)
        sub = SpeakingSubmission.objects.create(
            student=other, title="t",
            youtube_url="https://youtube.com/watch?v=dQw4w9WgXcQ")
        self.client.force_login(self.student)
        r = self.client.post(reverse("speaking:delete", args=[sub.pk]))
        self.assertEqual(r.status_code, 302)
        self.assertTrue(SpeakingSubmission.objects.filter(pk=sub.pk).exists())
