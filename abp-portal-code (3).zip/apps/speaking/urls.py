from django.urls import path

from . import views

app_name = "speaking"

urlpatterns = [
    path("", views.my_videos, name="my_videos"),
    path("submit/", views.submit, name="submit"),
    path("review/", views.teacher_list, name="teacher_list"),
    path("<int:pk>/feedback/", views.give_feedback, name="feedback"),
    path("<int:pk>/delete/", views.delete_video, name="delete"),
]
