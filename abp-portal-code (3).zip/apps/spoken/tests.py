"""Spoken Arabic tests."""

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import SpokenLine, SpokenSession


class SpokenTests(TestCase):
    def setUp(self):
        SpokenLine.objects.all().delete()  # isolate from seed migration data
        self.student = User.objects.create_user(
            email="sp@x.com", password="x", first_name="S",
            last_name="T", role=User.ROLE_STUDENT)
        for i in range(3):
            SpokenLine.objects.create(
                level=1, order=i, role="student" if i % 2 == 0 else "computer",
                arabic=f"جملة {i}", urdu=f"اردو {i}", english=f"English {i}")

    def test_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("spoken:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 1")

    def test_practice(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("spoken:practice", args=[1]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Suno")

    def test_practice_empty_level_redirects(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("spoken:practice", args=[9]))
        self.assertEqual(r.status_code, 302)

    def test_complete_post(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("spoken:practice", args=[1]),
            '{"lines_done": 3, "completed": true}',
            content_type="application/json")
        self.assertTrue(r.json()["ok"])
        self.assertTrue(SpokenSession.objects.get().completed)

    def test_bad_level_redirects(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("spoken:practice", args=[99]))
        self.assertEqual(r.status_code, 302)
