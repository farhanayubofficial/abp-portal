# Spoken Arabic Conversations — Content Report

Generated 2026-10-11 for the Arabic Bridge Program portal (Speaking practice game).

## Counts

| File | Lines | student | computer |
|------|-------|---------|----------|
| level_1.json | 100 | 50 | 50 |
| level_2.json | 100 | 50 | 50 |
| level_3.json | 100 | 50 | 50 |
| level_4.json | 100 | 50 | 50 |
| level_5.json | 100 | 50 | 50 |
| level_6.json | 100 | 50 | 50 |
| level_7.json | 100 | 50 | 50 |
| level_8.json | 100 | 50 | 50 |
| level_9.json | 100 | 50 | 50 |
| level_10.json | 100 | 50 | 50 |
| **Total** | **1000** | **500** | **500** |

## Topics by level

- L1: greetings & introductions
- L2: family & home
- L3: daily routine & time
- L4: food & meals
- L5: work & study
- L6: travel & transport
- L7: health & body
- L8: work life (deeper)
- L9: opinions & society
- L10: complex discussions (environment, future, abstract topics)

## Verification

- Every file parses as JSON; exactly 100 entries per file; all fields (`arabic`, `urdu`, `english`, `role`) non-empty.
- Exactly 50 `student` + 50 `computer` lines per file, strictly alternating.
- Zero duplicate Arabic lines across all 10 files (checked with diacritic/whitespace normalization).
- Urdu translations are in Urdu script; English translations are natural.

## Fixes applied during assembly

Three cross-file duplicate lines were found and replaced with context-fitting alternatives (duplicate kept in the lower level):
- L8#11 "نعم، أحب عملي كثيرًا." → "نعم، أستمتع به كل يوم." (dup of L1#31)
- L4#44 "من يطبخ في بيتكم؟" → "هل طعام البيت لذيذ؟" (dup of L2#58)
- L6#22 "كم تستغرق الرحلة؟" → "كم مدة الطيران؟" (dup of L3#16)

## Unsure items / caveats

- L5 line 89 (original numbering): phrasing flagged by the generating agent as slightly odd; meaning is clear.
- L7–L8: some student lines use masculine Urdu verb forms (e.g. "ہوتا ہوں"); acceptable for a generic learner voice but could be neutralized later.
- Content draws from Madinah Book 1–3 style plus original material, per FARHAN's approval for out-of-book content. Tafsir content was skipped per his order.
