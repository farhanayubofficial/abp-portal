"""Spoken Arabic: 10 levels x 100 conversation lines.

Two-person dialogues (computer <-> student). Every line has Arabic +
Urdu + English + TTS voice. Student practices their lines with the mic.
"""

from django.conf import settings
from django.db import models

ROLE_CHOICES = [
    ("student", "Student"),
    ("computer", "Computer"),
]


class SpokenLine(models.Model):
    level = models.PositiveSmallIntegerField(
        help_text="1 (easy) to 10 (hard)")
    order = models.PositiveIntegerField(default=0)
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    arabic = models.CharField(max_length=500)
    urdu = models.CharField(max_length=500, blank=True)
    english = models.CharField(max_length=500, blank=True)
    is_published = models.BooleanField(default=True)

    class Meta:
        ordering = ["level", "order"]
        unique_together = ("level", "order")

    def __str__(self):
        return f"L{self.level} #{self.order} [{self.role}] {self.arabic[:40]}"


class SpokenSession(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="spoken_sessions")
    level = models.PositiveSmallIntegerField()
    lines_done = models.PositiveIntegerField(default=0)
    completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — Spoken L{self.level}"
