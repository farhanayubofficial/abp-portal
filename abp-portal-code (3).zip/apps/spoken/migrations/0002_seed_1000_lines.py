"""Seed 1000 spoken conversation lines (10 levels x 100) from JSON files."""

import json
from pathlib import Path

from django.db import migrations

DATA_DIR = Path(__file__).parent.parent / "data" / "levels"


def seed(apps, schema_editor):
    SpokenLine = apps.get_model("spoken", "SpokenLine")
    SpokenLine.objects.all().delete()
    for lv in range(1, 11):
        path = DATA_DIR / f"level_{lv}.json"
        if not path.exists():
            continue
        lines = json.loads(path.read_text(encoding="utf-8"))
        for i, l in enumerate(lines):
            SpokenLine.objects.create(
                level=lv, order=i, role=l["role"],
                arabic=l["arabic"], urdu=l.get("urdu", ""),
                english=l.get("english", ""), is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("spoken", "0001_initial")]
    operations = [migrations.RunPython(seed, unseed)]
