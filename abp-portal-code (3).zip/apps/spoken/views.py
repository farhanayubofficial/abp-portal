"""Spoken Arabic views: 10 levels of conversation practice."""

import json

from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import SpokenLine, SpokenSession


@login_required
def home(request):
    levels = []
    for lv in range(1, 11):
        levels.append({
            "n": lv,
            "count": SpokenLine.objects.filter(
                level=lv, is_published=True).count(),
            "done": SpokenSession.objects.filter(
                student=request.user, level=lv, completed=True).exists(),
        })
    return render(request, "spoken/home.html", {"levels": levels})


@login_required
def practice(request, level):
    level = int(level)
    if not 1 <= level <= 10:
        return redirect("spoken:home")
    lines = list(SpokenLine.objects.filter(
        level=level, is_published=True).order_by("order"))
    if not lines:
        return redirect("spoken:home")
    data = [{"arabic": l.arabic, "urdu": l.urdu, "english": l.english,
             "role": l.role} for l in lines]
    if request.method == "POST":
        try:
            payload = json.loads(request.body.decode("utf-8") or "{}")
        except Exception:
            return JsonResponse({"ok": False}, status=400)
        SpokenSession.objects.create(
            student=request.user, level=level,
            lines_done=int(payload.get("lines_done", 0) or 0),
            completed=bool(payload.get("completed", False)))
        return JsonResponse({"ok": True})
    return render(request, "spoken/practice.html", {
        "level": level,
        "lines_json": json.dumps(data, ensure_ascii=False),
        "total": len(lines),
    })
