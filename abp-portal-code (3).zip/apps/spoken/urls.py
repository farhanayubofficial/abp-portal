from django.urls import path

from . import views

app_name = "spoken"

urlpatterns = [
    path("", views.home, name="home"),
    path("practice/<int:level>/", views.practice, name="practice"),
]
