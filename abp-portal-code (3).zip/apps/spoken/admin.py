from django.contrib import admin

from .models import SpokenLine, SpokenSession


@admin.register(SpokenLine)
class SpokenLineAdmin(admin.ModelAdmin):
    list_display = ("level", "order", "role", "__str__")
    list_filter = ("level", "role")


@admin.register(SpokenSession)
class SpokenSessionAdmin(admin.ModelAdmin):
    list_display = ("student", "level", "completed", "created_at")
