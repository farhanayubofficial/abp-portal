"""Reseed Reading Lab passages from updated JSON (1000 passages).

Updates existing passages in place (preserving IDs and student attempts);
creates any missing ones. Safe to run on live DB.
"""

import json
from pathlib import Path

from django.db import migrations

DATA_DIR = Path(__file__).parent.parent / "data" / "levels"


def reseed(apps, schema_editor):
    ReadingPassage = apps.get_model("reading", "ReadingPassage")
    for lv in range(1, 11):
        path = DATA_DIR / f"level_{lv}.json"
        if not path.exists():
            continue
        items = json.loads(path.read_text(encoding="utf-8"))
        existing = list(
            ReadingPassage.objects.filter(level=lv).order_by("id"))
        for i, it in enumerate(items, 1):
            title = f"Level {lv} — Ibarat {i}"
            if i <= len(existing):
                p = existing[i - 1]
                p.title = title
                p.arabic_text = it["arabic"]
                p.english_translation = it.get("english", "")
                p.total_marks = 10
                p.marks_per_mistake = 1
                p.is_published = True
                p.save()
            else:
                ReadingPassage.objects.create(
                    title=title,
                    arabic_text=it["arabic"],
                    english_translation=it.get("english", ""),
                    total_marks=10, marks_per_mistake=1,
                    level=lv, is_published=True)
        # remove extras beyond 100 (should not happen)
        for p in existing[len(items):]:
            p.delete()


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("reading", "0005_seed_1000_reading")]
    operations = [migrations.RunPython(reseed, unseed)]
