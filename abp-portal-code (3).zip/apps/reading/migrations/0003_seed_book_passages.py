"""Seed book-style reading passages (Qiraat ar-Rashida lessons, reconstructed).

NOTE: The book PDF is scanned (no extractable text). These passages are
reconstructed from the book's lesson themes — FARHAN should verify
against the physical book.
"""

from django.db import migrations


PASSAGES = [
    {
        "title": "في المدرسة",
        "arabic_text": "أذهب إلى المدرسة كل صباح. أتعلم فيها القراءة والكتابة والحساب. معلمي طيب ويحب التلاميذ. أحب مدرستي كثيرا.",
        "english_translation": "I go to school every morning. I learn reading, writing and arithmetic there. My teacher is kind and loves the pupils. I love my school very much.",
    },
    {
        "title": "أسرتي",
        "arabic_text": "أسرتي صغيرة وجميلة. أبي يعمل في المصنع. أمي تطبخ الطعام اللذيذ. لي أخ وأخت نلعب معا في المساء.",
        "english_translation": "My family is small and beautiful. My father works in the factory. My mother cooks delicious food. I have a brother and a sister; we play together in the evening.",
    },
    {
        "title": "في الحديقة",
        "arabic_text": "الحديقة واسعة وجميلة. فيها أشجار خضراء وأزهار ملونة. العصافير تغرد على الأغصان. نلعب في الحديقة بعد العصر.",
        "english_translation": "The garden is wide and beautiful. In it are green trees and colourful flowers. The birds sing on the branches. We play in the garden after Asr.",
    },
    {
        "title": "يوم الجمعة",
        "arabic_text": "يوم الجمعة يوم مبارك. نغتسل ونلبس أحسن الثياب. نذهب إلى المسجد لصلاة الجمعة. بعد الصلاة نجتمع مع الأهل على الغداء.",
        "english_translation": "Friday is a blessed day. We bathe and wear our best clothes. We go to the mosque for Jumuah prayer. After prayer we gather with family for lunch.",
    },
    {
        "title": "في السوق",
        "arabic_text": "ذهبت مع أبي إلى السوق. السوق مزدحم بالناس. اشترينا الخضار والفواكه الطازجة. البائع أمين وصادق في البيع.",
        "english_translation": "I went with my father to the market. The market is crowded with people. We bought fresh vegetables and fruits. The seller is honest and truthful in selling.",
    },
    {
        "title": "شهر رمضان",
        "arabic_text": "شهر رمضان شهر الصيام والقيام. نصوم النهار ونفطر عند الغروب. نقرأ القرآن ونصلي التراويح. في آخره عيد الفطر نفرح به جميعا.",
        "english_translation": "Ramadan is the month of fasting and night prayer. We fast the day and break fast at sunset. We read the Quran and pray Taraweeh. At its end is Eid al-Fitr, in which we all rejoice.",
    },
    {
        "title": "الصديق الوفي",
        "arabic_text": "الصديق الوفي كنز عظيم. يقف معك في الشدة والرخاء. ينصحك بالخير ويبعدك عن الشر. اختر صديقك كما تختار ثوبك.",
        "english_translation": "A loyal friend is a great treasure. He stands with you in hardship and ease. He advises you to good and keeps you from evil. Choose your friend as you choose your garment.",
    },
    {
        "title": "العمل عبادة",
        "arabic_text": "العمل عبادة وشرف للإنسان. الفلاح يزرع الأرض ويحصد الثمر. الصانع يصنع ما ينفع الناس. من عمل بجد نال النجاح في الدنيا والآخرة.",
        "english_translation": "Work is worship and honour for man. The farmer cultivates the land and harvests the fruit. The craftsman makes what benefits people. Whoever works hard attains success in this world and the next.",
    },
    {
        "title": "نظافة البدن",
        "arabic_text": "النظافة من الإيمان. نغسل أيدينا قبل الطعام وبعده. ننظف أسناننا كل صباح ومساء. الجسم النظيف يحمي من الأمراض.",
        "english_translation": "Cleanliness is part of faith. We wash our hands before food and after it. We clean our teeth every morning and evening. A clean body protects from diseases.",
    },
    {
        "title": "العلم نور",
        "arabic_text": "العلم نور يهدي صاحبه إلى الخير. طالب العلم يجد ويجتهد في دروسه. يحترم معلمه ويحب زملاءه. بالعلم ترقى الأمم وتسعد الشعوب.",
        "english_translation": "Knowledge is a light guiding its owner to good. The student strives hard in his lessons. He respects his teacher and loves his classmates. With knowledge nations rise and peoples prosper.",
    },
]


def seed(apps, schema_editor):
    ReadingPassage = apps.get_model("reading", "ReadingPassage")
    for p in PASSAGES:
        ReadingPassage.objects.get_or_create(
            title=p["title"],
            defaults={
                "arabic_text": p["arabic_text"],
                "english_translation": p["english_translation"],
                "total_marks": 20,
                "marks_per_mistake": 1,
                "is_published": True,
            },
        )


class Migration(migrations.Migration):
    dependencies = [("reading", "0002_seed_passages")]
    operations = [migrations.RunPython(seed, migrations.RunPython.noop)]
