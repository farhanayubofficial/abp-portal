"""Seed 1000 reading sentences (10 levels x 100) from JSON files."""

import json
from pathlib import Path

from django.db import migrations

DATA_DIR = Path(__file__).parent.parent / "data" / "levels"


def seed(apps, schema_editor):
    ReadingPassage = apps.get_model("reading", "ReadingPassage")
    # clear old generic passages; keep nothing (fresh level-based set)
    ReadingPassage.objects.all().delete()
    for lv in range(1, 11):
        path = DATA_DIR / f"level_{lv}.json"
        if not path.exists():
            continue
        items = json.loads(path.read_text(encoding="utf-8"))
        for i, it in enumerate(items, 1):
            ReadingPassage.objects.create(
                title=f"Level {lv} — Ibarat {i}",
                arabic_text=it["arabic"],
                english_translation=it.get("english", ""),
                total_marks=10, marks_per_mistake=1,
                level=lv, is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("reading", "0004_readingpassage_level")]
    operations = [migrations.RunPython(seed, unseed)]
