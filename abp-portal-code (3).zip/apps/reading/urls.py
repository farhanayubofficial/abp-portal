from django.urls import path

from . import views

app_name = "reading"

urlpatterns = [
    path("", views.passage_list, name="list"),
    path("level/<int:level>/", views.play_level, name="play_level"),
    path("<int:pk>/practice/", views.practice, name="practice"),
    path("<int:pk>/submit/", views.submit_attempt, name="submit"),
    path("report/", views.teacher_report, name="report"),
]
