# Reading Lab — Content Report

1000 read-aloud practice sentences, 10 levels × 100. Generated 2026-10-11
by 3 parallel workers, verified programmatically.

## Counts
| Level | Sentences | Word band | Focus |
|-------|-----------|-----------|-------|
| 1 | 100 | 2–4 | Ultra-common vocab (school, home, هذا/هذه) |
| 2 | 100 | 3–5 | Daily life: family, morning, animals |
| 3 | 100 | 4–6 | Mosque, garden, simple Islamic themes |
| 4 | 100 | 5–7 | Market, guests, weather, mosque |
| 5 | 100 | 6–8 | Connectors (ثم، بعد ذلك، لأن) + past tense |
| 6 | 100 | 7–9 | Moral/educational: honesty, Ramadan, manners |
| 7 | 100 | 8–10 | Travel, work, community, seasons |
| 8 | 100 | 9–11 | Cause/effect, comparisons, hadith-based advice |
| 9 | 100 | 10–12 | Nature, Islamic history, Islamic values |
| 10 | 100 | 10–14 | Abstract ideas, proverb-like wisdom |

## Verification (script, all pass)
- Valid JSON in all 10 files; exactly 100 `{"arabic","english"}` objects each.
- All fields non-empty. Every sentence inside its level's word-length band.
- Zero global duplicates (tashkeel-normalized comparison): 1000/1000 unique.

## Format
Each file: `[{"arabic": "...", "english": "..."}, ...]` — UTF-8.
Arabic carries natural tashkeel (beginners read aloud; diacritics guide pronunciation).

## Notes / caveats
- Content drawn from القراءة الرشيدة / Madinah-book style themes plus the
  generator's own knowledge (FARHAN explicitly allowed this; book PDFs are
  scanned images with no extractable text).
- These are practice sentences, not verbatim book excerpts. If FARHAN wants
  exact book passages, they must be typed from the physical books.
- Sample L1: «هَذَا بَيْتٌ كَبِيرٌ» — "This is a big house."
- Sample L10: «الْعِلْمُ نُورٌ يَهْدِي الْعَقْلَ إِلَى الْحَقِّ...» — "Knowledge is a light guiding the mind to truth..."
