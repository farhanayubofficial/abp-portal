"""Reading Lab: Arabic read-aloud practice with live green/red feedback.

Teacher creates passages (Arabic WITHOUT diacritics + English translation).
Student listens (free TTS), then reads aloud via mic (free Web Speech API).
Correct words turn green, wrong words turn red with an error buzz.
Score = total_marks - mistakes * marks_per_mistake (min 0).
"""

from django.conf import settings
from django.db import models


class ReadingPassage(models.Model):
    title = models.CharField(max_length=200)
    track = models.ForeignKey(
        "courses.CourseTrack", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="reading_passages",
    )
    arabic_text = models.TextField(
        help_text="Arabic paragraph WITHOUT zabar/zair/paish (no diacritics)."
    )
    english_translation = models.TextField(blank=True)
    total_marks = models.PositiveIntegerField(default=20)
    marks_per_mistake = models.PositiveIntegerField(default=1)
    level = models.PositiveSmallIntegerField(
        default=1, help_text="1 (easy) to 10 (hard)")
    is_published = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="reading_passages",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["title"]

    def __str__(self):
        return self.title

    def word_count(self):
        return len(self.arabic_text.split())

    def compute_score(self, mistakes):
        return max(0, self.total_marks - mistakes * self.marks_per_mistake)


class ReadingAttempt(models.Model):
    passage = models.ForeignKey(
        ReadingPassage, on_delete=models.CASCADE, related_name="attempts")
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="reading_attempts")
    words_total = models.PositiveIntegerField(default=0)
    words_correct = models.PositiveIntegerField(default=0)
    words_wrong = models.PositiveIntegerField(default=0)
    score = models.IntegerField(default=0)
    mistake_words = models.JSONField(default=list, blank=True,
                                     help_text="Expected words read wrong.")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — {self.passage} ({self.score})"
