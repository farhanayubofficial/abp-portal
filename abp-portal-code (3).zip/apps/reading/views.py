"""Reading Lab views: practice (student) + report (teacher)."""

import json

from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import ReadingAttempt, ReadingPassage


def _is_staff_teacher(u):
    return u.is_authenticated and (u.is_teacher or u.is_admin)


@login_required
def passage_list(request):
    levels = []
    for lv in range(1, 11):
        if _is_staff_teacher(request.user):
            qs = ReadingPassage.objects.filter(level=lv)
        else:
            qs = ReadingPassage.objects.filter(level=lv, is_published=True)
        total = qs.count()
        done = (ReadingAttempt.objects
                .filter(student=request.user, passage__level=lv)
                .values("passage").distinct().count())
        levels.append({"n": lv, "total": total, "done": done})
    return render(request, "reading/passage_list.html",
                  {"levels": levels,
                   "is_teacher": _is_staff_teacher(request.user)})


@login_required
def play_level(request, level):
    """Pick a random UNATTEMPTED passage from the level (no repeats)."""
    level = int(level)
    if not 1 <= level <= 10:
        return redirect("reading:list")
    tried = ReadingAttempt.objects.filter(
        student=request.user, passage__level=level
    ).values_list("passage_id", flat=True)
    remaining = list(ReadingPassage.objects.filter(
        level=level, is_published=True).exclude(id__in=tried))
    if not remaining:
        return redirect("reading:list")
    import random
    nxt = random.choice(remaining)
    return redirect("reading:practice", pk=nxt.pk)


@login_required
def practice(request, pk):
    passage = get_object_or_404(ReadingPassage, pk=pk)
    if not passage.is_published and not _is_staff_teacher(request.user):
        raise PermissionDenied
    words = passage.arabic_text.split()
    return render(request, "reading/practice.html",
                  {"passage": passage, "words": words})


@login_required
@require_POST
def submit_attempt(request, pk):
    """Save a reading attempt. Score is computed server-side (trusted)."""
    passage = get_object_or_404(ReadingPassage, pk=pk)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False, "error": "bad json"}, status=400)
    words_wrong = int(data.get("words_wrong", 0) or 0)
    words_correct = int(data.get("words_correct", 0) or 0)
    mistake_words = data.get("mistake_words", []) or []
    if not isinstance(mistake_words, list):
        mistake_words = []
    score = passage.compute_score(words_wrong)
    attempt = ReadingAttempt.objects.create(
        passage=passage, student=request.user,
        words_total=passage.word_count(),
        words_correct=words_correct, words_wrong=words_wrong,
        score=score, mistake_words=mistake_words[:50],
    )
    return JsonResponse({"ok": True, "score": score,
                         "total": passage.total_marks,
                         "attempt_id": attempt.id})


@login_required
@user_passes_test(_is_staff_teacher)
def teacher_report(request):
    attempts = (ReadingAttempt.objects
                .select_related("passage", "student")
                .order_by("-created_at")[:200])
    return render(request, "reading/report.html", {"attempts": attempts})
