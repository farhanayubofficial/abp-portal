from django.urls import path

from . import views

app_name = "sentences"

urlpatterns = [
    path("", views.home, name="home"),
    path("play/<int:level>/", views.play, name="play"),
    path("submit/<int:pk>/", views.submit, name="submit"),
]
