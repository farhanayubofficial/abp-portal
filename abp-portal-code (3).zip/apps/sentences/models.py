"""Sentence Builder: unscramble Arabic sentences by clicking words in order.

10 levels x 100 sentences. No typing needed (students may not know Arabic
typing). The student clicks scrambled words in the order they should appear:
first click = position 1, second click = position 2, etc. Then Check compares
with the correct order. No sentence is ever repeated for a student — each
sentence is served once (tracked via SentenceAttempt).
"""

from django.conf import settings
from django.db import models

POINTS_PER_WORD = 5
BONUS_PERFECT = 10


class Sentence(models.Model):
    arabic = models.TextField(help_text="Correct Arabic sentence.")
    urdu = models.CharField(max_length=300, blank=True)
    english = models.CharField(max_length=300, blank=True)
    level = models.PositiveSmallIntegerField(
        default=1, help_text="1 (easy) to 10 (hard)")
    track = models.ForeignKey(
        "courses.CourseTrack", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="sentences")
    is_published = models.BooleanField(default=False)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]

    def __str__(self):
        return self.arabic[:60]

    def words(self):
        return self.arabic.split()


class SentenceAttempt(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="sentence_attempts")
    sentence = models.ForeignKey(
        Sentence, on_delete=models.CASCADE, related_name="attempts")
    correct_positions = models.PositiveIntegerField(default=0)
    total_words = models.PositiveIntegerField(default=0)
    score = models.PositiveIntegerField(default=0)
    perfect = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — {self.score} pts"
