"""Sentence Builder views: 10 levels, no-repeat play, history."""

import json
import random

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.decorators.http import require_POST

from .models import BONUS_PERFECT, POINTS_PER_WORD, Sentence, SentenceAttempt


@login_required
def home(request):
    levels = []
    for lv in range(1, 11):
        total = Sentence.objects.filter(level=lv, is_published=True).count()
        done = (SentenceAttempt.objects
                .filter(student=request.user, sentence__level=lv)
                .values("sentence").distinct().count())
        levels.append({"n": lv, "total": total, "done": done})
    my_points = (SentenceAttempt.objects.filter(student=request.user)
                 .aggregate(s=Sum("score"))["s"] or 0)
    return render(request, "sentences/home.html",
                  {"levels": levels, "my_points": my_points})


@login_required
def play(request, level):
    level = int(level)
    if not 1 <= level <= 10:
        return redirect("sentences:home")
    # NO repeats: only sentences this student has never attempted
    tried_ids = SentenceAttempt.objects.filter(
        student=request.user, sentence__level=level
    ).values_list("sentence_id", flat=True)
    remaining = list(Sentence.objects.filter(
        level=level, is_published=True).exclude(id__in=tried_ids))
    if not remaining:
        return render(request, "sentences/home.html", {
            "levels": [], "my_points": 0,
            "done_msg": f"Level {level} mukammal! 🎉 Sab jumle ho gaye!"})
    s = random.choice(remaining)
    words = s.words()
    scrambled = words[:]
    for _ in range(10):
        random.shuffle(scrambled)
        if scrambled != words or len(words) < 2:
            break
    left = len(remaining) - 1
    return render(request, "sentences/play.html", {
        "sentence": s, "level": level, "left": left,
        "scrambled_json": json.dumps(scrambled, ensure_ascii=False),
        "correct_json": json.dumps(words, ensure_ascii=False),
        "points_per_word": POINTS_PER_WORD,
        "bonus": BONUS_PERFECT,
    })


@login_required
@require_POST
def submit(request, pk):
    sentence = get_object_or_404(Sentence, pk=pk)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False}, status=400)
    order = data.get("order", []) or []
    correct_words = sentence.words()
    good = sum(1 for i, w in enumerate(order)
               if i < len(correct_words) and w == correct_words[i])
    perfect = good == len(correct_words) and len(order) == len(correct_words)
    score = good * POINTS_PER_WORD + (BONUS_PERFECT if perfect else 0)
    attempt = SentenceAttempt.objects.create(
        student=request.user, sentence=sentence,
        correct_positions=good, total_words=len(correct_words),
        score=score, perfect=perfect)
    total = (SentenceAttempt.objects.filter(student=request.user)
             .aggregate(s=Sum("score"))["s"] or 0)
    # next unattempted sentence in this level (no repeats)
    tried_ids = SentenceAttempt.objects.filter(
        student=request.user, sentence__level=sentence.level
    ).values_list("sentence_id", flat=True)
    has_next = Sentence.objects.filter(
        level=sentence.level, is_published=True
    ).exclude(id__in=tried_ids).exists()
    return JsonResponse({"ok": True, "score": score, "perfect": perfect,
                         "good": good, "total": len(correct_words),
                         "total_points": total, "has_next": has_next,
                         "level": sentence.level,
                         "attempt_id": attempt.id})
