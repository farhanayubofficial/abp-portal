# Sentence Builder — Content Report

Generated 2026-10-11 for the Arabic Bridge Program portal (Sentence Builder word-order game).

## Counts

| File | Sentences | Arabic words per sentence |
|------|-----------|---------------------------|
| level_1.json | 100 | 3–4 |
| level_2.json | 100 | 4–5 |
| level_3.json | 100 | 5–6 |
| level_4.json | 100 | 6–7 |
| level_5.json | 100 | 6–8 |
| level_6.json | 100 | 7–8 |
| level_7.json | 100 | 8–9 |
| level_8.json | 100 | 8–10 |
| level_9.json | 100 | 9–11 |
| level_10.json | 100 | 10–12 |
| **Total** | **1000** | — |

## Verification

- Every file parses as JSON; exactly 100 entries per file; all fields (`arabic`, `urdu`, `english`) non-empty.
- Zero duplicate sentences across all 10 files (checked with diacritic/whitespace normalization).
- Sentence length ascends with level as specified.
- Urdu translations are in Urdu script; English translations are natural.

## Design notes

Each sentence was written to have one unambiguous correct word order for the scramble game
(no swappable adjectives or symmetric pairs). A generator script used for the harder levels
is kept at `/tmp/abp_content/gen_sentences.py` (ephemeral; not part of the app).

## Unsure items / caveats

- Generating agents flagged a small number of sentences with minor notes (e.g. an L1 produce/market
  pairing, one L5 sentence with slightly stiff word order, a few L7–L10 sentences where two
  adverbial phrases could arguably flip). All are grammatical with a single most-natural order;
  none block gameplay, but a teacher review pass could polish them.
- Content draws from Madinah Book 1–3 style plus original material, per FARHAN's approval
  for out-of-book content.
