"""Seed 1000 sentence-builder sentences (10 levels x 100) from JSON files."""

import json
from pathlib import Path

from django.db import migrations

DATA_DIR = Path(__file__).parent.parent / "data" / "levels"


def seed(apps, schema_editor):
    Sentence = apps.get_model("sentences", "Sentence")
    Sentence.objects.all().delete()
    for lv in range(1, 11):
        path = DATA_DIR / f"level_{lv}.json"
        if not path.exists():
            continue
        items = json.loads(path.read_text(encoding="utf-8"))
        for it in items:
            Sentence.objects.create(
                arabic=it["arabic"], urdu=it.get("urdu", ""),
                english=it.get("english", ""),
                level=lv, is_published=True)


def unseed(apps, schema_editor):
    pass


class Migration(migrations.Migration):
    dependencies = [("sentences", "0003_sentence_level_sentence_urdu")]
    operations = [migrations.RunPython(seed, unseed)]
