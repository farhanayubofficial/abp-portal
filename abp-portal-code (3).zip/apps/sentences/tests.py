"""Sentence Builder tests: 10 levels, no-repeat play."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import Sentence, SentenceAttempt


def make_user(email):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U",
        role=User.ROLE_STUDENT)


class SentenceTests(TestCase):
    def setUp(self):
        Sentence.objects.all().delete()  # isolate from seed migration data
        self.student = make_user("s@x.com")
        self.s = Sentence.objects.create(
            arabic="الولد يقرأ الكتاب", english="The boy reads the book.",
            level=1, is_published=True)
        self.s2 = Sentence.objects.create(
            arabic="البنت تكتب الدرس", english="The girl writes the lesson.",
            level=1, is_published=True)

    def test_home_lists_levels(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("sentences:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 10")

    def test_play_serves_unattempted_only(self):
        # attempt s2, so play must serve s (no repeats)
        SentenceAttempt.objects.create(
            student=self.student, sentence=self.s2,
            correct_positions=3, total_words=3, score=25, perfect=True)
        self.client.force_login(self.student)
        r = self.client.get(reverse("sentences:play", args=[1]))
        self.assertEqual(r.status_code, 200)
        # words are rendered individually in the click-to-order UI
        self.assertContains(r, "الولد")
        self.assertContains(r, "يقرأ")
        self.assertContains(r, "الكتاب")
        self.assertNotContains(r, "البنت تكتب الدرس")

    def test_play_level_complete(self):
        for s in (self.s, self.s2):
            SentenceAttempt.objects.create(
                student=self.student, sentence=s,
                correct_positions=3, total_words=3, score=25, perfect=True)
        self.client.force_login(self.student)
        r = self.client.get(reverse("sentences:play", args=[1]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "mukammal")

    def test_submit_perfect(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("sentences:submit", args=[self.s.pk]),
            json.dumps({"order": ["الولد", "يقرأ", "الكتاب"]}),
            content_type="application/json")
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertTrue(data["perfect"])
        self.assertEqual(data["score"], 25)
        self.assertTrue(data["has_next"])  # s2 still unattempted
        a = SentenceAttempt.objects.get()
        self.assertEqual(a.score, 25)

    def test_submit_has_next_false_when_done(self):
        SentenceAttempt.objects.create(
            student=self.student, sentence=self.s2,
            correct_positions=3, total_words=3, score=25, perfect=True)
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("sentences:submit", args=[self.s.pk]),
            json.dumps({"order": ["الولد", "يقرأ", "الكتاب"]}),
            content_type="application/json")
        self.assertFalse(r.json()["has_next"])

    def test_submit_partial(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("sentences:submit", args=[self.s.pk]),
            json.dumps({"order": ["الولد", "الكتاب", "يقرأ"]}),
            content_type="application/json")
        data = r.json()
        self.assertFalse(data["perfect"])
        self.assertEqual(data["score"], 5)

    def test_words_split(self):
        self.assertEqual(self.s.words(), ["الولد", "يقرأ", "الكتاب"])
