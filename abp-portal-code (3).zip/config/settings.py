"""ABP project settings. Secrets come from environment (.env), never from this file."""
from pathlib import Path
from urllib.parse import urlparse

from decouple import config as env

BASE_DIR = Path(__file__).resolve().parent.parent

SECRET_KEY = env("SECRET_KEY", default="django-insecure-dev-only-change-me")
DEBUG = env("DEBUG", default=True, cast=bool)
ALLOWED_HOSTS = [h.strip() for h in env("ALLOWED_HOSTS", default="127.0.0.1,localhost").split(",") if h.strip()]

INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # ABP apps
    "apps.core",
    "apps.accounts",
    "apps.courses",
    "apps.classes",
    "apps.homework",
    "apps.fees",
    "apps.notifications",
    "apps.reports",
    "apps.reading",
    "apps.speaking",
    "apps.vocab",
    "apps.sentences",
    "apps.maze",
    "apps.snake",
    "apps.tartib",
    "apps.tilawat",
    "apps.spoken",
    "apps.grammar",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "config.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
                "apps.notifications.context_processors.unread_count",
            ],
        },
    },
]

WSGI_APPLICATION = "config.wsgi.application"

# Database: PostgreSQL when DATABASE_URL is set, otherwise local SQLite.
DATABASE_URL = env("DATABASE_URL", default="")
if DATABASE_URL:
    u = urlparse(DATABASE_URL)
    _qs = dict(p.split("=", 1) for p in u.query.split("&") if "=" in p)
    _db = {
        "ENGINE": "django.db.backends.postgresql",
        "NAME": u.path.lstrip("/"),
        "USER": u.username,
        "PASSWORD": u.password,
        "HOST": u.hostname,
        "PORT": u.port or 5432,
    }
    if _qs.get("sslmode"):
        _db["OPTIONS"] = {"sslmode": _qs["sslmode"]}
    DATABASES = {"default": _db}
else:
    DATABASES = {"default": {"ENGINE": "django.db.backends.sqlite3", "NAME": BASE_DIR / "db.sqlite3"}}

AUTH_USER_MODEL = "accounts.User"
LOGIN_URL = "login"
LOGIN_REDIRECT_URL = "dashboard"
LOGOUT_REDIRECT_URL = "landing"

AUTH_PASSWORD_VALIDATORS = [
    {"NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator"},
    {"NAME": "django.contrib.auth.password_validation.MinimumLengthValidator"},
    {"NAME": "django.contrib.auth.password_validation.CommonPasswordValidator"},
    {"NAME": "django.contrib.auth.password_validation.NumericPasswordValidator"},
]

LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

STATIC_URL = "static/"
STATIC_ROOT = BASE_DIR / "staticfiles"
# WhiteNoise: serve static files in production (free, no extra service).
STATICFILES_STORAGE = "whitenoise.storage.CompressedManifestStaticFilesStorage"
MEDIA_URL = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
# Phase 7 will configure a real email backend; development prints emails to console.
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
DEFAULT_FROM_EMAIL = "Arabic Bridge Program <noreply@arabicbridgeprogram.com>"

# ---- Free email via Gmail SMTP (500 emails/day free) ----
# Set these environment variables when ready to send real emails:
#   GMAIL_USER = your Gmail address
#   GMAIL_APP_PASSWORD = Gmail "App password" (not your login password)
# Until then, emails print to the console (dev mode).
import os as _os

_GMAIL_USER = _os.environ.get("GMAIL_USER", "")
_GMAIL_APP_PASSWORD = _os.environ.get("GMAIL_APP_PASSWORD", "")
if _GMAIL_USER and _GMAIL_APP_PASSWORD:
    EMAIL_BACKEND = "django.core.mail.backends.smtp.EmailBackend"
    EMAIL_HOST = "smtp.gmail.com"
    EMAIL_PORT = 587
    EMAIL_USE_TLS = True
    EMAIL_HOST_USER = _GMAIL_USER
    EMAIL_HOST_PASSWORD = _GMAIL_APP_PASSWORD
    DEFAULT_FROM_EMAIL = f"Arabic Bridge Program <{_GMAIL_USER}>"

# ---- Free WhatsApp via Meta Cloud API (1,000 conversations/month free) ----
# Set these environment variables when ready:
#   WHATSAPP_TOKEN = Meta developer dashboard → WhatsApp → API setup → temporary/permanent token
#   WHATSAPP_PHONE_NUMBER_ID = the Phone Number ID shown in the same dashboard
# Until then, WhatsApp sending is skipped silently (portal notifications still work).
WHATSAPP_TOKEN = _os.environ.get("WHATSAPP_TOKEN", "")
WHATSAPP_PHONE_NUMBER_ID = _os.environ.get("WHATSAPP_PHONE_NUMBER_ID", "")
# Secret word Meta must send back when verifying the webhook.
# FARHAN invents any random word, puts the SAME word in Meta dashboard
# and in this env var.
WHATSAPP_VERIFY_TOKEN = _os.environ.get("WHATSAPP_VERIFY_TOKEN", "")

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ---- Production hardening (Phase 9). All via env vars; dev defaults stay safe. ----
_csrf = [h.strip() for h in _os.environ.get("CSRF_TRUSTED_ORIGINS", "").split(",") if h.strip()]
if _csrf:
    CSRF_TRUSTED_ORIGINS = _csrf
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_HSTS_SECONDS = 31536000
    SECURE_HSTS_INCLUDE_SUBDOMAINS = True
