from django.contrib import admin
from django.urls import include, path

from apps.core.views import LandingView

admin.site.site_header = "Arabic Bridge Program — Administration"
admin.site.site_title = "ABP Admin"
admin.site.index_title = "Academy administration"

urlpatterns = [
    path("", LandingView.as_view(), name="landing"),
    path("admin/", admin.site.urls),
    path("accounts/", include("apps.accounts.urls")),
    path("courses/", include("apps.courses.urls")),
    path("classes/", include("apps.classes.urls")),
    path("homework/", include("apps.homework.urls")),
    path("fees/", include("apps.fees.urls")),
    path("notifications/", include("apps.notifications.urls")),
    path("reports/", include("apps.reports.urls")),
]
