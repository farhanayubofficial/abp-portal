from django.apps import AppConfig


class SentencesConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.sentences"
    verbose_name = "Sentence Builder"
