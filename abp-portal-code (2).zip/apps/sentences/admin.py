from django.contrib import admin

from .models import Sentence, SentenceAttempt


@admin.register(Sentence)
class SentenceAdmin(admin.ModelAdmin):
    list_display = ("arabic", "track", "is_published")
    list_filter = ("track", "is_published")
    search_fields = ("arabic",)


@admin.register(SentenceAttempt)
class SentenceAttemptAdmin(admin.ModelAdmin):
    list_display = ("student", "sentence", "score", "perfect", "created_at")
    list_filter = ("perfect",)
