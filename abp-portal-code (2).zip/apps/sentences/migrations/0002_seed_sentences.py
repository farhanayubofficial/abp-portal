"""Seed 10 starter Arabic sentences (correct order)."""

from django.db import migrations

SENTENCES = [
    ("الولد يقرأ الكتاب", "The boy reads the book."),
    ("البنت تكتب الدرس", "The girl writes the lesson."),
    ("المعلم يشرح القاعدة", "The teacher explains the rule."),
    ("الطالب يتعلم اللغة العربية", "The student learns the Arabic language."),
    ("نحن نحب المدرسة كثيرا", "We love the school very much."),
    ("ذهب محمد إلى السوق صباحا", "Muhammad went to the market in the morning."),
    ("القراءة مفيدة للعقل والقلب", "Reading is beneficial for the mind and heart."),
    ("اللغة العربية لغة جميلة وسهلة", "Arabic is a beautiful and easy language."),
    ("اشرب الماء البارد في الصيف", "Drink cold water in summer."),
    ("العلم نور يهدي الناس إلى الحق", "Knowledge is a light guiding people to truth."),
]


def seed(apps, schema_editor):
    Sentence = apps.get_model("sentences", "Sentence")
    CourseTrack = apps.get_model("courses", "CourseTrack")
    track = CourseTrack.objects.filter(name="Arabic Language").first()
    for ar, en in SENTENCES:
        Sentence.objects.get_or_create(
            arabic=ar,
            defaults={"english": en, "track": track, "is_published": True})


class Migration(migrations.Migration):
    dependencies = [("sentences", "0001_initial")]
    operations = [migrations.RunPython(seed, migrations.RunPython.noop)]
