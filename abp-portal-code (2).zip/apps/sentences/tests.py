"""Sentence Builder tests (Phase 13)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import Sentence, SentenceAttempt


def make_user(email):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U",
        role=User.ROLE_STUDENT)


class SentenceTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com")
        self.s = Sentence.objects.create(
            arabic="الولد يقرأ الكتاب", english="The boy reads the book.",
            is_published=True)

    def test_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("sentences:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Khel Shuru Karein")

    def test_play_scrambles(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("sentences:play"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "scrambled")

    def test_submit_perfect(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("sentences:submit", args=[self.s.pk]),
            json.dumps({"order": ["الولد", "يقرأ", "الكتاب"]}),
            content_type="application/json")
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertTrue(data["perfect"])
        # 3 words * 5 + 10 bonus = 25
        self.assertEqual(data["score"], 25)
        a = SentenceAttempt.objects.get()
        self.assertEqual(a.score, 25)

    def test_submit_partial(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("sentences:submit", args=[self.s.pk]),
            json.dumps({"order": ["الولد", "الكتاب", "يقرأ"]}),
            content_type="application/json")
        data = r.json()
        self.assertFalse(data["perfect"])
        # only position 0 correct = 5
        self.assertEqual(data["score"], 5)

    def test_words_split(self):
        self.assertEqual(self.s.words(), ["الولد", "يقرأ", "الكتاب"])
