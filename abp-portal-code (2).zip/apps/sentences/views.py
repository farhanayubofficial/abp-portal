"""Sentence Builder views: home, play, history."""

import json
import random

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_POST

from .models import BONUS_PERFECT, POINTS_PER_WORD, Sentence, SentenceAttempt


@login_required
def home(request):
    total = Sentence.objects.filter(is_published=True).count()
    my_points = (SentenceAttempt.objects.filter(student=request.user)
                 .aggregate(s=Sum("score"))["s"] or 0)
    recent = SentenceAttempt.objects.filter(
        student=request.user).select_related("sentence")[:5]
    return render(request, "sentences/home.html", {
        "total": total, "my_points": my_points, "recent": recent})


@login_required
def play(request):
    sentences = list(Sentence.objects.filter(is_published=True))
    if not sentences:
        return render(request, "sentences/home.html", {
            "total": 0, "my_points": 0, "recent": [],
            "error": "Abhi koi jumle nahi hain."})
    s = random.choice(sentences)
    words = s.words()
    scrambled = words[:]
    # ensure actually scrambled (avoid identity shuffle for >1 word)
    for _ in range(10):
        random.shuffle(scrambled)
        if scrambled != words or len(words) < 2:
            break
    return render(request, "sentences/play.html", {
        "sentence": s,
        "scrambled_json": json.dumps(scrambled, ensure_ascii=False),
        "correct_json": json.dumps(words, ensure_ascii=False),
        "points_per_word": POINTS_PER_WORD,
        "bonus": BONUS_PERFECT,
    })


@login_required
@require_POST
def submit(request, pk):
    sentence = get_object_or_404(Sentence, pk=pk)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False}, status=400)
    order = data.get("order", []) or []
    correct_words = sentence.words()
    good = sum(1 for i, w in enumerate(order)
               if i < len(correct_words) and w == correct_words[i])
    perfect = good == len(correct_words) and len(order) == len(correct_words)
    score = good * POINTS_PER_WORD + (BONUS_PERFECT if perfect else 0)
    attempt = SentenceAttempt.objects.create(
        student=request.user, sentence=sentence,
        correct_positions=good, total_words=len(correct_words),
        score=score, perfect=perfect)
    total = (SentenceAttempt.objects.filter(student=request.user)
             .aggregate(s=Sum("score"))["s"] or 0)
    return JsonResponse({"ok": True, "score": score, "perfect": perfect,
                         "good": good, "total": len(correct_words),
                         "total_points": total,
                         "attempt_id": attempt.id})
