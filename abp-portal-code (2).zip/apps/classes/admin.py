from django.contrib import admin

from .models import ClassAttendance, LiveClass


class ClassAttendanceInline(admin.TabularInline):
    model = ClassAttendance
    extra = 0
    readonly_fields = ["marked_at"]


@admin.register(LiveClass)
class LiveClassAdmin(admin.ModelAdmin):
    list_display = ["title", "track", "teacher", "scheduled_at", "status"]
    list_filter = ["status", "track"]
    inlines = [ClassAttendanceInline]


@admin.register(ClassAttendance)
class ClassAttendanceAdmin(admin.ModelAdmin):
    list_display = ["live_class", "student", "status", "marked_at"]
    list_filter = ["status"]
