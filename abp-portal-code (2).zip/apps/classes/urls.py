from django.urls import path

from . import views

app_name = "classes"

urlpatterns = [
    path("", views.ClassListView.as_view(), name="class_list"),
    path("schedule/", views.ScheduleClassView.as_view(), name="schedule"),
    path("<int:pk>/", views.ClassDetailView.as_view(), name="class_detail"),
    path("<int:pk>/attendance/", views.AttendanceView.as_view(), name="attendance"),
]
