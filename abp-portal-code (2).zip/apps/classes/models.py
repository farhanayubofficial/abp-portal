"""Phase 4: Live classes (free tier).

No paid meeting API. The teacher schedules a class and pastes any meeting
link (Jitsi / Zoom free / Google Meet). Students see upcoming classes and
a Join button. Attendance is marked manually by the teacher after class.
"""
from django.conf import settings
from django.db import models

from apps.courses.models import CourseTrack


class LiveClass(models.Model):
    """A scheduled live class session."""

    STATUS_SCHEDULED = "scheduled"
    STATUS_LIVE = "live"
    STATUS_DONE = "done"
    STATUS_CANCELLED = "cancelled"
    STATUS_CHOICES = [
        (STATUS_SCHEDULED, "Scheduled"),
        (STATUS_LIVE, "Live now"),
        (STATUS_DONE, "Completed"),
        (STATUS_CANCELLED, "Cancelled"),
    ]

    track = models.ForeignKey(CourseTrack, on_delete=models.CASCADE, related_name="live_classes")
    teacher = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="taught_classes"
    )
    title = models.CharField(max_length=200)
    scheduled_at = models.DateTimeField()
    duration_minutes = models.PositiveIntegerField(default=60)
    meeting_url = models.URLField(
        max_length=500,
        help_text="Paste your meeting link here (Jitsi, Zoom, Google Meet — any free service).",
    )
    notes = models.TextField(blank=True, help_text="Topic, homework, or instructions for students.")
    recording_url = models.URLField(
        max_length=500, blank=True,
        help_text="Paste the class recording link (YouTube unlisted — free). Plays inside the portal.",
    )
    recording_file = models.FileField(
        upload_to="class_recordings/", blank=True, null=True,
        help_text="Or record from your camera and upload the video directly.",
    )
    recording_notes = models.CharField(max_length=255, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SCHEDULED)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["scheduled_at"]

    @property
    def youtube_embed_url(self):
        """Convert a YouTube watch/share URL to an embed URL for in-portal playback."""
        import re

        url = (self.recording_url or "").strip()
        m = re.search(r"(?:youtube\.com/(?:watch\?v=|embed/|shorts/)|youtu\.be/)([\w-]{6,})", url)
        if m:
            return f"https://www.youtube.com/embed/{m.group(1)}"
        return ""

    @property
    def has_recording(self):
        return bool(self.recording_file or self.recording_url)

    def __str__(self):
        return f"{self.title} — {self.scheduled_at:%Y-%m-%d %H:%M}"


class ClassAttendance(models.Model):
    """Manual attendance record marked by the teacher."""

    PRESENT = "present"
    ABSENT = "absent"
    LATE = "late"
    EXCUSED = "excused"
    STATUS_CHOICES = [
        (PRESENT, "Present"),
        (ABSENT, "Absent"),
        (LATE, "Late"),
        (EXCUSED, "Excused"),
    ]

    live_class = models.ForeignKey(LiveClass, on_delete=models.CASCADE, related_name="attendance")
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="class_attendance"
    )
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PRESENT)
    marked_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name="+"
    )
    marked_at = models.DateTimeField(auto_now=True)
    note = models.CharField(max_length=200, blank=True)

    class Meta:
        unique_together = [("live_class", "student")]
        ordering = ["student__first_name"]

    def __str__(self):
        return f"{self.student} — {self.live_class.title}: {self.status}"
