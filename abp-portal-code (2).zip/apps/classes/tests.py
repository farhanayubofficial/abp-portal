"""Phase 4 tests: live classes (free tier) + attendance."""
from django.test import TestCase
from django.urls import reverse
from django.utils import timezone

from apps.accounts.models import User
from apps.courses.models import CourseTrack

from .models import ClassAttendance, LiveClass


class Phase4Tests(TestCase):
    def setUp(self):
        self.track = CourseTrack.objects.create(code="t1", name="Track 1")
        self.teacher = User.objects.create_user(
            email="teach@abp.test", password="x", role=User.ROLE_TEACHER
        )
        self.student = User.objects.create_user(
            email="stud@abp.test", password="x", role=User.ROLE_STUDENT
        )
        self.klass = LiveClass.objects.create(
            track=self.track,
            teacher=self.teacher,
            title="Test Class",
            scheduled_at=timezone.now() + timezone.timedelta(days=1),
            meeting_url="https://meet.jit.si/abp-test-123",
        )

    def test_student_sees_class_list_and_join_link(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("classes:class_list"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Test Class")
        self.assertContains(r, "https://meet.jit.si/abp-test-123")

    def test_student_cannot_schedule(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("classes:schedule"))
        self.assertEqual(r.status_code, 403)

    def test_teacher_can_schedule(self):
        self.client.force_login(self.teacher)
        r = self.client.post(
            reverse("classes:schedule"),
            {
                "track": self.track.pk,
                "title": "New Class",
                "meeting_url": "https://meet.jit.si/abp-new",
                "scheduled_at": "2030-01-01T10:00",
                "duration_minutes": 45,
            },
        )
        self.assertEqual(r.status_code, 302)
        self.assertTrue(LiveClass.objects.filter(title="New Class").exists())

    def test_teacher_marks_attendance(self):
        self.client.force_login(self.teacher)
        r = self.client.post(
            reverse("classes:attendance", kwargs={"pk": self.klass.pk}),
            {f"att_{self.student.pk}": "present"},
        )
        self.assertEqual(r.status_code, 302)
        att = ClassAttendance.objects.get(live_class=self.klass, student=self.student)
        self.assertEqual(att.status, "present")
        self.klass.refresh_from_db()
        self.assertEqual(self.klass.status, LiveClass.STATUS_DONE)

    def test_student_cannot_mark_attendance(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("classes:attendance", kwargs={"pk": self.klass.pk}))
        self.assertEqual(r.status_code, 403)

    def test_dashboard_shows_upcoming(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("dashboard"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Upcoming Live Classes")
