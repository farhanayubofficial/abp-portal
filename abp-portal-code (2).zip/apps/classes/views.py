"""Phase 4 views: schedule classes (teacher), join (student), attendance (teacher)."""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import DetailView, ListView

from apps.accounts.models import User

from .models import ClassAttendance, LiveClass


class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        u = self.request.user
        return u.is_authenticated and (u.is_teacher or u.is_admin)


class ClassListView(LoginRequiredMixin, ListView):
    """Upcoming + past classes. Students see all; join button on upcoming."""

    model = LiveClass
    template_name = "classes/class_list.html"
    context_object_name = "classes"

    def get_queryset(self):
        return LiveClass.objects.select_related("track", "teacher").order_by("-scheduled_at")[:50]


class ClassDetailView(LoginRequiredMixin, DetailView):
    model = LiveClass
    template_name = "classes/class_detail.html"
    context_object_name = "live_class"

    def post(self, request, pk):
        # Staff: save class recording — YouTube link OR camera-recorded file upload.
        u = request.user
        if not (u.is_teacher or u.is_admin):
            from django.http import Http404
            raise Http404
        live_class = self.get_object()
        saved = False
        if request.FILES.get("recording_file"):
            live_class.recording_file = request.FILES["recording_file"]
            saved = True
        url = request.POST.get("recording_url", "").strip()
        if url:
            live_class.recording_url = url
            saved = True
        live_class.recording_notes = request.POST.get("recording_notes", "").strip()
        live_class.save()
        if saved:
            from apps.accounts.models import StudentProfile
            from apps.notifications.models import class_url, notify_many, Notification
            students = [p.user for p in StudentProfile.objects.filter(
                tracks=live_class.track, is_enrolled=True).select_related("user")]
            notify_many(students, f"Recording available: {live_class.title}",
                        live_class.recording_notes,
                        class_url(live_class.pk), Notification.TYPE_CLASS)
            messages.success(request, "Recording saved — students can now watch it inside the portal.")
        else:
            messages.info(request, "No recording provided.")
        return redirect("classes:class_detail", pk=pk)


class ScheduleClassView(StaffRequiredMixin, ListView):
    """Teacher: form to schedule a class (GET shows form, POST creates)."""

    template_name = "classes/schedule.html"

    def get(self, request):
        from apps.courses.models import CourseTrack

        return render(
            request,
            self.template_name,
            {"tracks": CourseTrack.objects.all()},
        )

    def post(self, request):
        from apps.courses.models import CourseTrack

        track = get_object_or_404(CourseTrack, pk=request.POST.get("track"))
        title = request.POST.get("title", "").strip()
        meeting_url = request.POST.get("meeting_url", "").strip()
        scheduled_at = request.POST.get("scheduled_at", "").strip()
        duration = int(request.POST.get("duration_minutes", 60) or 60)
        notes = request.POST.get("notes", "").strip()
        if not (title and meeting_url and scheduled_at):
            messages.error(request, "Please fill in title, meeting link, and date/time.")
            return redirect("classes:schedule")
        live_class = LiveClass.objects.create(
            track=track,
            teacher=request.user,
            title=title,
            meeting_url=meeting_url,
            scheduled_at=scheduled_at,
            duration_minutes=duration,
            notes=notes,
        )
        # Phase 7: notify enrolled students of this track
        from apps.accounts.models import StudentProfile
        from apps.notifications.models import class_url, notify_many, Notification
        students = [p.user for p in StudentProfile.objects.filter(
            tracks=track, is_enrolled=True).select_related("user")]
        when = live_class.scheduled_at
        when_str = when.strftime("%d %b, %H:%M") if hasattr(when, "strftime") else str(when)
        notify_many(students, f"New live class: {title}",
                    f"{track.name} — {when_str}",
                    class_url(live_class.pk), Notification.TYPE_CLASS)
        messages.success(request, "Class scheduled successfully!")
        return redirect("classes:class_list")


class AttendanceView(StaffRequiredMixin, DetailView):
    """Teacher marks attendance after class."""

    model = LiveClass
    template_name = "classes/attendance.html"
    context_object_name = "live_class"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        students = User.objects.filter(role=User.ROLE_STUDENT, is_active=True).order_by(
            "first_name", "email"
        )
        marked = {a.student_id: a.status for a in self.object.attendance.all()}
        ctx["student_rows"] = [(s, marked.get(s.pk, "present")) for s in students]
        return ctx

    def post(self, request, pk):
        live_class = self.get_object()
        for key, value in request.POST.items():
            if key.startswith("att_"):
                try:
                    student_id = int(key[4:])
                except ValueError:
                    continue
                if value not in dict(ClassAttendance.STATUS_CHOICES):
                    continue
                student = get_object_or_404(User, pk=student_id, role=User.ROLE_STUDENT)
                ClassAttendance.objects.update_or_create(
                    live_class=live_class,
                    student=student,
                    defaults={"status": value, "marked_by": request.user},
                )
        if live_class.status == LiveClass.STATUS_SCHEDULED:
            live_class.status = LiveClass.STATUS_DONE
            live_class.save()
        messages.success(request, "Attendance saved!")
        return redirect("classes:class_detail", pk=live_class.pk)
