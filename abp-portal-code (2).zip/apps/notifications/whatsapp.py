"""Free WhatsApp sending via Meta WhatsApp Cloud API.

Free tier: 1,000 conversations/month free (Meta's official pricing).
Setup (one time, by FARHAN):
  1. Go to developers.facebook.com → create app → add "WhatsApp" product.
  2. In API Setup: copy the Phone Number ID and generate an access token.
  3. Add a phone number and verify it (test number works instantly).
  4. Set env vars WHATSAPP_TOKEN and WHATSAPP_PHONE_NUMBER_ID on the server.
Until then, send_whatsapp() returns False and the portal just skips it.
Uses only Python stdlib — no new dependencies.
"""

import json
import logging
import urllib.request

from django.conf import settings

logger = logging.getLogger(__name__)


def _clean_phone(phone):
    """Keep digits and leading +; Meta wants digits only with country code."""
    digits = "".join(c for c in str(phone) if c.isdigit())
    return digits


def send_whatsapp(to_phone, message):
    """Send a WhatsApp text message. Returns True on success, False otherwise."""
    token = getattr(settings, "WHATSAPP_TOKEN", "")
    phone_id = getattr(settings, "WHATSAPP_PHONE_NUMBER_ID", "")
    to = _clean_phone(to_phone)
    if not (token and phone_id and to and message):
        return False
    url = f"https://graph.facebook.com/v21.0/{phone_id}/messages"
    payload = json.dumps({
        "messaging_product": "whatsapp",
        "to": to,
        "type": "text",
        "text": {"body": message[:4000]},
    }).encode()
    req = urllib.request.Request(
        url, data=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            return resp.status == 200
    except Exception as e:
        logger.warning("WhatsApp send failed: %s", e)
        return False
