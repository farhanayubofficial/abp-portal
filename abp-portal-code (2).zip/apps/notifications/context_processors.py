"""Unread notification count for the nav bell (free, one cheap query)."""


def unread_count(request):
    if not getattr(request, "user", None) or not request.user.is_authenticated:
        return {}
    try:
        from .models import Notification
        return {"unread_notifications": Notification.objects.filter(
            user=request.user, is_read=False).count()}
    except Exception:
        return {}
