"""WhatsApp auto-reply agent brain for Arabic Bridge Program.

Pure function get_reply(text) -> str. Keyword-based FAQ matching in
English + Roman Urdu. No network, no AI API — 100% free, instant.
FARHAN can edit REPLY_TOPICS freely to change the agent's answers.
"""

GREETING = (
    "Assalam-o-Alaikum! Arabic Bridge Program mein khush aamdeed. "
    "Main aap ki madad ke liye hazir hun. Aap pooch sakte hain: "
    "courses, fees, timings, admission."
)

# (keywords, reply) — first match wins, so keep specific topics first.
REPLY_TOPICS = [
    (
        ["admission", "admit", "enroll", "enrolment", "join", "dakhla", "apply",
         "registration", "register", "dakhl"],
        "Admission bilkul asaan hai! Aap hamare portal par apply kar sakte hain. "
        "Kya aap ko admission link bhejun?",
    ),
    (
        ["fee", "fees", "price", "cost", "payment", "paisa", "pese", "charges",
         "kitna", "qemat", "qeemat"],
        "Fees har course ke hisaab se mukhtalif hai. Aap kaunsa course karna "
        "chahte hain — Quranic Arabic, Arabic Language, Spoken Arabic ya Tafsir? "
        "Naam batayein, main fees bata deta hun.",
    ),
    (
        ["timing", "timings", "time", "schedule", "kab", "class kab", "baje",
         "slot", "when"],
        "Classes online hoti hain (Zoom/Google Meet). Timing aap ke aur teacher "
        "ke darmiyan tay hoti hai. Aap ko subah ya shaam — kis waqt asaan rahega?",
    ),
    (
        ["course", "courses", "track", "quranic", "tafseer", "tafsir", "spoken",
         "arabic language", "madinah", "qasas", "syllabus", "kitab", "book"],
        "Hamare 4 courses hain:\n"
        "1. Quranic Arabic\n"
        "2. Arabic Language\n"
        "3. Spoken Arabic\n"
        "4. Tafsir al-Quran\n"
        "Kis course ke bare mein maloom karna chahte hain?",
    ),
    (
        ["farhan", "bhai", "aap kahan", "tum kahan", "kahan hain", "kab aaoge",
         "kab aoge", "milna hai", "mulaqat"],
        "Main FARHAN bhai ka digital assistant hun. Wo is waqt masroof hain — "
        "aap ka paigham un tak zaroor pahuncha dunga. "
        "Bara-e-meharbani apna naam aur kaam likh dein!",
    ),
    (
        ["online", "zoom", "meet", "where", "location", "address",
         "academy kahan"],
        "Hamari academy 100% online hai — aap duniya mein kahin se bhi parh "
        "sakte hain! Classes Zoom/Google Meet par hoti hain.",
    ),
    (
        ["human", "insan", "insaan", "call", "phone", "number", "rabta",
         "contact", "teacher", "ustad", "sir", "baat"],
        "Bilkul! Aap ki baat teacher tak pahuncha deta hun. "
        "Bara-e-meharbani apna naam likh dein — hum jald rabta karenge.",
    ),
    (
        ["shukriya", "thanks", "thank", "jazakallah", "ok", "theek", "acha"],
        "Khush aamdeed! Aur koi sawal ho to zaroor poochein. "
        "Arabic Bridge Program aap ke sath hai!",
    ),
]

FALLBACK = (
    "Samajh nahi aaya — maazrat! Aap ye pooch sakte hain: "
    "courses, fees, timings, admission. "
    "Ya likhein 'teacher' — aap ki baat teacher tak pahuncha dunga."
)


def get_reply(text):
    """Return the agent's reply for an incoming message (pure function)."""
    t = (text or "").strip().lower()
    if not t:
        return FALLBACK
    # greeting first
    if any(w in t for w in ["salam", "assalam", "hello", "hi", "hey", "aoa", "adab"]):
        # greeting + a nudge, unless they already asked something specific
        for keywords, reply in REPLY_TOPICS:
            if any(k in t for k in keywords):
                return reply
        return GREETING
    for keywords, reply in REPLY_TOPICS:
        if any(k in t for k in keywords):
            return reply
    return FALLBACK
