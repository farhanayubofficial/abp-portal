"""Phase 7 views: bell list, mark read."""

from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect
from django.views.generic import ListView, View

from .models import Notification


class NotificationListView(LoginRequiredMixin, ListView):
    model = Notification
    template_name = "notifications/list.html"
    context_object_name = "notifications"
    paginate_by = 30

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user).order_by("-created_at")


class MarkReadView(LoginRequiredMixin, View):
    def post(self, request, pk):
        n = get_object_or_404(Notification, pk=pk, user=request.user)
        n.is_read = True
        n.save(update_fields=["is_read"])
        return redirect(n.link or "notifications:list")


class MarkAllReadView(LoginRequiredMixin, View):
    def post(self, request):
        Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return redirect("notifications:list")


# ---- WhatsApp agent webhook (Meta Cloud API, free) ----
import json as _json
import logging as _logging

from django.conf import settings as _settings
from django.http import HttpResponse, HttpResponseForbidden
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt

from .agent import get_reply
from .whatsapp import send_whatsapp

_logger = _logging.getLogger(__name__)


@method_decorator(csrf_exempt, name="dispatch")
class WhatsAppWebhookView(View):
    """Meta calls GET once to verify, then POST for every incoming message."""

    def get(self, request):
        mode = request.GET.get("hub.mode")
        token = request.GET.get("hub.verify_token")
        challenge = request.GET.get("hub.challenge")
        expected = getattr(_settings, "WHATSAPP_VERIFY_TOKEN", "")
        if expected and mode == "subscribe" and token == expected:
            return HttpResponse(challenge or "")
        return HttpResponseForbidden("verification failed")

    def post(self, request):
        try:
            data = _json.loads(request.body.decode("utf-8") or "{}")
        except Exception:
            return HttpResponse("ok")
        try:
            for entry in data.get("entry", []):
                for change in entry.get("changes", []):
                    value = change.get("value", {})
                    for msg in value.get("messages", []):
                        if msg.get("type") != "text":
                            continue
                        sender = msg.get("from", "")
                        text = (msg.get("text") or {}).get("body", "")
                        if sender and text:
                            send_whatsapp(sender, get_reply(text))
        except Exception:
            _logger.exception("WhatsApp webhook failed")
        return HttpResponse("ok")
