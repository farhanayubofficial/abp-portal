"""Phase 7 tests: bell, hooks, recordings."""

from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from apps.accounts.models import StudentProfile
from apps.classes.models import LiveClass
from apps.courses.models import CourseTrack
from apps.fees.models import FeePlan, Invoice
from apps.homework.models import Homework, Submission

from .models import Notification

User = get_user_model()


class Phase7Tests(TestCase):
    def setUp(self):
        self.teacher = User.objects.create_user(email="n_teacher@abp.test", password="x", role="teacher")
        self.student = User.objects.create_user(email="n_student@abp.test", password="x", role="student")
        self.track = CourseTrack.objects.create(code="nt", name="Notif Track")
        self.profile = StudentProfile.objects.create(user=self.student, student_id="N001")
        self.profile.tracks.add(self.track)

    def test_bell_list_and_unread_count(self):
        Notification.objects.create(user=self.student, title="Hello")
        self.client.force_login(self.student)
        r = self.client.get("/notifications/")
        self.assertContains(r, "Hello")
        self.assertContains(r, "🔔 (1)")

    def test_mark_read(self):
        n = Notification.objects.create(user=self.student, title="Hi", link="/homework/")
        self.client.force_login(self.student)
        r = self.client.post(f"/notifications/{n.pk}/read/")
        self.assertEqual(r.status_code, 302)
        n.refresh_from_db()
        self.assertTrue(n.is_read)

    def test_mark_all_read(self):
        Notification.objects.create(user=self.student, title="A")
        Notification.objects.create(user=self.student, title="B")
        self.client.force_login(self.student)
        self.client.post("/notifications/read-all/")
        self.assertEqual(Notification.objects.filter(user=self.student, is_read=False).count(), 0)

    def test_homework_published_notifies_students(self):
        self.client.force_login(self.teacher)
        self.client.post("/homework/create/", {"track": self.track.pk, "title": "HW1",
                                               "instructions": "do", "homework_type": "written",
                                               "max_marks": "10", "status": "published"})
        self.assertTrue(Notification.objects.filter(user=self.student, title__contains="HW1").exists())

    def test_homework_draft_no_notification(self):
        self.client.force_login(self.teacher)
        self.client.post("/homework/create/", {"track": self.track.pk, "title": "Draft1",
                                               "instructions": "do", "homework_type": "written",
                                               "max_marks": "10", "status": "draft"})
        self.assertFalse(Notification.objects.filter(user=self.student).exists())

    def test_grading_notifies_student(self):
        hw = Homework.objects.create(track=self.track, title="HW", instructions="x",
                                     status="published", created_by=self.teacher)
        sub = Submission.objects.create(homework=hw, student=self.student, text_answer="a")
        self.client.force_login(self.teacher)
        self.client.post(f"/homework/submission/{sub.pk}/grade/", {"marks": "8", "feedback": ""})
        n = Notification.objects.filter(user=self.student, notif_type="grade").first()
        self.assertIsNotNone(n)
        self.assertIn("8/10", n.message)

    def test_class_scheduled_notifies_students(self):
        self.client.force_login(self.teacher)
        self.client.post("/classes/schedule/", {
            "track": self.track.pk, "title": "Class 1",
            "meeting_url": "https://meet.jit.si/test",
            "scheduled_at": (timezone.now() + timedelta(days=1)).strftime("%Y-%m-%dT%H:%M"),
            "duration_minutes": "60", "notes": ""})
        self.assertTrue(Notification.objects.filter(user=self.student, title__contains="Class 1").exists())

    def test_recording_save_and_visible(self):
        lc = LiveClass.objects.create(track=self.track, teacher=self.teacher, title="C1",
                                      meeting_url="https://x", scheduled_at=timezone.now())
        self.client.force_login(self.teacher)
        r = self.client.post(f"/classes/{lc.pk}/", {"recording_url": "https://drive.test/rec",
                                                    "recording_notes": "Part 1"})
        self.assertEqual(r.status_code, 302)
        lc.refresh_from_db()
        self.assertEqual(lc.recording_url, "https://drive.test/rec")
        # student sees recording + got notified
        self.client.force_login(self.student)
        r = self.client.get(f"/classes/{lc.pk}/")
        self.assertContains(r, "Watch Recording")
        self.assertTrue(Notification.objects.filter(user=self.student, title__contains="Recording").exists())

    def test_student_cannot_save_recording(self):
        lc = LiveClass.objects.create(track=self.track, teacher=self.teacher, title="C1",
                                      meeting_url="https://x", scheduled_at=timezone.now())
        self.client.force_login(self.student)
        r = self.client.post(f"/classes/{lc.pk}/", {"recording_url": "https://evil.test"})
        self.assertEqual(r.status_code, 404)

    def test_invoice_generated_notifies_student(self):
        plan = FeePlan.objects.create(track=self.track, name="Monthly", amount=Decimal("1000"), currency="PKR")
        self.client.force_login(self.teacher)
        from datetime import date
        self.client.post("/fees/invoices/generate/", {"plan": plan.pk, "period_label": "Nov 2026",
                                                      "due_date": str(date.today())})
        self.assertTrue(Notification.objects.filter(user=self.student, notif_type="fee").exists())

    def test_payment_notifies_student(self):
        plan = FeePlan.objects.create(track=self.track, name="Monthly", amount=Decimal("1000"), currency="PKR")
        from datetime import date
        inv = Invoice.objects.create(student=self.student, fee_plan=plan, period_label="Nov 2026",
                                     amount=Decimal("1000"), currency="PKR", due_date=date.today())
        self.client.force_login(self.teacher)
        self.client.post(f"/fees/invoices/{inv.pk}/", {"amount": "1000", "currency": "PKR", "method": "cash"})
        n = Notification.objects.filter(user=self.student, title__contains="Payment received").first()
        self.assertIsNotNone(n)

    def test_requires_login(self):
        self.assertEqual(self.client.get("/notifications/").status_code, 302)

class FreeChannelsTests(TestCase):
    """Email + WhatsApp helpers: free paths, never break, skip when unconfigured."""

    def setUp(self):
        self.user = User.objects.create_user(email="ch@abp.test", password="x",
                                             role="student", phone="+923001234567")

    def test_notify_never_raises_without_config(self):
        from .models import notify
        n = notify(self.user, "Test title", "Test message")
        self.assertIsNotNone(n)
        self.assertTrue(Notification.objects.filter(user=self.user).exists())

    def test_whatsapp_skipped_without_token(self):
        from .whatsapp import send_whatsapp
        # no WHATSAPP_TOKEN in env -> False, no exception
        self.assertFalse(send_whatsapp("+923001234567", "hello"))

    def test_whatsapp_phone_cleaning(self):
        from .whatsapp import _clean_phone
        self.assertEqual(_clean_phone("+92 300 1234567"), "923001234567")
        self.assertEqual(_clean_phone("0300-1234567"), "03001234567")

    def test_email_not_smtp_without_gmail_env(self):
        import os
        # no GMAIL_USER/GMAIL_APP_PASSWORD env -> must NOT use real SMTP
        self.assertFalse(os.environ.get("GMAIL_USER") and os.environ.get("GMAIL_APP_PASSWORD"))

    def test_email_sent_via_django(self):
        from django.core.mail import send_mail
        send_mail("Subject", "Body", None, ["test@example.com"], fail_silently=True)
        # console backend: no exception = pass

class RecordingEmbedTests(TestCase):
    def setUp(self):
        self.teacher = User.objects.create_user(email="rec_teacher@abp.test", password="x", role="teacher")
        self.student = User.objects.create_user(email="rec_student@abp.test", password="x", role="student")
        self.track = CourseTrack.objects.create(code="rec", name="Rec Track")
        self.lc = LiveClass.objects.create(track=self.track, teacher=self.teacher, title="RC",
                                           meeting_url="https://x", scheduled_at=timezone.now())

    def test_youtube_url_converts_to_embed(self):
        self.lc.recording_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        self.assertEqual(self.lc.youtube_embed_url, "https://www.youtube.com/embed/dQw4w9WgXcQ")
        self.lc.recording_url = "https://youtu.be/dQw4w9WgXcQ"
        self.assertEqual(self.lc.youtube_embed_url, "https://www.youtube.com/embed/dQw4w9WgXcQ")

    def test_non_youtube_url_no_embed(self):
        self.lc.recording_url = "https://drive.google.com/file/d/abc/view"
        self.assertEqual(self.lc.youtube_embed_url, "")

    def test_youtube_embedded_in_portal(self):
        self.lc.recording_url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        self.lc.save()
        self.client.force_login(self.student)
        r = self.client.get(f"/classes/{self.lc.pk}/")
        self.assertContains(r, "youtube.com/embed/dQw4w9WgXcQ")
        self.assertContains(r, "<iframe")

    def test_recording_file_upload(self):
        from django.core.files.uploadedfile import SimpleUploadedFile
        self.client.force_login(self.teacher)
        video = SimpleUploadedFile("rec.webm", b"fake-video-bytes", content_type="video/webm")
        r = self.client.post(f"/classes/{self.lc.pk}/", {"recording_file": video})
        self.assertEqual(r.status_code, 302)
        self.lc.refresh_from_db()
        self.assertTrue(bool(self.lc.recording_file))
        # student sees <video> player inside portal
        self.client.force_login(self.student)
        r = self.client.get(f"/classes/{self.lc.pk}/")
        self.assertContains(r, "<video")

    def test_has_recording_property(self):
        self.assertFalse(self.lc.has_recording)
        self.lc.recording_url = "https://youtube.com/watch?v=abc123xyz45"
        self.assertTrue(self.lc.has_recording)
