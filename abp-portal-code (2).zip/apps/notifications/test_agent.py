"""Tests for the WhatsApp auto-reply agent (Phase 9 addon)."""

import json
from unittest.mock import patch

from django.test import TestCase, override_settings
from django.urls import reverse

from .agent import get_reply


class AgentBrainTests(TestCase):
    def test_greeting(self):
        r = get_reply("Assalam o alaikum")
        self.assertIn("Arabic Bridge Program", r)

    def test_fees(self):
        r = get_reply("fees kitni hai?")
        self.assertIn("Fees", r)

    def test_timings(self):
        r = get_reply("class kab hoti hai")
        self.assertIn("online", r.lower())

    def test_courses(self):
        r = get_reply("kaunse courses hain")
        self.assertIn("Quranic Arabic", r)

    def test_admission(self):
        r = get_reply("admission lena hai")
        self.assertIn("Admission", r)

    def test_teacher_handoff(self):
        r = get_reply("teacher se baat karni hai")
        self.assertIn("teacher", r.lower())

    def test_fallback(self):
        r = get_reply("xyzabc123")
        self.assertIn("courses", r.lower())

    def test_empty(self):
        self.assertTrue(get_reply(""))


@override_settings(WHATSAPP_VERIFY_TOKEN="test-secret-123")
class WebhookTests(TestCase):
    def test_verify_ok(self):
        url = reverse("notifications:whatsapp_webhook")
        r = self.client.get(url, {
            "hub.mode": "subscribe",
            "hub.verify_token": "test-secret-123",
            "hub.challenge": "CHALLENGE123",
        })
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.content.decode(), "CHALLENGE123")

    def test_verify_wrong_token(self):
        url = reverse("notifications:whatsapp_webhook")
        r = self.client.get(url, {
            "hub.mode": "subscribe",
            "hub.verify_token": "wrong",
            "hub.challenge": "CHALLENGE123",
        })
        self.assertEqual(r.status_code, 403)

    def test_incoming_message_replies(self):
        url = reverse("notifications:whatsapp_webhook")
        payload = {"entry": [{"changes": [{"value": {"messages": [
            {"from": "923001234567", "type": "text",
             "text": {"body": "fees kitni hai?"}}
        ]}}]}]}
        with patch("apps.notifications.views.send_whatsapp") as mock_send:
            r = self.client.post(url, json.dumps(payload),
                                 content_type="application/json")
        self.assertEqual(r.status_code, 200)
        mock_send.assert_called_once()
        to, reply = mock_send.call_args[0]
        self.assertEqual(to, "923001234567")
        self.assertIn("Fees", reply)

    def test_non_text_ignored(self):
        url = reverse("notifications:whatsapp_webhook")
        payload = {"entry": [{"changes": [{"value": {"messages": [
            {"from": "923001234567", "type": "image"}
        ]}}]}]}
        with patch("apps.notifications.views.send_whatsapp") as mock_send:
            r = self.client.post(url, json.dumps(payload),
                                 content_type="application/json")
        self.assertEqual(r.status_code, 200)
        mock_send.assert_not_called()
