"""Phase 7 — In-portal notifications (free). Email hooks ready for later."""

from django.conf import settings
from django.db import models
from django.urls import reverse


class Notification(models.Model):
    """A bell notification for one user."""

    TYPE_HOMEWORK = "homework"
    TYPE_GRADE = "grade"
    TYPE_CLASS = "class"
    TYPE_FEE = "fee"
    TYPE_GENERAL = "general"
    TYPE_CHOICES = [
        (TYPE_HOMEWORK, "Homework"),
        (TYPE_GRADE, "Grade"),
        (TYPE_CLASS, "Class"),
        (TYPE_FEE, "Fee"),
        (TYPE_GENERAL, "General"),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications"
    )
    title = models.CharField(max_length=200)
    message = models.TextField(blank=True)
    link = models.CharField(max_length=500, blank=True,
                            help_text="Portal URL the bell links to.")
    notif_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_GENERAL)
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.user.email}: {self.title}"


def notify(user, title, message="", link="", notif_type=Notification.TYPE_GENERAL):
    """Create one notification. Never raises (notifications must not break flows).

    Also tries free Email (Gmail SMTP, if configured) and free WhatsApp
    (Meta Cloud API, if configured) — both best-effort, failures are silent.
    """
    try:
        notif = Notification.objects.create(
            user=user, title=title, message=message, link=link, notif_type=notif_type
        )
    except Exception:
        return None
    _send_email(user, title, message)
    _send_whatsapp(user, title, message)
    return notif


def _send_email(user, title, message):
    try:
        from django.core.mail import send_mail

        if not getattr(user, "email", ""):
            return
        # Dev: console backend prints it. Prod (Gmail env set): really sends. Free 500/day.
        send_mail(title, message or title, None, [user.email], fail_silently=True)
    except Exception:
        pass


def _send_whatsapp(user, title, message):
    try:
        from .whatsapp import send_whatsapp

        phone = getattr(user, "phone", "") or ""
        if not phone:
            return
        text = f"*Arabic Bridge Program*\n{title}"
        if message:
            text += f"\n{message}"
        send_whatsapp(phone, text)
    except Exception:
        pass


def notify_many(users, title, message="", link="", notif_type=Notification.TYPE_GENERAL):
    for u in users:
        notify(u, title, message, link, notif_type)


def homework_url(pk):
    return reverse("homework:homework_detail", args=[pk])


def class_url(pk):
    return reverse("classes:class_detail", args=[pk])


def invoice_url(pk):
    return reverse("fees:invoice_detail", args=[pk])
