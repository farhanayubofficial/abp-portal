"""Phase 1 tests: student IDs, admission flow, role-based access."""
from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import Application, AuditLog, StudentProfile, generate_student_id
from apps.accounts.services import approve_application, reject_application
from apps.courses.models import CourseTrack

User = get_user_model()


class StudentIDTests(TestCase):
    def test_ids_are_sequential_unique_and_formatted(self):
        ids = [generate_student_id() for _ in range(3)]
        self.assertEqual(len(set(ids)), 3)
        for i, sid in enumerate(ids, start=1):
            self.assertRegex(sid, r"^ABP-\d{4}-\d{4}$")
            self.assertTrue(sid.endswith(f"{i:04d}"))


class AdmissionFlowTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(
            email="admin@abp.test", password="x", first_name="A", last_name="B",
            role=User.ROLE_ADMIN,
        )
        self.track = CourseTrack.objects.get(code="quranic-arabic")
        self.app = Application.objects.create(
            name="Test Student", email="student@abp.test", phone="+920000000000"
        )
        self.app.requested_tracks.add(self.track)

    def test_approve_creates_user_profile_and_audit(self):
        user, profile, raw_password = approve_application(self.app, self.admin)
        self.assertTrue(raw_password)
        self.assertTrue(user.check_password(raw_password))  # hashed, verifiable
        self.assertEqual(user.role, User.ROLE_STUDENT)
        self.assertRegex(profile.student_id, r"^ABP-\d{4}-\d{4}$")
        self.assertIn(self.track, profile.tracks.all())
        self.app.refresh_from_db()
        self.assertEqual(self.app.status, Application.STATUS_APPROVED)
        self.assertEqual(self.app.created_user, user)
        self.assertTrue(AuditLog.objects.filter(action="application.approved").exists())

    def test_reject_creates_no_account(self):
        reject_application(self.app, self.admin, notes="incomplete")
        self.app.refresh_from_db()
        self.assertEqual(self.app.status, Application.STATUS_REJECTED)
        self.assertFalse(User.objects.filter(email="student@abp.test").exists())

    def test_double_approval_blocked(self):
        approve_application(self.app, self.admin)
        with self.assertRaises(ValueError):
            approve_application(self.app, self.admin)

    def test_second_student_gets_next_id(self):
        _, p1, _ = approve_application(self.app, self.admin)
        app2 = Application.objects.create(name="Two", email="two@abp.test", phone="1")
        _, p2, _ = approve_application(app2, self.admin)
        self.assertNotEqual(p1.student_id, p2.student_id)
        n1 = int(p1.student_id.rsplit("-", 1)[1])
        n2 = int(p2.student_id.rsplit("-", 1)[1])
        self.assertEqual(n2, n1 + 1)


class AccessControlTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_superuser(
            email="admin@abp.test", password="pw", first_name="A", last_name="B",
            role=User.ROLE_ADMIN,
        )
        self.student_user = User.objects.create_user(
            email="s@abp.test", password="pw", first_name="S", last_name="T",
            role=User.ROLE_STUDENT,
        )
        StudentProfile.objects.create(user=self.student_user, student_id=generate_student_id())

    def test_student_cannot_open_staff_application_list(self):
        self.client.force_login(self.student_user)
        resp = self.client.get(reverse("application_list"))
        self.assertIn(resp.status_code, (302, 403))

    def test_anonymous_redirected_to_login_for_dashboard(self):
        resp = self.client.get(reverse("dashboard"))
        self.assertEqual(resp.status_code, 302)
        self.assertIn(reverse("login"), resp.url)

    def test_admin_can_open_application_list(self):
        self.client.force_login(self.admin)
        resp = self.client.get(reverse("application_list"))
        self.assertEqual(resp.status_code, 200)

    def test_student_dashboard_renders(self):
        self.client.force_login(self.student_user)
        resp = self.client.get(reverse("dashboard"))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, self.student_user.student_profile.student_id)

    def test_public_pages_render(self):
        for name in ("landing", "login", "apply"):
            resp = self.client.get(reverse(name))
            self.assertEqual(resp.status_code, 200, name)
