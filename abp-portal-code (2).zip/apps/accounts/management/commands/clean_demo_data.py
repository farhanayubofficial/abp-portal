"""Remove all demo/test data before production. Keeps curriculum (tracks/lessons/exercises).

Deletes: users with @abp.test emails and everything tied to them
(submissions, invoices, payments, notifications, certificates, attempts,
progress, attendance, classes, homework created by them).
"""

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand

User = get_user_model()


class Command(BaseCommand):
    help = "Delete demo/test users (@abp.test) and their data. Curriculum stays."

    def add_arguments(self, parser):
        parser.add_argument("--yes", action="store_true", help="Skip confirmation.")

    def handle(self, *args, **options):
        demo_users = User.objects.filter(email__endswith="@abp.test")
        count = demo_users.count()
        if count == 0:
            self.stdout.write("No demo users found. Nothing to clean.")
            return
        if not options["yes"]:
            confirm = input(f"Delete {count} demo users and ALL their data? [y/N] ")
            if confirm.lower() != "y":
                self.stdout.write("Cancelled.")
                return
        # Cascades handle: submissions, invoices, payments, notifications,
        # certificates, attempts, progress, salary records, created classes/homework.
        demo_users.delete()
        # Demo content with no owner tie (belt & braces)
        from apps.homework.models import Homework
        from apps.fees.models import FeePlan
        from apps.classes.models import LiveClass
        Homework.objects.all().delete()
        FeePlan.objects.all().delete()
        LiveClass.objects.all().delete()
        self.stdout.write(self.style.SUCCESS(
            f"Deleted {count} demo users + demo homework/fees/classes. Curriculum kept."))
