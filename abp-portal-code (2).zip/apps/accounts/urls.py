from django.contrib.auth import views as auth_views
from django.urls import path

from . import views

urlpatterns = [
    path("login/", auth_views.LoginView.as_view(template_name="accounts/login.html"), name="login"),
    path("logout/", auth_views.LogoutView.as_view(), name="logout"),
    path(
        "password-reset/",
        auth_views.PasswordResetView.as_view(template_name="registration/password_reset_form.html"),
        name="password_reset",
    ),
    path(
        "password-reset/done/",
        auth_views.PasswordResetDoneView.as_view(template_name="registration/password_reset_done.html"),
        name="password_reset_done",
    ),
    path(
        "reset/<uidb64>/<token>/",
        auth_views.PasswordResetConfirmView.as_view(
            template_name="registration/password_reset_confirm.html"
        ),
        name="password_reset_confirm",
    ),
    path(
        "reset/done/",
        auth_views.PasswordResetCompleteView.as_view(
            template_name="registration/password_reset_complete.html"
        ),
        name="password_reset_complete",
    ),
    path("apply/", views.ApplicationCreateView.as_view(), name="apply"),
    path("apply/success/", views.ApplicationSuccessView.as_view(), name="apply_success"),
    path("dashboard/", views.DashboardView.as_view(), name="dashboard"),
    path("staff/applications/", views.ApplicationListView.as_view(), name="application_list"),
    path(
        "staff/applications/<int:pk>/approve/",
        views.application_approve,
        name="application_approve",
    ),
    path(
        "staff/applications/<int:pk>/reject/",
        views.application_reject,
        name="application_reject",
    ),
]
