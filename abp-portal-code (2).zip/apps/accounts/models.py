"""Accounts domain: users, roles, applications, student IDs, guardians, audit log."""
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models, transaction
from django.utils import timezone

from apps.courses.models import CourseTrack


class UserManager(BaseUserManager):
    """Manager for the email-login user (no username field)."""

    use_in_migrations = True

    def _create_user(self, email, password, **extra_fields):
        if not email:
            raise ValueError("An email address is required.")
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_user(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        return self._create_user(email, password, **extra_fields)

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")
        return self._create_user(email, password, **extra_fields)


class User(AbstractUser):
    """Single user table for all roles. Email is the login identity."""

    ROLE_ADMIN = "admin"
    ROLE_TEACHER = "teacher"
    ROLE_STUDENT = "student"
    ROLE_GUARDIAN = "guardian"
    ROLE_CHOICES = [
        (ROLE_ADMIN, "Administrator"),
        (ROLE_TEACHER, "Teacher"),
        (ROLE_STUDENT, "Student"),
        (ROLE_GUARDIAN, "Guardian"),
    ]

    username = None  # email is the login field
    email = models.EmailField("email address", unique=True)
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=ROLE_STUDENT)
    phone = models.CharField(max_length=30, blank=True)
    email_verified = models.BooleanField(default=False)

    USERNAME_FIELD = "email"
    REQUIRED_FIELDS = ["first_name", "last_name"]

    objects = UserManager()

    class Meta:
        ordering = ["email"]

    def __str__(self):
        return f"{self.get_full_name() or self.email} ({self.get_role_display()})"

    # Role helpers used by permission checks
    @property
    def is_admin(self):
        return self.role == self.ROLE_ADMIN or self.is_superuser

    @property
    def is_teacher(self):
        return self.role == self.ROLE_TEACHER

    @property
    def is_student(self):
        return self.role == self.ROLE_STUDENT

    @property
    def is_guardian(self):
        return self.role == self.ROLE_GUARDIAN


class StudentIDSequence(models.Model):
    """Per-year counter for student IDs. Never edited by hand."""

    year = models.PositiveIntegerField(unique=True)
    last_number = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.year}: {self.last_number}"


def generate_student_id() -> str:
    """Return the next unique student ID like ABP-2026-0001.

    Concurrency-safe: the counter row is locked inside a transaction so two
    simultaneous admissions can never receive the same ID.
    """
    year = timezone.now().year
    with transaction.atomic():
        seq, _ = StudentIDSequence.objects.select_for_update().get_or_create(year=year)
        seq.last_number += 1
        seq.save(update_fields=["last_number"])
    return f"ABP-{year}-{seq.last_number:04d}"


class Application(models.Model):
    """A prospective student's registration request. Pending until decided."""

    STATUS_PENDING = "pending"
    STATUS_APPROVED = "approved"
    STATUS_REJECTED = "rejected"
    STATUS_CHOICES = [
        (STATUS_PENDING, "Pending"),
        (STATUS_APPROVED, "Approved"),
        (STATUS_REJECTED, "Rejected"),
    ]

    name = models.CharField(max_length=150)
    email = models.EmailField()
    phone = models.CharField(max_length=30)
    requested_tracks = models.ManyToManyField(CourseTrack, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    submitted_at = models.DateTimeField(auto_now_add=True)
    decided_at = models.DateTimeField(null=True, blank=True)
    decided_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="decided_applications"
    )
    decision_notes = models.TextField(blank=True)
    # Link to the account created on approval (history preservation)
    created_user = models.OneToOneField(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="application"
    )

    class Meta:
        ordering = ["-submitted_at"]

    def __str__(self):
        return f"{self.name} <{self.email}> [{self.get_status_display()}]"


class StudentProfile(models.Model):
    """Student record. The student_id is permanent and independent of the DB pk."""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="student_profile")
    student_id = models.CharField(max_length=20, unique=True, db_index=True)
    tracks = models.ManyToManyField(CourseTrack, blank=True)
    is_enrolled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.student_id} — {self.user.get_full_name() or self.user.email}"


class GuardianProfile(models.Model):
    """Guardian account. Links to children only after admin verification."""

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="guardian_profile")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Guardian: {self.user.get_full_name() or self.user.email}"

    def verified_children(self):
        return self.links.filter(verified=True)


class GuardianLink(models.Model):
    """Verified link between a guardian and a student."""

    guardian = models.ForeignKey(GuardianProfile, on_delete=models.CASCADE, related_name="links")
    student = models.ForeignKey(StudentProfile, on_delete=models.CASCADE, related_name="guardian_links")
    verified = models.BooleanField(default=False)
    verified_by = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.SET_NULL, related_name="verified_guardian_links"
    )
    verified_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [("guardian", "student")]

    def __str__(self):
        state = "verified" if self.verified else "unverified"
        return f"{self.guardian} -> {self.student} ({state})"


class AuditLog(models.Model):
    """Immutable record of important administrative actions."""

    actor = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, related_name="audit_actions")
    action = models.CharField(max_length=100)
    details = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.created_at:%Y-%m-%d %H:%M} — {self.actor} — {self.action}"


def log_action(actor, action, details=""):
    """Helper to record an audit entry."""
    return AuditLog.objects.create(actor=actor, action=action, details=details)
