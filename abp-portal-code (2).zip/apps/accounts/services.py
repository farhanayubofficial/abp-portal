"""Business logic for admissions. Kept out of views so it is testable."""
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.db import transaction
from django.utils import timezone
from django.utils.crypto import get_random_string

from .models import Application, StudentProfile, generate_student_id, log_action

User = get_user_model()


def _split_name(full_name):
    parts = full_name.strip().split(None, 1)
    if len(parts) == 2:
        return parts[0], parts[1]
    return parts[0], ""


@transaction.atomic
def approve_application(application: Application, admin_user, password: str | None = None):
    """Approve a pending application: create the user + student profile with a
    unique student ID. Returns (user, student_profile, raw_password).

    The raw password is returned ONCE so the admin can share it with the
    student through a secure channel. It is never stored in plain text.
    """
    if application.status != Application.STATUS_PENDING:
        raise ValueError("Only pending applications can be approved.")

    first_name, last_name = _split_name(application.name)
    raw_password = password or get_random_string(12)
    user = User.objects.create_user(
        email=application.email,
        password=raw_password,
        first_name=first_name,
        last_name=last_name,
        phone=application.phone,
        role=User.ROLE_STUDENT,
        is_active=True,
    )
    profile = StudentProfile.objects.create(user=user, student_id=generate_student_id())
    profile.tracks.set(application.requested_tracks.all())

    application.status = Application.STATUS_APPROVED
    application.decided_at = timezone.now()
    application.decided_by = admin_user
    application.created_user = user
    application.save()

    log_action(
        admin_user,
        "application.approved",
        f"Approved {application.name} <{application.email}> as {profile.student_id}",
    )
    return user, profile, raw_password


@transaction.atomic
def reject_application(application: Application, admin_user, notes: str = ""):
    """Reject a pending application. No account is created."""
    if application.status != Application.STATUS_PENDING:
        raise ValueError("Only pending applications can be rejected.")
    application.status = Application.STATUS_REJECTED
    application.decided_at = timezone.now()
    application.decided_by = admin_user
    application.decision_notes = notes
    application.save()
    log_action(
        admin_user,
        "application.rejected",
        f"Rejected {application.name} <{application.email}>. Notes: {notes or '-'}",
    )
    return application


def password_reset_token(user):
    """Token for building a secure password-reset link."""
    return default_token_generator.make_token(user)
