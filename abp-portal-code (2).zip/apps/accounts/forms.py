from django import forms

from apps.courses.models import CourseTrack

from .models import Application


class ApplicationForm(forms.ModelForm):
    """Public student registration application (spec section 6)."""

    requested_tracks = forms.ModelMultipleChoiceField(
        queryset=CourseTrack.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False,
        label="Requested courses",
    )

    class Meta:
        model = Application
        fields = ["name", "email", "phone", "requested_tracks"]
        widgets = {
            "name": forms.TextInput(attrs={"placeholder": "Full name"}),
            "email": forms.EmailInput(attrs={"placeholder": "you@example.com"}),
            "phone": forms.TextInput(attrs={"placeholder": "+92 ..."}),
        }

    def clean_email(self):
        email = self.cleaned_data["email"].lower()
        if Application.objects.filter(email__iexact=email, status=Application.STATUS_PENDING).exists():
            raise forms.ValidationError("An application with this email is already pending review.")
        return email
