"""Speaking Videos views: student submit/list + teacher review."""

from django.contrib.auth.decorators import login_required, user_passes_test
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from .models import SpeakingSubmission, this_week_monday


def _is_staff_teacher(u):
    return u.is_authenticated and (u.is_teacher or u.is_admin)


@login_required
def my_videos(request):
    subs = SpeakingSubmission.objects.filter(student=request.user)
    monday = this_week_monday()
    week_done = subs.filter(week_start=monday).exists()
    return render(request, "speaking/my_videos.html", {
        "subs": subs, "week_done": week_done, "monday": monday,
    })


@login_required
def submit(request):
    """One endpoint: camera-recorded blob, file upload, or YouTube link."""
    if request.method == "POST":
        title = (request.POST.get("title") or "").strip() or "Weekly speaking"
        youtube_url = (request.POST.get("youtube_url") or "").strip()
        video_file = request.FILES.get("recording_file") or request.FILES.get("video_file")
        audio_file = request.FILES.get("audio_file")
        if not (video_file or audio_file or youtube_url):
            return render(request, "speaking/submit.html", {
                "error": "Video record karein, file upload karein, ya YouTube link dein."})
        sub = SpeakingSubmission(
            student=request.user, title=title, youtube_url=youtube_url,
            week_start=this_week_monday())
        if video_file:
            sub.video_file.save(video_file.name, video_file)
        if audio_file:
            sub.audio_file.save(audio_file.name, audio_file)
        sub.save()
        return redirect("speaking:my_videos")
    return render(request, "speaking/submit.html")


@login_required
@user_passes_test(_is_staff_teacher)
def teacher_list(request):
    subs = SpeakingSubmission.objects.select_related("student").all()
    student_id = request.GET.get("student")
    if student_id:
        subs = subs.filter(student_id=student_id)
    return render(request, "speaking/teacher_list.html", {"subs": subs[:200]})


@login_required
@user_passes_test(_is_staff_teacher)
def give_feedback(request, pk):
    sub = get_object_or_404(SpeakingSubmission, pk=pk)
    if request.method == "POST":
        sub.teacher_feedback = request.POST.get("teacher_feedback", "").strip()
        sub.feedback_at = timezone.now()
        sub.save(update_fields=["teacher_feedback", "feedback_at"])
    return redirect("speaking:teacher_list")
