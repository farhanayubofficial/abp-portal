from django.contrib import admin

from .models import SpeakingSubmission


@admin.register(SpeakingSubmission)
class SpeakingSubmissionAdmin(admin.ModelAdmin):
    list_display = ("student", "title", "week_start", "has_media",
                    "created_at")
    list_filter = ("week_start",)
    search_fields = ("student__email", "title")
    readonly_fields = ("created_at",)
