"""Speaking Videos: students record/upload weekly Arabic speaking videos.

Videos are NEVER deleted by students (no delete view) — they accumulate as
a permanent confidence/progress portfolio. Teacher watches and gives feedback.
Long videos should use the YouTube-link option (free hosting has little disk).
"""

import re
from datetime import date, timedelta

from django.conf import settings
from django.db import models


def this_week_monday():
    return date.today() - timedelta(days=date.today().weekday())


class SpeakingSubmission(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="speaking_submissions")
    title = models.CharField(max_length=200, help_text="Topic of the video")
    video_file = models.FileField(upload_to="speaking_videos/",
                                   blank=True, null=True)
    audio_file = models.FileField(upload_to="speaking_audio/",
                                   blank=True, null=True)
    youtube_url = models.URLField(blank=True,
                                  help_text="YouTube (unlisted) link for long videos")
    week_start = models.DateField(default=this_week_monday,
                                  help_text="Monday of the week this counts for")
    teacher_feedback = models.TextField(blank=True)
    feedback_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — {self.title}"

    def youtube_embed_id(self):
        """Extract the 11-char video id from a YouTube URL."""
        m = re.search(r"(?:v=|youtu\.be/|embed/)([\w-]{11})", self.youtube_url or "")
        return m.group(1) if m else ""

    @property
    def has_media(self):
        return bool(self.video_file or self.audio_file or self.youtube_url)
