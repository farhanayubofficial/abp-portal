"""Phase 8 views: progress reports, certificates (free PDF)."""

from io import BytesIO

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.views import View
from django.views.generic import ListView, TemplateView

from apps.accounts.models import AuditLog, User

from .models import Certificate
from .services import is_track_complete, student_track_report


class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        u = self.request.user
        return u.is_authenticated and (u.is_teacher or u.is_admin)


class MyReportView(LoginRequiredMixin, TemplateView):
    """Student: own progress report across enrolled tracks."""

    template_name = "reports/my_report.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        u = self.request.user
        try:
            tracks = u.student_profile.tracks.all()
        except Exception:
            tracks = []
        ctx["reports"] = [student_track_report(u, t) for t in tracks]
        ctx["certificates"] = Certificate.objects.filter(student=u).select_related("track")
        return ctx


class StudentReportView(StaffRequiredMixin, TemplateView):
    """Staff: one student's full report."""

    template_name = "reports/student_report.html"

    def get_context_data(self, **kwargs):
        from apps.courses.models import CourseTrack

        ctx = super().get_context_data(**kwargs)
        student = get_object_or_404(User, pk=kwargs["pk"])
        ctx["student"] = student
        try:
            tracks = student.student_profile.tracks.all()
        except Exception:
            tracks = CourseTrack.objects.all()
        rows = []
        for t in tracks:
            rep = student_track_report(student, t)
            rep["complete"] = is_track_complete(student, t)
            rep["certificate"] = Certificate.objects.filter(student=student, track=t).first()
            rows.append(rep)
        ctx["reports"] = rows
        return ctx


class StudentListView(StaffRequiredMixin, ListView):
    """Staff: pick a student to view report."""

    template_name = "reports/student_list.html"
    context_object_name = "students"

    def get_queryset(self):
        return User.objects.filter(role="student").order_by("email")[:200]


class IssueCertificateView(StaffRequiredMixin, View):
    """Staff: issue certificate when track complete."""

    def post(self, request, pk, track_id):
        from apps.courses.models import CourseTrack

        student = get_object_or_404(User, pk=pk)
        track = get_object_or_404(CourseTrack, pk=track_id)
        if not is_track_complete(student, track):
            messages.error(request, "Track not complete yet — certificate cannot be issued.")
            return redirect("reports:student_report", pk=pk)
        cert, created = Certificate.objects.get_or_create(
            student=student, track=track, defaults={"issued_by": request.user}
        )
        if created:
            AuditLog.objects.create(actor=request.user, action="certificate_issued",
                                    details=f"{cert.certificate_no} → {student.email} ({track.name})")
            from apps.notifications.models import notify, Notification
            from django.urls import reverse
            notify(student, f"Certificate issued: {track.name}",
                   f"Certificate No. {cert.certificate_no}",
                   reverse("reports:certificate_pdf", args=[cert.pk]),
                   Notification.TYPE_GENERAL)
            messages.success(request, f"Certificate {cert.certificate_no} issued.")
        else:
            messages.info(request, "Certificate already issued.")
        return redirect("reports:student_report", pk=pk)


class CertificatePDFView(LoginRequiredMixin, View):
    """Free PDF certificate (reportlab). Student sees own; staff sees all."""

    def get(self, request, pk):
        cert = get_object_or_404(
            Certificate.objects.select_related("student", "track"), pk=pk)
        u = request.user
        if not (u.is_teacher or u.is_admin) and cert.student != u:
            raise Http404
        buf = BytesIO()
        self._build_pdf(buf, cert)
        buf.seek(0)
        return FileResponse(buf, as_attachment=True,
                            filename=f"certificate-{cert.certificate_no}.pdf",
                            content_type="application/pdf")

    def _build_pdf(self, buf, cert):
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas

        c = canvas.Canvas(buf, pagesize=landscape(A4))
        w, h = landscape(A4)
        # gold border
        c.setStrokeColorRGB(0.78, 0.63, 0.36)
        c.setLineWidth(4)
        c.rect(12 * mm, 12 * mm, w - 24 * mm, h - 24 * mm)
        c.setLineWidth(1)
        c.rect(16 * mm, 16 * mm, w - 32 * mm, h - 32 * mm)

        cx = w / 2
        y = h - 45 * mm
        c.setFont("Helvetica-Bold", 28)
        c.setFillColorRGB(0.09, 0.16, 0.30)
        c.drawCentredString(cx, y, "Certificate of Completion")
        y -= 14 * mm
        c.setFont("Helvetica", 14)
        c.drawCentredString(cx, y, "Arabic Bridge Program")
        y -= 16 * mm
        c.setFont("Helvetica", 12)
        c.drawCentredString(cx, y, "This certificate is proudly presented to")
        y -= 14 * mm
        c.setFont("Helvetica-Bold", 22)
        name = cert.student.get_full_name() or cert.student.email
        c.drawCentredString(cx, y, name)
        y -= 12 * mm
        c.setFont("Helvetica", 13)
        c.drawCentredString(cx, y, f"for successfully completing the {cert.track.name} track")
        y -= 16 * mm
        c.setFont("Helvetica", 11)
        c.drawCentredString(cx, y, f"Certificate No: {cert.certificate_no}")
        y -= 8 * mm
        c.drawCentredString(cx, y, f"Issued: {cert.issued_at.strftime('%d %B %Y')}")
        y -= 18 * mm
        c.setFont("Helvetica-Oblique", 11)
        c.drawCentredString(cx, y, "Founded and Managed by Farhan Khan")
        c.showPage()
        c.save()
