"""Phase 8: progress report computation (free, pure Django ORM)."""

from django.db.models import Avg, Count, Q

from apps.classes.models import ClassAttendance
from apps.courses.models import ExerciseAttempt, Lesson, LessonProgress
from apps.homework.models import Submission


def student_track_report(student, track):
    """Full progress report for one student in one track."""
    lessons = Lesson.objects.filter(track=track, status=Lesson.STATUS_PUBLISHED)
    total_lessons = lessons.count()
    completed = LessonProgress.objects.filter(
        student=student, lesson__in=lessons, status=LessonProgress.STATUS_COMPLETED
    ).count()

    attempts = ExerciseAttempt.objects.filter(student=student, exercise__lesson__track=track)
    quiz_answered = attempts.count()
    quiz_correct = attempts.filter(is_correct=True).count()

    subs = Submission.objects.filter(student=student, homework__track=track)
    hw_submitted = subs.count()
    hw_graded = subs.filter(status=Submission.STATUS_GRADED)
    hw_avg = hw_graded.aggregate(a=Avg("marks"))["a"]

    att = ClassAttendance.objects.filter(student=student, live_class__track=track)
    att_total = att.count()
    att_present = att.filter(status__in=[ClassAttendance.PRESENT, ClassAttendance.LATE]).count()

    return {
        "track": track,
        "lessons_total": total_lessons,
        "lessons_done": completed,
        "lessons_pct": round(completed / total_lessons * 100) if total_lessons else 0,
        "quiz_answered": quiz_answered,
        "quiz_correct": quiz_correct,
        "quiz_pct": round(quiz_correct / quiz_answered * 100) if quiz_answered else 0,
        "hw_submitted": hw_submitted,
        "hw_avg": round(hw_avg, 1) if hw_avg is not None else None,
        "att_total": att_total,
        "att_present": att_present,
        "att_pct": round(att_present / att_total * 100) if att_total else 0,
    }


def is_track_complete(student, track):
    """True when every published lesson of the track is completed."""
    rep = student_track_report(student, track)
    return rep["lessons_total"] > 0 and rep["lessons_done"] == rep["lessons_total"]
