"""Phase 8 tests: progress reports, certificates, PDF, backup."""

from django.contrib.auth import get_user_model
from django.test import TestCase

from apps.accounts.models import StudentProfile
from apps.courses.models import CourseTrack, Exercise, Lesson, LessonProgress

from .models import Certificate
from .services import is_track_complete, student_track_report

User = get_user_model()


class Phase8Tests(TestCase):
    def setUp(self):
        self.teacher = User.objects.create_user(email="rep_teacher@abp.test", password="x", role="teacher")
        self.student = User.objects.create_user(email="rep_student@abp.test", password="x", role="student")
        self.track = CourseTrack.objects.create(code="rept", name="Report Track")
        self.profile = StudentProfile.objects.create(user=self.student, student_id="R001")
        self.profile.tracks.add(self.track)
        self.lesson1 = Lesson.objects.create(track=self.track, title="L1", order=1, status="published")
        self.lesson2 = Lesson.objects.create(track=self.track, title="L2", order=2, status="published")

    def test_my_report(self):
        self.client.force_login(self.student)
        r = self.client.get("/reports/my/")
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Report Track")

    def test_report_requires_login(self):
        self.assertEqual(self.client.get("/reports/my/").status_code, 302)

    def test_staff_student_report(self):
        self.client.force_login(self.teacher)
        r = self.client.get(f"/reports/students/{self.student.pk}/")
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "rep_student@abp.test")

    def test_student_cannot_view_others_report(self):
        other = User.objects.create_user(email="other2@abp.test", password="x", role="student")
        self.client.force_login(other)
        r = self.client.get(f"/reports/students/{self.student.pk}/")
        self.assertEqual(r.status_code, 403)

    def test_report_numbers(self):
        LessonProgress.objects.create(student=self.student, lesson=self.lesson1,
                                      status=LessonProgress.STATUS_COMPLETED)
        rep = student_track_report(self.student, self.track)
        self.assertEqual(rep["lessons_total"], 2)
        self.assertEqual(rep["lessons_done"], 1)
        self.assertEqual(rep["lessons_pct"], 50)
        self.assertFalse(is_track_complete(self.student, self.track))
        LessonProgress.objects.create(student=self.student, lesson=self.lesson2,
                                      status=LessonProgress.STATUS_COMPLETED)
        self.assertTrue(is_track_complete(self.student, self.track))

    def test_issue_certificate_only_when_complete(self):
        self.client.force_login(self.teacher)
        # not complete yet
        r = self.client.post(f"/reports/students/{self.student.pk}/issue/{self.track.pk}/")
        self.assertEqual(r.status_code, 302)
        self.assertFalse(Certificate.objects.filter(student=self.student).exists())
        # complete both lessons
        for lesson in (self.lesson1, self.lesson2):
            LessonProgress.objects.create(student=self.student, lesson=lesson,
                                          status=LessonProgress.STATUS_COMPLETED)
        r = self.client.post(f"/reports/students/{self.student.pk}/issue/{self.track.pk}/")
        cert = Certificate.objects.filter(student=self.student, track=self.track).first()
        self.assertIsNotNone(cert)
        self.assertTrue(cert.certificate_no.startswith("ABP-"))
        # duplicate issue doesn't create another
        self.client.post(f"/reports/students/{self.student.pk}/issue/{self.track.pk}/")
        self.assertEqual(Certificate.objects.filter(student=self.student).count(), 1)

    def test_certificate_pdf_download(self):
        cert = Certificate.objects.create(student=self.student, track=self.track,
                                          issued_by=self.teacher)
        self.client.force_login(self.student)
        r = self.client.get(f"/reports/certificate/{cert.pk}/pdf/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r["Content-Type"], "application/pdf")

    def test_student_cannot_download_others_certificate(self):
        other = User.objects.create_user(email="other3@abp.test", password="x", role="student")
        cert = Certificate.objects.create(student=other, track=self.track, issued_by=self.teacher)
        self.client.force_login(self.student)
        self.assertEqual(self.client.get(f"/reports/certificate/{cert.pk}/pdf/").status_code, 404)

    def test_certificate_notification_sent(self):
        from apps.notifications.models import Notification
        for lesson in (self.lesson1, self.lesson2):
            LessonProgress.objects.create(student=self.student, lesson=lesson,
                                          status=LessonProgress.STATUS_COMPLETED)
        self.client.force_login(self.teacher)
        self.client.post(f"/reports/students/{self.student.pk}/issue/{self.track.pk}/")
        self.assertTrue(Notification.objects.filter(
            user=self.student, title__contains="Certificate").exists())

    def test_backup_command(self):
        from django.core.management import call_command
        # in-memory test DB: command must not crash
        call_command("backup_db")
