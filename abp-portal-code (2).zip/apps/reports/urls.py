from django.urls import path

from . import views

app_name = "reports"

urlpatterns = [
    path("my/", views.MyReportView.as_view(), name="my_report"),
    path("students/", views.StudentListView.as_view(), name="student_list"),
    path("students/<int:pk>/", views.StudentReportView.as_view(), name="student_report"),
    path("students/<int:pk>/issue/<int:track_id>/", views.IssueCertificateView.as_view(), name="issue_certificate"),
    path("certificate/<int:pk>/pdf/", views.CertificatePDFView.as_view(), name="certificate_pdf"),
]
