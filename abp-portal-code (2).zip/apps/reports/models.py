"""Phase 8 — Reports & Certificates (all free)."""

import uuid

from django.conf import settings
from django.db import models


def _cert_no():
    return "ABP-" + uuid.uuid4().hex[:8].upper()


class Certificate(models.Model):
    """Completion certificate for a student finishing a track."""

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="certificates"
    )
    track = models.ForeignKey(
        "courses.CourseTrack", on_delete=models.CASCADE, related_name="certificates"
    )
    certificate_no = models.CharField(max_length=20, unique=True, default=_cert_no)
    issued_at = models.DateTimeField(auto_now_add=True)
    issued_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="issued_certificates",
    )

    class Meta:
        ordering = ["-issued_at"]
        unique_together = [("student", "track")]

    def __str__(self):
        return f"{self.certificate_no} — {self.student.email} ({self.track.name})"
