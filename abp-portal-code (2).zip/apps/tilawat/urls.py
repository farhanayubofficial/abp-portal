from django.urls import path

from . import views

app_name = "tilawat"

urlpatterns = [
    path("", views.home, name="home"),
    path("create/", views.create, name="create"),
    path("session/<int:pk>/", views.detail, name="detail"),
    path("session/<int:pk>/toggle/", views.toggle_active, name="toggle"),
    path("practice/<int:pk>/", views.practice, name="practice"),
]
