"""Tilawat Practice tests (Phase 17)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import TilawatResult, TilawatSession
from .translations import get_translation


def make_user(email, role):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class TilawatTests(TestCase):
    def setUp(self):
        self.teacher = make_user("t@x.com", User.ROLE_TEACHER)
        self.student = make_user("s@x.com", User.ROLE_STUDENT)
        self.sess = TilawatSession.objects.create(
            surah_number=112, ayat_from=1, ayat_to=2, total_marks=20,
            created_by=self.teacher)
        self.sess.students.add(self.student)

    def test_translations_loaded(self):
        en = get_translation(112, 1, "en")
        ur = get_translation(112, 1, "ur")
        self.assertTrue(len(en) > 10)
        self.assertTrue(len(ur) > 5)

    def test_teacher_create(self):
        self.client.force_login(self.teacher)
        r = self.client.post(reverse("tilawat:create"), {
            "surah": 112, "ayat_from": 1, "ayat_to": 3,
            "total_marks": 30, "students": [self.student.pk]})
        self.assertEqual(r.status_code, 302)
        s = TilawatSession.objects.get(total_marks=30)
        self.assertEqual(s.marks_per_ayat(), 10.0)

    def test_practice_page(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("tilawat:practice", args=[self.sess.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "112001.mp3")  # qari audio
        self.assertContains(r, "Tarjuma")

    def test_submit_ayat(self):
        self.client.force_login(self.student)
        url = reverse("tilawat:practice", args=[self.sess.pk])
        r = self.client.post(
            url, json.dumps({"ayat": 1, "mistakes": 2}),
            content_type="application/json")
        d = r.json()
        self.assertTrue(d["ok"])
        # 10 per ayat - 2 mistakes = 8
        self.assertEqual(d["ayat_score"], 8.0)
        res = TilawatResult.objects.get()
        self.assertEqual(res.mistakes, 2)

    def test_unassigned_blocked(self):
        other = make_user("o@x.com", User.ROLE_STUDENT)
        self.client.force_login(other)
        r = self.client.get(reverse("tilawat:practice", args=[self.sess.pk]))
        self.assertEqual(r.status_code, 302)

    def test_student_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("tilawat:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Tilawat Practice")
