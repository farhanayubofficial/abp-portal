from django.apps import AppConfig


class TilawatConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.tilawat"
    verbose_name = "Tilawat Practice"
