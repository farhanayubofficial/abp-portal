from django.contrib import admin

from .models import TilawatResult, TilawatSession


@admin.register(TilawatSession)
class TilawatSessionAdmin(admin.ModelAdmin):
    list_display = ("__str__", "total_marks", "created_by", "is_active")
    list_filter = ("is_active",)


@admin.register(TilawatResult)
class TilawatResultAdmin(admin.ModelAdmin):
    list_display = ("student", "session", "ayat_number", "mistakes", "score")
