"""Tilawat Practice: qari first, then student recites ayat-by-ayat.

- Teacher sets surah + ayat range + total marks + students.
- Student: listens to the Qari, then reads each ayat with the mic.
- Mistake -> buzzer + red; corrected -> green; only then next ayat.
- Marks auto: per-ayat share of total marks minus mistakes.
- English + Urdu translation under each ayat, with TTS voice buttons.
"""

from django.conf import settings
from django.db import models


class TilawatSession(models.Model):
    surah_number = models.PositiveIntegerField()
    ayat_from = models.PositiveIntegerField()
    ayat_to = models.PositiveIntegerField()
    total_marks = models.PositiveIntegerField(default=20)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="tilawat_sessions")
    students = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name="tilawat_assigned",
        blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Tilawat {self.surah_number}:{self.ayat_from}-{self.ayat_to}"

    def ayat_numbers(self):
        return list(range(self.ayat_from, self.ayat_to + 1))

    def marks_per_ayat(self):
        n = max(1, len(self.ayat_numbers()))
        return self.total_marks / n


class TilawatResult(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="tilawat_results")
    session = models.ForeignKey(
        TilawatSession, on_delete=models.CASCADE, related_name="results")
    ayat_number = models.PositiveIntegerField()
    mistakes = models.PositiveIntegerField(default=0)
    score = models.FloatField(default=0)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["ayat_number"]
        unique_together = ("student", "session", "ayat_number")

    def __str__(self):
        return f"{self.student} {self.session} :{self.ayat_number}"
