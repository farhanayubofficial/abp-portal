"""English + Urdu translations of every ayah (bundled JSON)."""

import json
from functools import lru_cache
from pathlib import Path

DATA_DIR = Path(__file__).parent / "data"


@lru_cache(maxsize=2)
def _load(lang):
    path = DATA_DIR / ("trans_en.json" if lang == "en" else "trans_ur.json")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def get_translation(surah_no, ayah_no, lang="en"):
    return _load(lang).get(str(surah_no), {}).get(str(ayah_no), "")
