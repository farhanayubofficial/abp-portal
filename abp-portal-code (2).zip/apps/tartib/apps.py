from django.apps import AppConfig


class TartibConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.tartib"
    verbose_name = "Ayat Tartib"
