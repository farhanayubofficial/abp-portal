"""Ayat Tartib views: surah picker, ayah picker, listen-once + ordering game."""

import json

from django.contrib.auth.decorators import login_required
from django.db.models import Max
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.maze import quran

from .models import (BONUS_PERFECT_ROUND, POINTS_PER_WORD, WORDS_PER_ROUND,
                     TartibRun)


@login_required
def home(request):
    surahs = [
        {"number": n, "name": name, "count": c,
         "best": _best_for_surah(request.user, n)}
        for n, name, c in quran.surah_list()
    ]
    recent = TartibRun.objects.filter(
        student=request.user, completed=True)[:8]
    return render(request, "tartib/home.html",
                  {"surahs": surahs, "recent": recent})


def _best_for_surah(user, surah_no):
    return TartibRun.objects.filter(
        student=user, surah_number=surah_no, completed=True
    ).aggregate(b=Max("score"))["b"] or 0


@login_required
def ayahs(request, surah_no):
    s = quran.surah(surah_no)
    if not s:
        return redirect("tartib:home")
    # NO ayah text exposed — only number + word count
    rows = [{"n": v["n"], "words": len(v["text"].split())}
            for v in s["verses"]]
    return render(request, "tartib/ayahs.html",
                  {"surah": s, "rows": rows})


@login_required
def play(request, surah_no, ayah_no):
    words = quran.ayah_words(surah_no, ayah_no)
    if not words:
        return redirect("tartib:home")
    run, _ = TartibRun.objects.get_or_create(
        student=request.user, surah_number=surah_no, ayah_number=ayah_no,
        completed=False,
        defaults={"score": 0})
    if request.method == "POST":
        action = request.POST.get("action")
        payload = {}
        if not action:
            try:
                payload = json.loads(request.body.decode("utf-8") or "{}")
            except Exception:
                payload = {}
            action = payload.get("action")
        if action == "listened" and not run.listened_at:
            run.listened_at = timezone.now()
            run.save()
            return JsonResponse({"ok": True})
        if action == "submit":
            data = payload or {}
            run.score = max(0, min(int(data.get("score", 0) or 0), 99999))
            run.rounds_done = int(data.get("rounds_done", 0) or 0)
            run.completed = bool(data.get("completed", False))
            run.save()
            return JsonResponse({"ok": True})
        return JsonResponse({"ok": False}, status=400)

    listened = bool(run.listened_at)
    rounds = [words[i:i + WORDS_PER_ROUND]
              for i in range(0, len(words), WORDS_PER_ROUND)]
    s = quran.surah(surah_no)
    return render(request, "tartib/play.html", {
        "run": run, "listened": listened,
        "surah_name": s["name"] if s else "",
        "surah_no": surah_no, "ayah_no": ayah_no,
        "audio_url": quran.qari_audio_url(surah_no, ayah_no) if not listened else None,
        "rounds_json": json.dumps(rounds, ensure_ascii=False) if listened else "null",
        "points_per_word": POINTS_PER_WORD,
        "bonus": BONUS_PERFECT_ROUND,
    })
