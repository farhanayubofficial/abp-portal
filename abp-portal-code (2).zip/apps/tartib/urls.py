from django.urls import path

from . import views

app_name = "tartib"

urlpatterns = [
    path("", views.home, name="home"),
    path("surah/<int:surah_no>/", views.ayahs, name="ayahs"),
    path("play/<int:surah_no>/<int:ayah_no>/", views.play, name="play"),
]
