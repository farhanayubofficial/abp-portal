from django.contrib import admin

from .models import TartibRun


@admin.register(TartibRun)
class TartibRunAdmin(admin.ModelAdmin):
    list_display = ("student", "surah_number", "ayah_number", "score",
                    "completed", "created_at")
    list_filter = ("completed",)
