"""Ayat Tartib: listen to an ayah ONCE, then rebuild it by clicking
scrambled words in order (#1, #2, #3...).

The student NEVER sees the ayah text — not in the picker, not during
the game. Only surah name + ayah number + word count are shown.
Long ayahs are split into rounds.
"""

from django.conf import settings
from django.db import models

WORDS_PER_ROUND = 8
POINTS_PER_WORD = 5
BONUS_PERFECT_ROUND = 10


class TartibRun(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="tartib_runs")
    surah_number = models.PositiveIntegerField()
    ayah_number = models.PositiveIntegerField()
    listened_at = models.DateTimeField(null=True, blank=True)
    completed = models.BooleanField(default=False)
    score = models.PositiveIntegerField(default=0)
    rounds_done = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} {self.surah_number}:{self.ayah_number} {self.score}"
