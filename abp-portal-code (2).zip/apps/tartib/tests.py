"""Ayat Tartib tests (Phase 16)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import TartibRun


def make_user(email):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U",
        role=User.ROLE_STUDENT)


class TartibTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com")

    def test_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("tartib:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Ayat Tartib")

    def test_ayah_picker_hides_text(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("tartib:ayahs", args=[112]))
        self.assertEqual(r.status_code, 200)
        from apps.maze.quran import get_ayah
        self.assertNotContains(r, get_ayah(112, 1))
        self.assertContains(r, "alfaz")

    def test_play_listen_once_flow(self):
        self.client.force_login(self.student)
        url = reverse("tartib:play", args=[112, 1])
        r = self.client.get(url)
        self.assertEqual(r.status_code, 200)
        # audio before listen
        self.assertContains(r, "112001.mp3")
        # no ayah text
        from apps.maze.quran import get_ayah
        self.assertNotContains(r, get_ayah(112, 1))
        # mark listened
        r = self.client.post(url, {"action": "listened"})
        self.assertTrue(r.json()["ok"])
        r = self.client.get(url)
        # after: no audio, rounds config present
        self.assertNotContains(r, "112001.mp3")
        self.assertContains(r, "Bikhre Alfaz")

    def test_submit(self):
        self.client.force_login(self.student)
        url = reverse("tartib:play", args=[112, 1])
        self.client.post(url, {"action": "listened"})
        r = self.client.post(
            url, json.dumps({"action": "submit", "score": 30,
                             "rounds_done": 1, "completed": True}),
            content_type="application/json")
        self.assertTrue(r.json()["ok"])
        run = TartibRun.objects.get()
        self.assertEqual(run.score, 30)
        self.assertTrue(run.completed)

    def test_long_ayah_rounds(self):
        # Ayat al-Kursi is long -> multiple rounds
        from apps.maze.quran import ayah_words
        from .models import WORDS_PER_ROUND
        words = ayah_words(2, 255)
        self.assertTrue(len(words) > WORDS_PER_ROUND)
