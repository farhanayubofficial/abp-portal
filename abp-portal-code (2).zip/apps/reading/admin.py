from django.contrib import admin

from .models import ReadingAttempt, ReadingPassage


@admin.register(ReadingPassage)
class ReadingPassageAdmin(admin.ModelAdmin):
    list_display = ("title", "track", "total_marks", "is_published", "created_at")
    list_filter = ("is_published", "track")
    search_fields = ("title", "arabic_text")


@admin.register(ReadingAttempt)
class ReadingAttemptAdmin(admin.ModelAdmin):
    list_display = ("student", "passage", "score", "words_correct",
                    "words_wrong", "created_at")
    list_filter = ("passage",)
    search_fields = ("student__email",)
