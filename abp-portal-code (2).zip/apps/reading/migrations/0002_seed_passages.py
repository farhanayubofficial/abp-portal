"""Seed 3 starter reading passages (simple Arabic, no diacritics)."""

from django.db import migrations


PASSAGES = [
    {
        "title": "طالب العلم",
        "arabic_text": "أنا طالب في مدرسة عربية. أتعلم اللغة العربية كل يوم. أحب القراءة والكتابة.",
        "english_translation": "I am a student in an Arabic school. I learn the Arabic language every day. I love reading and writing.",
    },
    {
        "title": "في الصباح",
        "arabic_text": "في الصباح أستيقظ مبكرا. أصلي الفجر ثم أتناول الفطور. بعد ذلك أذهب إلى المدرسة.",
        "english_translation": "In the morning I wake up early. I pray Fajr, then I eat breakfast. After that I go to school.",
    },
    {
        "title": "قراءة القرآن",
        "arabic_text": "المسلم يقرأ القرآن كل يوم. القرآن نور وهداية للناس. من قرأ القرآن نال الأجر.",
        "english_translation": "The Muslim reads the Quran every day. The Quran is light and guidance for people. Whoever reads the Quran earns reward.",
    },
]


def seed(apps, schema_editor):
    ReadingPassage = apps.get_model("reading", "ReadingPassage")
    for p in PASSAGES:
        ReadingPassage.objects.get_or_create(
            title=p["title"],
            defaults={
                "arabic_text": p["arabic_text"],
                "english_translation": p["english_translation"],
                "total_marks": 20,
                "marks_per_mistake": 1,
                "is_published": True,
            },
        )


class Migration(migrations.Migration):
    dependencies = [("reading", "0001_initial")]
    operations = [migrations.RunPython(seed, migrations.RunPython.noop)]
