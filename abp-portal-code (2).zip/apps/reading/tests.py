"""Reading Lab tests (Phase 10)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import ReadingAttempt, ReadingPassage


def make_user(email, role):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class ReadingModelTests(TestCase):
    def test_compute_score(self):
        p = ReadingPassage(total_marks=20, marks_per_mistake=1)
        self.assertEqual(p.compute_score(0), 20)
        self.assertEqual(p.compute_score(3), 17)
        self.assertEqual(p.compute_score(99), 0)  # floor at 0

    def test_word_count(self):
        p = ReadingPassage(arabic_text="أنا طالب علم")
        self.assertEqual(p.word_count(), 3)


class ReadingViewTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com", User.ROLE_STUDENT)
        self.teacher = make_user("t@x.com", User.ROLE_TEACHER)
        self.pub = ReadingPassage.objects.create(
            title="Pub", arabic_text="أنا طالب", english_translation="I am a student",
            is_published=True)
        self.draft = ReadingPassage.objects.create(
            title="Draft", arabic_text="أنا معلم", english_translation="I am a teacher",
            is_published=False)

    def test_student_sees_only_published(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("reading:list"))
        self.assertContains(r, "Pub")
        self.assertNotContains(r, "Draft")

    def test_teacher_sees_all(self):
        self.client.force_login(self.teacher)
        r = self.client.get(reverse("reading:list"))
        self.assertContains(r, "Pub")
        self.assertContains(r, "Draft")

    def test_student_cannot_practice_draft(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("reading:practice", args=[self.draft.pk]))
        self.assertEqual(r.status_code, 403)

    def test_practice_page_loads(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("reading:practice", args=[self.pub.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "rword")

    def test_submit_attempt_scores_server_side(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("reading:submit", args=[self.pub.pk]),
            json.dumps({"words_correct": 8, "words_wrong": 3,
                        "mistake_words": ["طالب"]}),
            content_type="application/json")
        self.assertEqual(r.status_code, 200)
        data = r.json()
        self.assertTrue(data["ok"])
        self.assertEqual(data["score"], 17)  # 20 - 3*1
        a = ReadingAttempt.objects.get()
        self.assertEqual(a.student, self.student)
        self.assertEqual(a.score, 17)
        self.assertEqual(a.mistake_words, ["طالب"])

    def test_teacher_report_access(self):
        # student denied
        self.client.force_login(self.student)
        r = self.client.get(reverse("reading:report"))
        self.assertEqual(r.status_code, 302)  # user_passes_test redirect
        # teacher ok
        self.client.force_login(self.teacher)
        r = self.client.get(reverse("reading:report"))
        self.assertEqual(r.status_code, 200)
