"""Reading Lab views: practice (student) + report (teacher)."""

import json

from django.contrib.auth.decorators import login_required, user_passes_test
from django.core.exceptions import PermissionDenied
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.decorators.http import require_POST

from .models import ReadingAttempt, ReadingPassage


def _is_staff_teacher(u):
    return u.is_authenticated and (u.is_teacher or u.is_admin)


@login_required
def passage_list(request):
    if _is_staff_teacher(request.user):
        passages = ReadingPassage.objects.all()
    else:
        passages = ReadingPassage.objects.filter(is_published=True)
    # student's best score per passage
    best = {}
    if not _is_staff_teacher(request.user):
        for a in ReadingAttempt.objects.filter(student=request.user):
            if a.passage_id not in best or a.score > best[a.passage_id]:
                best[a.passage_id] = a.score
    return render(request, "reading/passage_list.html",
                  {"passages": passages, "best": best,
                   "is_teacher": _is_staff_teacher(request.user)})


@login_required
def practice(request, pk):
    passage = get_object_or_404(ReadingPassage, pk=pk)
    if not passage.is_published and not _is_staff_teacher(request.user):
        raise PermissionDenied
    words = passage.arabic_text.split()
    return render(request, "reading/practice.html",
                  {"passage": passage, "words": words})


@login_required
@require_POST
def submit_attempt(request, pk):
    """Save a reading attempt. Score is computed server-side (trusted)."""
    passage = get_object_or_404(ReadingPassage, pk=pk)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False, "error": "bad json"}, status=400)
    words_wrong = int(data.get("words_wrong", 0) or 0)
    words_correct = int(data.get("words_correct", 0) or 0)
    mistake_words = data.get("mistake_words", []) or []
    if not isinstance(mistake_words, list):
        mistake_words = []
    score = passage.compute_score(words_wrong)
    attempt = ReadingAttempt.objects.create(
        passage=passage, student=request.user,
        words_total=passage.word_count(),
        words_correct=words_correct, words_wrong=words_wrong,
        score=score, mistake_words=mistake_words[:50],
    )
    return JsonResponse({"ok": True, "score": score,
                         "total": passage.total_marks,
                         "attempt_id": attempt.id})


@login_required
@user_passes_test(_is_staff_teacher)
def teacher_report(request):
    attempts = (ReadingAttempt.objects
                .select_related("passage", "student")
                .order_by("-created_at")[:200])
    return render(request, "reading/report.html", {"attempts": attempts})
