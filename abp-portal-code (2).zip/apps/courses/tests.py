"""Phase 2 tests: books, text extraction, levels, lessons, curriculum views."""
from unittest.mock import patch

from django.contrib.auth import get_user_model
from django.core.files.uploadedfile import SimpleUploadedFile
from django.test import TestCase
from django.urls import reverse

from apps.courses.models import (
    Book, BookPage, CourseLevel, CourseTrack, Exercise, ExerciseAttempt,
    Lesson, LessonProgress,
)
from apps.courses.services import ingest_book_text

User = get_user_model()

# Minimal valid one-page PDF (text layer: a sentence long enough to count as text)
def _minimal_pdf(text: str) -> bytes:
    stream = f"BT /F1 12 Tf 10 50 Td ({text}) Tj ET\n".encode("latin-1")
    return (
        b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n"
        b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n"
        b"3 0 obj<</Type/Page/Parent 2 0 R/MediaBox[0 0 700 200]/Contents 4 0 R/Resources<</Font<</F1 5 0 R>>>>>>endobj\n"
        b"4 0 obj<</Length " + str(len(stream)).encode() + b">>stream\n" + stream +
        b"endstream\nendobj\n"
        b"5 0 obj<</Type/Font/Subtype/Type1/BaseFont/Helvetica>>endobj\n"
        b"trailer<</Size 6/Root 1 0 R>>\n"
        b"startxref\n0\n%%EOF"
    )


MINIMAL_PDF = _minimal_pdf(
    "Hello lesson one - this is a sample text long enough for extraction testing purposes"
)


def make_user(role, email):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class BookModelTests(TestCase):
    def test_book_creation_with_upload(self):
        track = CourseTrack.objects.get(code="quranic-arabic")
        book = Book.objects.create(
            title="Test Book", author="Author", track=track,
            file=SimpleUploadedFile("test.pdf", MINIMAL_PDF, content_type="application/pdf"),
        )
        self.assertEqual(book.track.code, "quranic-arabic")
        self.assertEqual(book.ocr_status, Book.OCR_PENDING)


class TextExtractionTests(TestCase):
    def test_text_layer_extracted_without_ocr(self):
        book = Book.objects.create(
            title="Text PDF",
            file=SimpleUploadedFile("t.pdf", MINIMAL_PDF, content_type="application/pdf"),
        )
        ingest_book_text(book, ocr=False)
        book.refresh_from_db()
        self.assertEqual(book.pages, 1)
        page = book.pages_records.get(page_number=1)
        self.assertIn("Hello", page.text)
        self.assertEqual(page.source, BookPage.SOURCE_TEXT_LAYER)
        self.assertEqual(book.ocr_status, Book.OCR_NOT_NEEDED)

    def test_scanned_page_flagged_for_review_without_ocr(self):
        # Blank PDF page: no text layer, OCR disabled -> flagged needs_review
        blank = _minimal_pdf("")
        book = Book.objects.create(
            title="Scanned PDF",
            file=SimpleUploadedFile("s.pdf", blank, content_type="application/pdf"),
        )
        with patch("apps.courses.services.tesseract_available", return_value=False):
            ingest_book_text(book, ocr=True)
        page = book.pages_records.get(page_number=1)
        self.assertTrue(page.needs_review)


class CurriculumViewTests(TestCase):
    def setUp(self):
        self.track = CourseTrack.objects.get(code="quranic-arabic")
        self.level = CourseLevel.objects.create(track=self.track, name="Level 1", order=1)
        self.student = make_user(User.ROLE_STUDENT, "s@abp.test")
        self.teacher = make_user(User.ROLE_TEACHER, "t@abp.test")
        self.published = Lesson.objects.create(
            track=self.track, level=self.level, title="Published lesson",
            order=1, status=Lesson.STATUS_PUBLISHED)
        self.draft = Lesson.objects.create(
            track=self.track, level=self.level, title="Draft lesson",
            order=2, status=Lesson.STATUS_DRAFT)

    def test_login_required(self):
        resp = self.client.get(reverse("track_list"))
        self.assertEqual(resp.status_code, 302)

    def test_student_sees_only_published(self):
        self.client.force_login(self.student)
        resp = self.client.get(reverse("track_detail", kwargs={"code": self.track.code}))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "Published lesson")
        self.assertNotContains(resp, "Draft lesson")

    def test_teacher_sees_drafts_too(self):
        self.client.force_login(self.teacher)
        resp = self.client.get(reverse("track_detail", kwargs={"code": self.track.code}))
        self.assertContains(resp, "Draft lesson")

    def test_track_list_shows_four_tracks(self):
        self.client.force_login(self.student)
        resp = self.client.get(reverse("track_list"))
        self.assertEqual(len(resp.context["tracks"]), 4)


class LessonWorkflowTests(TestCase):
    def test_default_status_is_draft(self):
        track = CourseTrack.objects.get(code="arabic-language")
        lesson = Lesson.objects.create(track=track, title="New lesson", order=1)
        self.assertEqual(lesson.status, Lesson.STATUS_DRAFT)


class SequentialUnlockingTests(TestCase):
    def setUp(self):
        self.track = CourseTrack.objects.get(code="quranic-arabic")
        self.level = CourseLevel.objects.create(track=self.track, name="L1", order=1)
        self.student = make_user(User.ROLE_STUDENT, "su@abp.test")
        self.lessons = [
            Lesson.objects.create(track=self.track, level=self.level,
                                  title=f"L{i}", order=i,
                                  status=Lesson.STATUS_PUBLISHED)
            for i in (1, 2, 3)
        ]

    def test_first_lesson_unlocked_rest_locked(self):
        self.assertTrue(self.lessons[0].is_unlocked_for(self.student))
        self.assertFalse(self.lessons[1].is_unlocked_for(self.student))
        self.assertFalse(self.lessons[2].is_unlocked_for(self.student))

    def test_opening_is_not_completion(self):
        self.client.force_login(self.student)
        self.client.get(reverse("lesson_detail", kwargs={"pk": self.lessons[0].pk}))
        prog = LessonProgress.objects.get(student=self.student, lesson=self.lessons[0])
        self.assertEqual(prog.status, LessonProgress.STATUS_IN_PROGRESS)
        # Second lesson still locked — opening did not complete the first
        self.assertFalse(self.lessons[1].is_unlocked_for(self.student))

    def test_explicit_completion_unlocks_next(self):
        self.client.force_login(self.student)
        resp = self.client.post(reverse("lesson_complete", kwargs={"pk": self.lessons[0].pk}))
        self.assertEqual(resp.status_code, 302)
        prog = LessonProgress.objects.get(student=self.student, lesson=self.lessons[0])
        self.assertEqual(prog.status, LessonProgress.STATUS_COMPLETED)
        self.assertTrue(self.lessons[1].is_unlocked_for(self.student))
        self.assertFalse(self.lessons[2].is_unlocked_for(self.student))

    def test_locked_lesson_redirects(self):
        self.client.force_login(self.student)
        resp = self.client.get(reverse("lesson_detail", kwargs={"pk": self.lessons[2].pk}))
        self.assertEqual(resp.status_code, 302)


class ExerciseTests(TestCase):
    def setUp(self):
        self.track = CourseTrack.objects.get(code="arabic-language")
        self.student = make_user(User.ROLE_STUDENT, "se@abp.test")
        self.lesson = Lesson.objects.create(
            track=self.track, title="Ex Lesson", order=1, status=Lesson.STATUS_PUBLISHED)
        self.ex = Exercise.objects.create(
            lesson=self.lesson, question_type=Exercise.TYPE_MCQ,
            question="2+2?", options=["3", "4", "5"], correct_answer="4", order=1)

    def test_correct_answer_recorded(self):
        self.client.force_login(self.student)
        self.client.post(reverse("exercise_submit", kwargs={"pk": self.ex.pk}),
                         {"answer": "4"})
        att = ExerciseAttempt.objects.get(student=self.student, exercise=self.ex)
        self.assertTrue(att.is_correct)

    def test_wrong_answer_recorded(self):
        self.client.force_login(self.student)
        self.client.post(reverse("exercise_submit", kwargs={"pk": self.ex.pk}),
                         {"answer": "3"})
        att = ExerciseAttempt.objects.get(student=self.student, exercise=self.ex)
        self.assertFalse(att.is_correct)

    def test_progress_page_shows_counts(self):
        self.client.force_login(self.student)
        LessonProgress.objects.create(
            student=self.student, lesson=self.lesson,
            status=LessonProgress.STATUS_COMPLETED)
        resp = self.client.get(reverse("my_progress"))
        self.assertEqual(resp.status_code, 200)
        self.assertContains(resp, "1")

class QuizFlowTests(TestCase):
    def setUp(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        self.student = User.objects.create_user(email="quizstu@abp.test", password="x", role="student")
        self.teacher = User.objects.create_user(email="quiztea@abp.test", password="x", role="teacher")
        from apps.courses.models import CourseTrack, Lesson, Exercise
        self.track = CourseTrack.objects.create(code="qt", name="Quiz Track")
        self.lesson = Lesson.objects.create(track=self.track, title="Quiz Lesson", order=1, status="published")
        self.ex1 = Exercise.objects.create(lesson=self.lesson, question_type="mcq",
            question="What does السلام mean?", options=["Peace", "War"], correct_answer="Peace", order=1,
            marks=2, sentence_ar="السَّلَامُ عَلَيْكُمْ", sentence_ur="آپ پر سلامتی ہو", sentence_en="Peace be upon you")
        self.ex2 = Exercise.objects.create(lesson=self.lesson, question_type="fill_blank",
            question="Fill: ___ عليكم", correct_answer="السلام", order=2, marks=3)

    def test_quiz_requires_login(self):
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.assertEqual(r.status_code, 302)

    def test_quiz_one_question_at_a_time(self):
        self.client.force_login(self.student)
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.assertEqual(r.status_code, 200)
        # only first question visible, not the second
        self.assertContains(r, "What does")
        self.assertNotContains(r, "Fill:")

    def test_quiz_answer_feedback_then_next(self):
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        r = self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "Peace"})
        self.assertContains(r, "Correct")
        # next question after feedback
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.assertContains(r, "Fill:")

    def test_quiz_final_score_and_restart(self):
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "Peace"})
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "wrong"})
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.assertContains(r, "Quiz Complete")
        self.assertContains(r, "-1 / 5")
        self.assertContains(r, "Try Again")

    def test_quiz_records_attempts(self):
        from apps.courses.models import ExerciseAttempt
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "Peace"})
        self.assertTrue(ExerciseAttempt.objects.filter(student=self.student, exercise=self.ex1).exists())

    def test_quiz_teacher_preview_allowed(self):
        self.client.force_login(self.teacher)
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.assertEqual(r.status_code, 200)

    def test_trilingual_card_rendered(self):
        self.client.force_login(self.student)
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.assertContains(r, "السَّلَامُ عَلَيْكُمْ")
        self.assertContains(r, "آپ پر سلامتی ہو")
        self.assertContains(r, "Peace be upon you")
        self.assertContains(r, "🔊 Arabic")
        self.assertContains(r, "🔊 Urdu")
        self.assertContains(r, "🔊 English")

    def test_lesson_page_shows_start_quiz_button(self):
        self.client.force_login(self.student)
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/")
        self.assertContains(r, "Start Quiz")

class QuizMarksTests(TestCase):
    def setUp(self):
        from django.contrib.auth import get_user_model
        User = get_user_model()
        self.student = User.objects.create_user(email="markstu@abp.test", password="x", role="student")
        from apps.courses.models import CourseTrack, Lesson, Exercise
        self.track = CourseTrack.objects.create(code="mk", name="Marks Track")
        self.lesson = Lesson.objects.create(track=self.track, title="Marks Lesson", order=1, status="published")
        self.ex1 = Exercise.objects.create(lesson=self.lesson, question_type="mcq",
            question="Q1?", options=["a", "b"], correct_answer="a", order=1, marks=2)
        self.ex2 = Exercise.objects.create(lesson=self.lesson, question_type="mcq",
            question="Q2?", options=["a", "b"], correct_answer="a", order=2, marks=3)

    def test_marks_shown_before_answering(self):
        self.client.force_login(self.student)
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.assertContains(r, "Marks: 2")

    def test_correct_answer_adds_marks(self):
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        r = self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "a"})
        self.assertContains(r, "+2 marks")
        self.assertContains(r, "Running score:")
        # score is 2
        self.assertContains(r, "<strong>2</strong>")

    def test_wrong_answer_deducts_marks(self):
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        r = self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "b"})
        self.assertContains(r, "-2 marks")

    def test_final_result_shows_score_and_percent(self):
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "a"})  # +2
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "a"})  # +3
        r = self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.assertContains(r, "5 / 5")
        self.assertContains(r, "100%")
        self.assertContains(r, "Excellent")

    def test_qa_no_marks_change(self):
        from apps.courses.models import Exercise
        qa = Exercise.objects.create(lesson=self.lesson, question_type="qa",
            question="Say something", model_answer="model", order=3, marks=5, auto_grade=False)
        self.client.force_login(self.student)
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/?start=1")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "a"})
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "a"})
        self.client.get(f"/courses/lesson/{self.lesson.pk}/quiz/")
        r = self.client.post(f"/courses/lesson/{self.lesson.pk}/quiz/", {"answer": "my answer"})
        # QA: no marks delta shown, score unchanged at 5
        self.assertContains(r, "Running score:")
        self.assertContains(r, "<strong>5</strong>")
