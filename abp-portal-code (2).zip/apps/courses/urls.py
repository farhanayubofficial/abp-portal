from django.urls import path

from . import views

urlpatterns = [
    path("", views.TrackListView.as_view(), name="track_list"),
    path("progress/", views.MyProgressView.as_view(), name="my_progress"),
    path("lesson/<int:pk>/", views.LessonDetailView.as_view(), name="lesson_detail"),
    path("lesson/<int:pk>/complete/", views.LessonCompleteView.as_view(), name="lesson_complete"),
    path("lesson/<int:pk>/quiz/", views.QuizView.as_view(), name="quiz"),
    path("exercise/<int:pk>/submit/", views.ExerciseSubmitView.as_view(), name="exercise_submit"),
    path("<slug:code>/", views.TrackDetailView.as_view(), name="track_detail"),
]
