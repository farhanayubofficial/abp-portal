"""Book text extraction: PDF text layer first, Tesseract OCR for scanned pages.

Religious-citation safety (spec section 10): extracted text is stored as-is.
Anything uncertain (low OCR yield) is flagged needs_review for a human —
citations are never invented or silently 'fixed'.
"""
import logging
import shutil
import subprocess
import tempfile
from pathlib import Path

from django.db import transaction

from .models import Book, BookPage

log = logging.getLogger(__name__)

# A page with fewer than this many characters is considered "no usable text".
MIN_TEXT_CHARS = 50
OCR_LANGS = "ara+urd"


def _run(cmd, **kwargs):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=300, **kwargs)


def pdf_page_count(pdf_path: str) -> int:
    out = _run(["pdfinfo", str(pdf_path)]).stdout
    for line in out.splitlines():
        if line.startswith("Pages:"):
            return int(line.split(":")[1].strip())
    return 0


def extract_text_layer(pdf_path: str) -> list:
    """Return per-page text from the PDF's embedded text layer ('' if none)."""
    pages = pdf_page_count(pdf_path)
    texts = []
    for n in range(1, pages + 1):
        out = _run(["pdftotext", "-f", str(n), "-l", str(n), "-layout", str(pdf_path), "-"]).stdout
        texts.append(out.strip())
    return texts


def ocr_pdf_page(pdf_path: str, page_number: int, langs: str = OCR_LANGS) -> str:
    """OCR a single PDF page with Tesseract. Raises RuntimeError if unavailable."""
    tesseract = shutil.which("tesseract")
    if not tesseract:
        raise RuntimeError("Tesseract is not installed; cannot OCR scanned pages.")
    with tempfile.TemporaryDirectory() as tmp:
        img_base = str(Path(tmp) / "page")
        _run(["pdftoppm", "-png", "-f", str(page_number), "-l", str(page_number),
              "-r", "200", str(pdf_path), img_base])
        img = img_base + f"-{page_number:02d}.png"
        # pdftoppm names single pages like page-01.png; fall back to glob
        candidates = list(Path(tmp).glob("*.png"))
        if not candidates:
            raise RuntimeError(f"Could not render page {page_number} to image.")
        out = _run([tesseract, str(candidates[0]), "stdout", "-l", langs]).stdout
    return out.strip()


def tesseract_available() -> bool:
    return shutil.which("tesseract") is not None


@transaction.atomic
def ingest_book_text(book: Book, ocr: bool = True, max_ocr_pages: int | None = None):
    """Extract per-page text for a book.

    1. Read the embedded text layer (fast, accurate).
    2. For pages without usable text, run Tesseract OCR (slower) unless
       ocr=False. max_ocr_pages caps cost on huge scanned books.
    3. Low-yield OCR pages are flagged needs_review for a human.
    """
    pdf_path = book.file.path
    texts = extract_text_layer(pdf_path)
    book.pages = len(texts)
    book.has_text_layer = any(len(t) >= MIN_TEXT_CHARS for t in texts)

    ocr_done = 0
    for i, text in enumerate(texts, start=1):
        source = BookPage.SOURCE_TEXT_LAYER
        needs_review = False
        if len(text) < MIN_TEXT_CHARS and ocr and tesseract_available():
            if max_ocr_pages is not None and ocr_done >= max_ocr_pages:
                text, source, needs_review = "", BookPage.SOURCE_OCR, True
            else:
                try:
                    text = ocr_pdf_page(pdf_path, i)
                    ocr_done += 1
                except Exception as exc:  # noqa: BLE001 — keep ingesting other pages
                    log.warning("OCR failed for %s p.%d: %s", book.title, i, exc)
                    text = ""
                source = BookPage.SOURCE_OCR
                if len(text) < MIN_TEXT_CHARS:
                    needs_review = True
        elif len(text) < MIN_TEXT_CHARS:
            needs_review = True
        BookPage.objects.update_or_create(
            book=book, page_number=i,
            defaults={"text": text, "source": source, "needs_review": needs_review},
        )

    if book.has_text_layer:
        book.ocr_status = Book.OCR_NOT_NEEDED
    elif ocr_done:
        book.ocr_status = Book.OCR_DONE
    else:
        book.ocr_status = Book.OCR_PENDING
    book.save()
    return book
