from django.contrib import admin
from django.utils import timezone

from .models import Book, BookPage, CourseLevel, CourseTrack, Exercise, Lesson, LessonProgress


@admin.register(CourseTrack)
class CourseTrackAdmin(admin.ModelAdmin):
    list_display = ["name", "code"]
    prepopulated_fields = {"code": ["name"]}


class LessonInline(admin.TabularInline):
    model = Lesson
    extra = 0
    fields = ["order", "title", "book", "page_start", "page_end", "status"]
    ordering = ["order"]


@admin.register(CourseLevel)
class CourseLevelAdmin(admin.ModelAdmin):
    list_display = ["track", "order", "name"]
    list_filter = ["track"]
    inlines = [LessonInline]


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ["title", "author", "track", "language", "pages", "ocr_status", "uploaded_at"]
    list_filter = ["track", "language", "ocr_status"]
    search_fields = ["title", "author"]
    readonly_fields = ["pages", "has_text_layer", "ocr_status", "uploaded_at"]


@admin.register(BookPage)
class BookPageAdmin(admin.ModelAdmin):
    list_display = ["book", "page_number", "source", "needs_review"]
    list_filter = ["source", "needs_review"]
    search_fields = ["book__title"]

    def has_add_permission(self, request):
        return False


@admin.register(Lesson)
class LessonAdmin(admin.ModelAdmin):
    list_display = ["title", "track", "level", "book", "status", "order"]
    list_filter = ["track", "status", "level"]
    search_fields = ["title", "source_reference"]
    actions = ["mark_in_review", "publish_lessons"]

    @admin.action(description="Send selected lessons for review")
    def mark_in_review(self, request, queryset):
        queryset.update(status=Lesson.STATUS_IN_REVIEW)

    @admin.action(description="Publish selected lessons (human approval)")
    def publish_lessons(self, request, queryset):
        queryset.update(status=Lesson.STATUS_PUBLISHED, reviewed_by=request.user,
                        published_at=timezone.now())


class ExerciseInline(admin.TabularInline):
    model = Exercise
    extra = 0
    fields = ["order", "question_type", "question", "correct_answer"]


@admin.register(Exercise)
class ExerciseAdmin(admin.ModelAdmin):
    list_display = ["lesson", "order", "question_type", "question"]
    list_filter = ["question_type"]


@admin.register(LessonProgress)
class LessonProgressAdmin(admin.ModelAdmin):
    list_display = ["student", "lesson", "status", "updated_at"]
    list_filter = ["status", "lesson__track"]
    readonly_fields = ["updated_at"]


# Attach exercises inline to lessons
LessonAdmin.inlines = [ExerciseInline]
