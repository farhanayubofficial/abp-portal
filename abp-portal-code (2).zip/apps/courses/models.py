"""Course tracks domain.

Phase 2: track structure, levels, books (upload + OCR), lesson skeletons.
Phase 3 will add full lesson content, exercises and student progress.
"""
from django.conf import settings
from django.db import models


class CourseTrack(models.Model):
    """One of the four course tracks (Quranic Arabic, Arabic Language, ...)."""

    code = models.SlugField(max_length=30, unique=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class CourseLevel(models.Model):
    """A level within a track (e.g. 'Level 1'). Final names need owner approval."""

    track = models.ForeignKey(CourseTrack, on_delete=models.CASCADE, related_name="levels")
    name = models.CharField(max_length=100)
    order = models.PositiveIntegerField(default=0)
    description = models.TextField(blank=True)

    class Meta:
        ordering = ["track", "order"]
        unique_together = [("track", "order")]

    def __str__(self):
        return f"{self.track.name} — {self.name}"


class Book(models.Model):
    """A curriculum book. Uploaded PDF stored securely; text extracted per page."""

    OCR_PENDING = "pending"
    OCR_DONE = "done"
    OCR_FAILED = "failed"
    OCR_NOT_NEEDED = "not_needed"
    OCR_CHOICES = [
        (OCR_PENDING, "Pending"),
        (OCR_DONE, "Done"),
        (OCR_FAILED, "Failed"),
        (OCR_NOT_NEEDED, "Not needed (has text layer)"),
    ]

    track = models.ForeignKey(
        CourseTrack, null=True, blank=True, on_delete=models.SET_NULL, related_name="books"
    )
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255, blank=True)
    publisher = models.CharField(max_length=255, blank=True)
    language = models.CharField(max_length=10, default="ar", help_text="ISO code: ar, ur, en")
    file = models.FileField(upload_to="books/%Y/")
    pages = models.PositiveIntegerField(default=0)
    has_text_layer = models.BooleanField(default=False)
    ocr_status = models.CharField(max_length=20, choices=OCR_CHOICES, default=OCR_PENDING)
    uploaded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="uploaded_books",
    )
    uploaded_at = models.DateTimeField(auto_now_add=True)
    notes = models.TextField(blank=True)

    class Meta:
        ordering = ["track__name", "title"]

    def __str__(self):
        return self.title

    @property
    def extracted_pages(self):
        return self.pages_records.filter(text__gt="")


class BookPage(models.Model):
    """Extracted text of one book page — from the PDF text layer or from OCR.

    Page references are preserved so lessons can cite exact pages.
    Religious citations found here are NEVER invented: uncertain references
    are flagged for human review (spec section 10).
    """

    SOURCE_TEXT_LAYER = "text_layer"
    SOURCE_OCR = "ocr"
    SOURCE_CHOICES = [(SOURCE_TEXT_LAYER, "PDF text layer"), (SOURCE_OCR, "OCR")]

    book = models.ForeignKey(Book, on_delete=models.CASCADE, related_name="pages_records")
    page_number = models.PositiveIntegerField()
    text = models.TextField(blank=True)
    source = models.CharField(max_length=20, choices=SOURCE_CHOICES)
    needs_review = models.BooleanField(
        default=False,
        help_text="Flagged when extraction quality is uncertain (e.g. low OCR confidence).",
    )

    class Meta:
        ordering = ["book", "page_number"]
        unique_together = [("book", "page_number")]

    def __str__(self):
        return f"{self.book.title} — p.{self.page_number} [{self.get_source_display()}]"


class Lesson(models.Model):
    """A lesson skeleton: title + source-book page reference.

    Status workflow (spec section 10): AI/staff create DRAFTS; a lesson becomes
    PUBLISHED only after human review/approval. Full lesson content, exercises
    and media arrive in Phase 3.
    """

    STATUS_DRAFT = "draft"
    STATUS_IN_REVIEW = "in_review"
    STATUS_PUBLISHED = "published"
    STATUS_CHOICES = [
        (STATUS_DRAFT, "Draft"),
        (STATUS_IN_REVIEW, "In review"),
        (STATUS_PUBLISHED, "Published"),
    ]

    track = models.ForeignKey(CourseTrack, on_delete=models.CASCADE, related_name="lessons")
    level = models.ForeignKey(
        CourseLevel, null=True, blank=True, on_delete=models.SET_NULL, related_name="lessons"
    )
    book = models.ForeignKey(
        Book, null=True, blank=True, on_delete=models.SET_NULL, related_name="lessons"
    )
    title = models.CharField(max_length=255)
    order = models.PositiveIntegerField(default=0)
    page_start = models.PositiveIntegerField(null=True, blank=True)
    page_end = models.PositiveIntegerField(null=True, blank=True)
    source_reference = models.CharField(
        max_length=255, blank=True,
        help_text="Human-readable citation, e.g. 'Muallam Al-Quran v1, pp. 10-15'.",
    )
    summary = models.TextField(blank=True)
    # Phase 3: lesson content (draft until human-approved & published)
    content = models.TextField(
        blank=True,
        help_text="Lesson body text. Draft-only until reviewed; never invent religious citations.",
    )
    audio_url = models.URLField(blank=True, help_text="Optional audio lesson URL.")
    video_url = models.URLField(blank=True, help_text="Optional video lesson URL.")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_DRAFT)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="created_lessons",
    )
    reviewed_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="reviewed_lessons",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    published_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["track", "level__order", "order"]

    def __str__(self):
        return f"[{self.get_status_display()}] {self.title}"

    def is_unlocked_for(self, student) -> bool:
        """Sequential unlocking: first lesson is open; others need the previous completed.

        Spec: opening a lesson is NOT completion — only explicit completion unlocks next.
        """
        if self.order <= 1:
            return True
        prev = (
            Lesson.objects.filter(track=self.track, level=self.level, order=self.order - 1)
            .only("id")
            .first()
        )
        if prev is None:
            return True
        return LessonProgress.objects.filter(
            student=student, lesson=prev, status=LessonProgress.STATUS_COMPLETED
        ).exists()


class Exercise(models.Model):
    """A practice question attached to a lesson. Draft until the lesson is approved."""

    TYPE_MCQ = "mcq"
    TYPE_FILL_BLANK = "fill_blank"
    TYPE_TRUE_FALSE = "true_false"
    TYPE_QA = "qa"
    TYPE_CHOICES = [
        (TYPE_MCQ, "Multiple choice"),
        (TYPE_FILL_BLANK, "Fill in the blank"),
        (TYPE_TRUE_FALSE, "True / False"),
        (TYPE_QA, "Sawal-Jawab (spoken answer)"),
    ]

    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name="exercises")
    question_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_MCQ)
    question = models.TextField()
    options = models.JSONField(default=list, blank=True,
                               help_text="MCQ options as a JSON list.")
    correct_answer = models.CharField(max_length=500, blank=True)
    model_answer = models.TextField(
        blank=True,
        help_text="Sample answer shown for Sawal-Jawab (self-check, not auto-graded).",
    )
    auto_grade = models.BooleanField(
        default=True,
        help_text="Off for Sawal-Jawab: attempt is recorded, student compares with model answer.",
    )
    explanation = models.TextField(blank=True)
    order = models.PositiveIntegerField(default=0)
    marks = models.PositiveIntegerField(
        default=1,
        help_text="Marks for this question: +marks if correct, -marks if wrong.",
    )
    # Trilingual sentence card (like the reference portal): Arabic sentence with
    # Urdu + English translations below, each with its own free TTS audio.
    sentence_ar = models.TextField(blank=True, help_text="Arabic sentence/word (kept in Arabic script).")
    sentence_ur = models.TextField(blank=True, help_text="Urdu translation shown below the Arabic.")
    sentence_en = models.TextField(blank=True, help_text="English translation shown below the Urdu.")
    audio_ar = models.CharField(max_length=500, blank=True, help_text="Audio file path for the Arabic reading.")
    audio_ur = models.CharField(max_length=500, blank=True, help_text="Audio file path for the Urdu reading.")
    audio_en = models.CharField(max_length=500, blank=True, help_text="Audio file path for the English reading.")

    class Meta:
        ordering = ["lesson", "order"]

    def __str__(self):
        return f"{self.lesson.title} — Q{self.order}"

    def check_answer(self, answer: str) -> bool | None:
        """Returns True/False for auto-graded types, None for Sawal-Jawab."""
        if not self.auto_grade:
            return None
        return answer.strip().lower() == self.correct_answer.strip().lower()


class ExerciseAttempt(models.Model):
    """One student's answer to one exercise (audited)."""

    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name="exercise_attempts")
    exercise = models.ForeignKey(Exercise, on_delete=models.CASCADE, related_name="attempts")
    answer = models.CharField(max_length=500)
    is_correct = models.BooleanField(
        null=True, blank=True,
        help_text="Null for Sawal-Jawab (not auto-graded; student self-checks).",
    )
    attempted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-attempted_at"]

    def __str__(self):
        mark = "✓" if self.is_correct else "✗"
        return f"{self.student} {mark} {self.exercise}"


class LessonProgress(models.Model):
    """Per-student progress on a lesson. Opening != completion (spec)."""

    STATUS_NOT_STARTED = "not_started"
    STATUS_IN_PROGRESS = "in_progress"
    STATUS_COMPLETED = "completed"
    STATUS_CHOICES = [
        (STATUS_NOT_STARTED, "Not started"),
        (STATUS_IN_PROGRESS, "In progress"),
        (STATUS_COMPLETED, "Completed"),
    ]

    student = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
                                related_name="lesson_progress")
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name="progress_records")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES,
                              default=STATUS_NOT_STARTED)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [("student", "lesson")]
        ordering = ["student", "lesson__track", "lesson__order"]

    def __str__(self):
        return f"{self.student} — {self.lesson.title} [{self.get_status_display()}]"
