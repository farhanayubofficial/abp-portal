"""Curriculum views. Students see published lessons only; staff see everything."""
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views import View
from django.views.generic import DetailView, ListView, TemplateView

from .models import CourseTrack, Exercise, ExerciseAttempt, Lesson, LessonProgress


class TrackListView(LoginRequiredMixin, ListView):
    model = CourseTrack
    template_name = "courses/track_list.html"
    context_object_name = "tracks"


class TrackDetailView(LoginRequiredMixin, DetailView):
    model = CourseTrack
    template_name = "courses/track_detail.html"
    context_object_name = "track"
    slug_field = "code"
    slug_url_kwarg = "code"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        lessons = self.object.lessons.select_related("level", "book")
        if not self.request.user.is_admin and not self.request.user.is_teacher:
            lessons = lessons.filter(status=Lesson.STATUS_PUBLISHED)
        ctx["levels"] = self.object.levels.prefetch_related("lessons")
        # Group lessons by level for the template
        by_level = {}
        unassigned = []
        for lesson in lessons:
            if lesson.level_id:
                by_level.setdefault(lesson.level_id, []).append(lesson)
            else:
                unassigned.append(lesson)
        ctx["lessons_by_level"] = by_level
        ctx["unassigned_lessons"] = unassigned
        ctx["books"] = self.object.books.all()
        return ctx


def _visible_lessons(user, track):
    lessons = track.lessons.select_related("level", "book")
    if not (user.is_admin or user.is_teacher):
        lessons = lessons.filter(status=Lesson.STATUS_PUBLISHED)
    return lessons


class LessonDetailView(LoginRequiredMixin, DetailView):
    model = Lesson
    template_name = "courses/lesson_detail.html"
    context_object_name = "lesson"

    def get_queryset(self):
        qs = super().get_queryset()
        user = self.request.user
        if not (user.is_admin or user.is_teacher):
            qs = qs.filter(status=Lesson.STATUS_PUBLISHED)
        return qs

    def get(self, request, *args, **kwargs):
        lesson = self.get_object()
        user = request.user
        # Students must unlock sequentially; staff bypass.
        if not (user.is_admin or user.is_teacher) and not lesson.is_unlocked_for(user):
            messages.warning(request, "Please complete the previous lesson first — lessons unlock in order.")
            return redirect("track_detail", code=lesson.track.code)
        # Opening a lesson marks in_progress, NEVER completed (spec).
        if not (user.is_admin or user.is_teacher):
            progress, created = LessonProgress.objects.get_or_create(
                student=user, lesson=lesson)
            if created or progress.status == LessonProgress.STATUS_NOT_STARTED:
                progress.status = LessonProgress.STATUS_IN_PROGRESS
                progress.started_at = progress.started_at or timezone.now()
                progress.save()
        return super().get(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        lesson = self.object
        user = self.request.user
        ctx["exercises"] = lesson.exercises.all()
        progress = LessonProgress.objects.filter(student=user, lesson=lesson).first()
        ctx["progress"] = progress
        # Next lesson for the "continue" button
        ctx["next_lesson"] = (
            Lesson.objects.filter(track=lesson.track, level=lesson.level,
                                  order=lesson.order + 1).first()
        )
        # Teachers see recent student attempts (to check Sawal-Jawab answers)
        if user.is_teacher or user.is_admin:
            ctx["recent_attempts"] = (
                ExerciseAttempt.objects.filter(exercise__lesson=lesson)
                .select_related("student", "exercise")
                .order_by("-attempted_at")[:20]
            )
        return ctx


class LessonCompleteView(LoginRequiredMixin, View):
    """Explicit completion only — opening a lesson never completes it (spec)."""

    def post(self, request, pk):
        lesson = get_object_or_404(Lesson, pk=pk, status=Lesson.STATUS_PUBLISHED)
        user = request.user
        if not (user.is_admin or user.is_teacher) and not lesson.is_unlocked_for(user):
            messages.error(request, "This lesson is still locked.")
            return redirect("track_detail", code=lesson.track.code)
        progress, _ = LessonProgress.objects.get_or_create(student=user, lesson=lesson)
        progress.status = LessonProgress.STATUS_COMPLETED
        progress.completed_at = timezone.now()
        progress.save()
        messages.success(request, f"'{lesson.title}' complete! The next lesson is now unlocked.")
        nxt = Lesson.objects.filter(track=lesson.track, level=lesson.level,
                                    order=lesson.order + 1).first()
        if nxt:
            return redirect("lesson_detail", pk=nxt.pk)
        return redirect("track_detail", code=lesson.track.code)


class ExerciseSubmitView(LoginRequiredMixin, View):
    """Submit one answer; result stored as an audited attempt."""

    def post(self, request, pk):
        exercise = get_object_or_404(Exercise, pk=pk)
        lesson = exercise.lesson
        user = request.user
        if lesson.status != Lesson.STATUS_PUBLISHED and not (user.is_admin or user.is_teacher):
            messages.error(request, "This exercise is not available.")
            return redirect("track_detail", code=lesson.track.code)
        answer = request.POST.get("answer", "").strip()
        is_correct = exercise.check_answer(answer)
        ExerciseAttempt.objects.create(
            student=user, exercise=exercise, answer=answer, is_correct=is_correct)
        if is_correct is None:
            messages.info(request, "Answer saved — compare it with the model answer below.")
        elif is_correct:
            messages.success(request, "Correct answer! ✅")
        else:
            messages.error(request, "Incorrect — please try again.")
        return redirect("lesson_detail", pk=lesson.pk)


class QuizView(LoginRequiredMixin, View):
    """One question at a time. Answer -> feedback -> next question -> score."""

    template_name = "courses/quiz.html"

    def _exercises(self, lesson):
        return list(lesson.exercises.order_by("order"))

    def _state(self, request, lesson):
        return request.session.get(f"quiz_{lesson.pk}", {})

    def _save_state(self, request, lesson, state):
        request.session[f"quiz_{lesson.pk}"] = state

    def _max_marks(self, exercises):
        return sum(ex.marks for ex in exercises if ex.auto_grade)

    def get(self, request, pk):
        lesson = get_object_or_404(Lesson, pk=pk)
        exercises = self._exercises(lesson)
        if not exercises:
            messages.info(request, "No quiz questions in this lesson yet.")
            return redirect("lesson_detail", pk=pk)
        # ?start=1 restarts
        if request.GET.get("start"):
            self._save_state(request, lesson, {"i": 0, "score": 0, "answers": []})
        state = self._state(request, lesson)
        if not state:
            state = {"i": 0, "score": 0, "answers": []}
            self._save_state(request, lesson, state)
        i = state["i"]
        max_marks = self._max_marks(exercises)
        if i >= len(exercises):
            score = state["score"]
            percent = round(score / max_marks * 100) if max_marks else 0
            return render(request, self.template_name, {
                "lesson": lesson, "finished": True,
                "score": score, "total": len(exercises),
                "max_marks": max_marks, "percent": percent,
                "answers": state["answers"],
            })
        return render(request, self.template_name, {
            "lesson": lesson, "finished": False,
            "exercise": exercises[i], "index": i + 1, "total": len(exercises),
            "feedback": None, "score": state["score"], "max_marks": max_marks,
        })

    def post(self, request, pk):
        lesson = get_object_or_404(Lesson, pk=pk)
        exercises = self._exercises(lesson)
        state = self._state(request, lesson)
        if not state:
            return redirect("quiz", pk=pk)
        i = state["i"]
        if i >= len(exercises):
            return redirect("quiz", pk=pk)
        ex = exercises[i]
        answer = request.POST.get("answer", "").strip()
        is_correct = ex.check_answer(answer)
        ExerciseAttempt.objects.create(
            student=request.user, exercise=ex, answer=answer, is_correct=is_correct)
        # Marks: +marks if correct, -marks if wrong (negative marking).
        # Sawal-Jawab is self-checked: no marks change.
        marks_delta = 0
        if is_correct is True:
            marks_delta = ex.marks
        elif is_correct is False:
            marks_delta = -ex.marks
        state["score"] += marks_delta
        state["answers"].append({
            "q": ex.question, "given": answer,
            "correct": ex.correct_answer or ex.model_answer,
            "ok": bool(is_correct), "marks_delta": marks_delta,
            "marks": ex.marks,
        })
        state["i"] = i + 1
        state["last_feedback"] = {
            "ok": bool(is_correct), "is_qa": ex.question_type == "qa",
            "correct": ex.correct_answer, "model": ex.model_answer,
            "marks_delta": marks_delta, "marks": ex.marks,
        }
        self._save_state(request, lesson, state)
        return render(request, self.template_name, {
            "lesson": lesson, "finished": False,
            "exercise": ex, "index": i + 1, "total": len(exercises),
            "feedback": state.pop("last_feedback"),
            "score": state["score"], "max_marks": self._max_marks(exercises),
        })


class MyProgressView(LoginRequiredMixin, TemplateView):
    template_name = "courses/my_progress.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        user = self.request.user
        records = (LessonProgress.objects.filter(student=user)
                   .select_related("lesson__track", "lesson__level")
                   .order_by("lesson__track__name", "lesson__order"))
        total = Lesson.objects.filter(status=Lesson.STATUS_PUBLISHED).count()
        done = records.filter(status=LessonProgress.STATUS_COMPLETED).count()
        ctx["records"] = records
        ctx["total"] = total
        ctx["done"] = done
        ctx["percent"] = round(done / total * 100) if total else 0
        return ctx
