"""Seed the four fixed course tracks (spec section 4)."""
from django.db import migrations

TRACKS = [
    ("quranic-arabic", "Quranic Arabic", "Arabic of the Quran: vocabulary, grammar and understanding."),
    ("arabic-language", "Arabic Language", "Reading, writing, listening and speaking skills."),
    ("spoken-arabic", "Spoken Arabic", "Conversational and spoken Arabic fluency."),
    ("tafsir", "Tafsir al-Quran", "Exegesis and interpretation of the Quran."),
]


def seed_tracks(apps, schema_editor):
    CourseTrack = apps.get_model("courses", "CourseTrack")
    for code, name, description in TRACKS:
        CourseTrack.objects.get_or_create(code=code, defaults={"name": name, "description": description})


def unseed_tracks(apps, schema_editor):
    CourseTrack = apps.get_model("courses", "CourseTrack")
    CourseTrack.objects.filter(code__in=[t[0] for t in TRACKS]).delete()


class Migration(migrations.Migration):
    dependencies = [("courses", "0001_initial")]

    operations = [migrations.RunPython(seed_tracks, unseed_tracks)]
