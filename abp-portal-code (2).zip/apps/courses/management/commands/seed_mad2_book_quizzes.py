"""Book-faithful ENGLISH quizzes for Madinah Book 2 - from actual book pages read visually.
Book: Duroos al-Lughat al-Arabiyya Book 2, Dr. V. Abdur Rahim."""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=2)
SRC = "Duroos al-Lughat al-Arabiyya — Book 2 (Dr. V. Abdur Rahim)"

TITLES = {
    1: "Madinah 2: The Present Tense Verb (الفعل المضارع)",
    2: "Madinah 2: Command and Prohibition (الأمر والنهي)",
    3: "Madinah 2: The Direct Object (المفعول به)",
    4: "Madinah 2: Adverbs of Time and Place (الظرف)",
    5: "Madinah 2: The Circumstantial Clause (الحال)",
    6: "Madinah 2: Adjectives (النعت)",
    7: "Madinah 2: Possessive Construction (الإضافة)",
    8: "Madinah 2: Compound Numbers (الأعداد المركبة)",
    9: "Madinah 2: Inna and Its Sisters (إنَّ وأخواتها)",
    10: "Madinah 2: Dialogue Practice (المحادثة)",
}

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kw = dict(lesson=lesson, order=n, question_type=qtype, question=question,
              options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer; kw["auto_grade"] = False; kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

for order, title in TITLES.items():
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    lesson.title = title
    lesson.source_reference = SRC
    lesson.save()
    n, _ = Exercise.objects.filter(lesson=lesson).delete()
    print(f"{title}: {n} old deleted")

# ===== Lesson 1: Present Tense Verb =====
add(1, "mcq", "What does «يَذْهَبُ» mean?", "He goes / he is going",
    ["He went", "He goes / he is going", "Go!", "He did not go"],
    "From the book's conjugation tables")
add(1, "fill_blank", "Complete the sentence: هُمْ ___ (they go).", "يَذْهَبُونَ",
    hint="Look at the book's table: هم يذهبون")
add(1, "mcq", "In «لَمْ يَذْهَبْ» (he did not go), what is the sign of jazm?", "Sukoon on the last letter",
    ["Fatha on the last letter", "Sukoon on the last letter", "Damma on the last letter", "Dropping the noon"],
    "Book: علامة الجزم السكون")
add(1, "qa", "What is the difference between «لَمْ يَفْعَلْ» and «لَنْ يَفْعَلَ»? Give the book's examples.",
    "«لَمْ يَفْعَلْ» = he did not do (past negation), e.g. لَمْ يَذْهَبْ. «لَنْ يَفْعَلَ» = he will never do (future emphatic negation), e.g. إِنِّي لَنْ أَذْهَبَ إِلى الهِنْدِ (I will never go to India) from Lesson 19.")

# ===== Lesson 2: Command and Prohibition =====
add(2, "mcq", "What is the command form of «يَكْتُبُ» (he writes)?", "اُكْتُبْ",
    ["يَكْتُبُ", "اُكْتُبْ", "كَتَبَ", "كِتَاب"],
    "Book: أنت تكتب ← اكتب")
add(2, "fill_blank", "Complete: ___ هُنا يا بِلالُ (Sit here, Bilal).", "اِجْلِسْ",
    hint="From the book: اجلس هنا يا بلال")
add(2, "mcq", "What does «يا أَحْمَدُ لا تَذْهَبْ» mean?", "O Ahmad, do not go",
    ["O Ahmad, go", "O Ahmad, do not go", "Ahmad went", "Ahmad will go"],
    "لا الناهية = prohibition")
add(2, "qa", "How is the prohibition (النهي) formed in the book? Give two examples.",
    "Prohibition is formed with لا الناهية + present tense: e.g. لا تَدْخُلْ (do not enter), لا تَسْمَعْ (do not listen). From the book: يا أحمد لا تذهب (O Ahmad, don't go).")

# ===== Lesson 3: Direct Object =====
add(3, "mcq", "In «رَأَيْتُ حامِدًا» (I saw Hamid), what is «حامِدًا»?", "Direct object (mansoob)",
    ["Subject (marfoo)", "Direct object (mansoob)", "Possessive (majroor)", "Adjective"],
    "Book: اجعل كلّا من الكلمات الآتية مفعولا به")
add(3, "fill_blank", "Complete the answer: أَرَأَيْتَ زَيْنَبَ؟ نَعَمْ، ___ (Yes, I saw her).", "رَأَيْتُها",
    hint="Book: نعم، رأيتُها")
add(3, "mcq", "What does «نَعَمْ، رَأَيْتُهُمْ» mean?", "Yes, I saw them",
    ["Yes, I saw him", "Yes, I saw her", "Yes, I saw them", "No, I did not see them"],
    "Book exercise: أرأيت حامدا وهشاما وعليا؟ نعم، رأيتُهم")
add(3, "qa", "What is المفعول به (the direct object)? Give an example from the book.",
    "المفعول به is the object on which the action falls; it is mansoob (accusative). Example from the book: كَتَبَ المُدَرِّسُ الدَّرْسَ عَلَى السَّبُّورَةِ (The teacher wrote the lesson on the board) — الدَّرْسَ is the direct object.")

# ===== Lesson 4: Adverbs of Time and Place =====
add(4, "mcq", "What does «مُبَكِّرًا» mean?", "Early",
    ["Late", "Early", "Always", "Quickly"],
    "Opposite: مُتَأَخِّرًا (late)")
add(4, "fill_blank", "Complete: ذَهَبْتُ إِلَى المَدْرَسَةِ اليَوْمَ ___ وَرَجَعْتُ إِلَى البَيْتِ مُتَأَخِّرًا (I went to school early today and returned home late).", "مُبَكِّرًا",
    hint="Book: ذهبت إلى المدرسة اليوم مبكرا")
add(4, "mcq", "What does «هُوَ غائِبٌ مُنْذُ أُسْبُوعٍ» mean?", "He has been absent for a week",
    ["He was absent a week ago", "He has been absent for a week", "He will be absent for a week", "He is absent every week"],
    "Book: منذ = since/for")
add(4, "qa", "Explain the use of «مُنْذُ» with an example from the book.",
    "مُنْذُ means 'since' or 'for' (duration). Example from the book: نَسْكُنُ فِي هٰذَا البَيْتِ مُنْذُ سَنَةٍ (We have lived in this house for a year).")

# ===== Lesson 5: Circumstantial Clause (Haal) =====
add(5, "mcq", "In «جاءَ الطَّالِبُ راكِبًا» (The student came riding), what is «راكِبًا»?", "Haal (circumstantial clause, mansoob)",
    ["Subject", "Haal (circumstantial clause, mansoob)", "Direct object", "Adjective of الطالب"],
    "الحال describes the state of the subject during the action")
add(5, "fill_blank", "Complete: خَرَجَ المُدِيرُ ___ (The director went out smiling).", "مُبْتَسِمًا",
    hint="The haal is mansoob")
add(5, "mcq", "What is the case (إعراب) of the الحال?", "Mansoob (accusative)",
    ["Marfoo", "Mansoob (accusative)", "Majroor", "Majzoom"],
    "الحال is always mansoob")
add(5, "qa", "What is الحال? Give an example and explain its case.",
    "الحال is a word describing the state of the subject or object during the action, and it is always mansoob. Example: جاءَ الطَّالِبُ راكِبًا (The student came riding) — راكِبًا is the haal.")

# ===== Lesson 6: Adjectives =====
add(6, "mcq", "In «القَمِيصُ الأَصْفَرُ» (the yellow shirt), what is «الأَصْفَرُ»?", "An adjective (نعت) describing the shirt",
    ["The subject", "An adjective (نعت) describing the shirt", "The direct object", "A possessive"],
    "Book: اسأل ذاك الرجلَ القميصَ الأصفرَ")
add(6, "fill_blank", "Complete: هٰذا بَيْتٌ ___ (This is a beautiful house).", "جَمِيلٌ",
    hint="The adjective matches the noun")
add(6, "mcq", "What does «صُوَرٌ مُلَوَّنَةٌ» mean?", "Colored pictures",
    ["Beautiful pictures", "Colored pictures", "Big pictures", "Old pictures"],
    "Book: عندي معجمٌ صورٌ ملونةٌ")
add(6, "qa", "What is the rule of النعت (adjective)? Give a book example.",
    "النعت follows and matches the described noun (المنعوت) in definiteness, gender, number and case. Example from the book: القَمِيصُ الأَصْفَرُ (the yellow shirt) — both definite, masculine, singular, marfoo.")

# ===== Lesson 7: Possessive Construction =====
add(7, "mcq", "In «أَبْناءُ المُدَرِّسِ» (the teacher's sons), what is the case of «المُدَرِّسِ»?", "Majroor (genitive)",
    ["Marfoo", "Mansoob", "Majroor (genitive)", "Majzoom"],
    "The second part of idafa (المضاف إليه) is always majroor")
add(7, "fill_blank", "Complete: ___ المُهَنْدِسِينَ (the engineers' houses).", "بُيُوتُ",
    hint="Book: بيوت المهندسين")
add(7, "mcq", "What does «دِينُ الكافِرِينَ» mean?", "The religion of the disbelievers",
    ["The disbelievers' religion book", "The religion of the disbelievers", "The religious disbelievers", "A disbeliever's religion (singular)"],
    "Book exercise on idafa")
add(7, "qa", "Explain الإضافة (possessive construction) with a book example.",
    "الإضافة joins two nouns: the first (المضاف) loses tanween, the second (المضاف إليه) is majroor. Example from the book: أَبْناءُ المُدَرِّسِ (the teacher's sons).")

# ===== Lesson 8: Compound Numbers =====
add(8, "mcq", "In «جاءَ اليَوْمَ ٢٢ طالِبًا جَدِيدًا» (22 new students came today), why is «طالِبًا» mansoob?", "It is تمييز (specification) after the number",
    ["It is the subject", "It is تمييز (specification) after the number", "It is the direct object", "It is an adjective"],
    "Numbers 11-99 take a mansoob tamyeez")
add(8, "fill_blank", "Complete in Arabic words: فِي هٰذَا الكِتابِ ___ دَرْسًا (In this book are 21 lessons).", "أَحَدٌ وَعِشْرُونَ",
    hint="Book: في هذا الكتاب ٢١ درسا")
add(8, "mcq", "What does «هٰذَا المَلْعَبُ طُولُهُ ٢٨ مِتْرًا» mean?", "This playground's length is 28 meters",
    ["This playground is 28 years old", "This playground's length is 28 meters", "This playground costs 28 meters", "28 playgrounds"],
    "Book: هذا الملعب طوله ٢٨ مترا وعرضه ٢٤ مترا")
add(8, "qa", "Explain the rule of تمييز with numbers 11-99, with a book example.",
    "Numbers 11 to 99 are followed by a singular mansoob noun called تمييز (specification). Example from the book: جاءَ اليَوْمَ ٢٢ طالِبًا جَدِيدًا (22 new students came today) — طالِبًا is the tamyeez.")

# ===== Lesson 9: Inna and Sisters =====
add(9, "mcq", "In «إِنَّكَ طالِبٌ ذَكِيٌّ» (Indeed you are a clever student), what did «إِنَّ» do to the pronoun?", "Made it mansoob (إِنَّكَ)",
    ["Made it marfoo", "Made it mansoob (إِنَّكَ)", "Made it majroor", "Nothing"],
    "From Lesson 1 dialogue: إنك طالب ذكي ومجتهد")
add(9, "fill_blank", "Complete: ___ اللّٰهَ رَبِّي (Indeed, Allah is my Lord).", "إِنَّ",
    hint="Book: إن الله ربي")
add(9, "mcq", "What does «أَظُنُّ أَنَّكَ مِنْ باكِسْتانَ» mean?", "I think that you are from Pakistan",
    ["I know you are from Pakistan", "I think that you are from Pakistan", "You are from Pakistan, I swear", "Are you from Pakistan?"],
    "Book: أظن أنك من باكستان")
add(9, "qa", "List إِنَّ and its sisters with their meanings.",
    "إِنَّ (indeed/verily), أَنَّ (that), كَأَنَّ (as if), لٰكِنَّ (but), لَيْتَ (if only/would that), لَعَلَّ (hopefully/perhaps). Example from the book: كَيْفَ حالُكَ يا أُسْتاذُ؟ لَعَلَّكَ بِخَيْرٍ (How are you, teacher? Hopefully you are well).")

# ===== Lesson 10: Dialogue Practice =====
add(10, "mcq", "In the book's first dialogue, where is Hashim from?", "India (الهِنْد)",
    ["Pakistan", "India (الهِنْد)", "Japan", "Bangladesh"],
    "هاشم: إني من الهند")
add(10, "fill_blank", "Complete the teacher's greeting: كَيْفَ حالُكَ يا أُسْتاذُ؟ لَعَلَّكَ ___ (Hopefully you are well).", "بِخَيْرٍ",
    hint="From الدرس الأول")
add(10, "mcq", "In Lesson 19, why won't Ayyub go to India in the summer vacation?", "He wants to go to Baghdad to visit his uncle",
    ["He is sick", "He wants to go to Baghdad to visit his uncle", "He has exams", "He has no money"],
    "أريد أن أذهب إلى بغداد لأزور خالي")
add(10, "qa", "In Lesson 19, what do Ayyub's brothers and sisters plan to do in the vacation?",
    "His brothers will stay in Madinah to memorize the Quran (يُرِيدُونَ أَنْ يَبْقَوْا بِالمَدِينَةِ لِيَحْفَظُوا القُرْآنَ الكَرِيمَ). His sisters will go to Makkah for Umrah, stay a month with their aunt, then go to Riyadh to visit their paternal aunt.")

print("done:", Exercise.objects.filter(lesson__track=track, lesson__level=level, lesson__order__lte=10).count())
