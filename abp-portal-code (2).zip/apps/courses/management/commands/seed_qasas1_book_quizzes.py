"""Book-faithful ENGLISH quizzes for Qasas al-Nabiyyin Part 1 (Nadwi).
Based on actual pages read visually from Qasas-un-Nabiyeen-1-Nadwi.pdf.
Part 1 contains ONLY: Story of Ibrahim (16 sections) + Story of Yusuf (25 sections).
"""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=1)

TITLES = {
    11: "Qasas 1: Ibrahim (AS) — Smashing the Idols",
    12: "Qasas 1: Ibrahim (AS) — The Cool Fire and Finding Allah",
    13: "Qasas 1: Ibrahim (AS) — The Call, Makkah and the Kaaba",
    14: "Qasas 1: Yusuf (AS) — The Dream and the Well",
    15: "Qasas 1: Yusuf (AS) — From Prison to the Throne",
}
for order, title in TITLES.items():
    les = Lesson.objects.get(track=track, level=level, order=order)
    les.title = title
    les.source_reference = "Qasas al-Nabiyyin Part 1 (Nadwi) — " + title
    les.save()
    n, _ = Exercise.objects.filter(lesson=les).delete()
    print(f"{title}: deleted {n} old exercises")

def add(order, qtype, question, answer, options=None, hint=""):
    les = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=les).count() + 1
    kw = dict(lesson=les, order=n, question_type=qtype, question=question,
              options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer; kw["auto_grade"] = False; kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

SRC = "Qasas al-Nabiyyin Part 1 (Abu'l-Hasan Nadwi) — read from the actual book"

# ============ Lesson 11: Ibrahim — Smashing the Idols (book sections 1-5) ============
add(11, "mcq",
    "In the book, what was Azar's (آزر) famous profession?",
    "He sold idols (بائع الأصنام)",
    ["He sold idols (بائع الأصنام)", "He built houses", "He was a shepherd", "He taught children"],
    "Book section 1: بائع الأصنام")
add(11, "fill_blank",
    "Fill in the blank: Ibrahim knew the idols were only ______ (حجارة) — they cannot speak or hear.",
    "stones",
    hint="The book repeats: الأصنام حجارة")
add(11, "mcq",
    "On the Eid day, what excuse did Ibrahim give to stay behind while everyone left?",
    "He said: 'I am sick' (أنا سقيم)",
    ["He said: 'I am sick' (أنا سقيم)", "He said he was travelling", "He hid in the well", "He went to the market"],
    "Book section 4: إبراهيم يكسر الأصنام")
add(11, "qa",
    "When the people asked Ibrahim 'Did you do this to our gods?', what clever answer did he give (from the book)?",
    "He said: 'Rather the biggest one did it — ask them, if they can speak!' (بل فعله كبيرهم هذا فاسألوهم إن كانوا ينطقون). He had left the biggest idol unbroken and hung the axe (الفأس) on its neck.",
    hint="Book section 5: من فعل هذا؟")

# ============ Lesson 12: Ibrahim — The Cool Fire and Finding Allah (sections 6-8) ============
add(12, "mcq",
    "What punishment did the people choose for Ibrahim after he broke the idols?",
    "'Burn him and help your gods!' (حرقوه وانصروا آلهتكم)",
    ["'Forgive him'", "'Burn him and help your gods!' (حرقوه وانصروا آلهتكم)", "'Send him to Egypt'", "'Make him king'"],
    "Book section 6: نار باردة")
add(12, "fill_blank",
    "Fill in the blank: Allah commanded the fire: 'O fire, be cool and ______ upon Ibrahim' (برداً وسلاماً).",
    "safe",
    hint="Book: يا نار كوني برداً وسلاماً على إبراهيم")
add(12, "mcq",
    "Ibrahim looked at the star, the moon and the sun, then rejected each as his lord. Why?",
    "Each one sets/disappears — but Allah is Living and never dies (حي لا يموت), Everlasting and never disappears (باق لا يغيب)",
    ["They were too small", "Each one sets/disappears — but Allah is Living and never dies (حي لا يموت), Everlasting and never disappears (باق لا يغيب)", "He could not see them clearly", "His father told him to"],
    "Book section 7: من ربي")
add(12, "qa",
    "According to the book, why can't the star, moon or sun help Ibrahim?",
    "Because each is weak (ضعيف): the morning overcomes the star, the sun overcomes the moon, and the night and clouds overcome the sun. Only Allah helps him, for Allah is Living (لا يموت), Everlasting (لا يغيب) and Strong — nothing overcomes Him (لا يغلبه شيء).")

# ============ Lesson 13: Ibrahim — The Call, Makkah and the Kaaba (sections 9-16) ============
add(13, "mcq",
    "When Ibrahim asked his people 'What do you worship?' and they said 'idols', what was their only reason?",
    "'We found our fathers doing so' (بل وجدنا آباءنا كذلك يفعلون)",
    ["'The idols speak to us'", "'We found our fathers doing so' (بل وجدنا آباءنا كذلك يفعلون)", "'The king ordered us'", "'They give us food'"],
    "Book section 9: دعوة إبراهيم")
add(13, "fill_blank",
    "Fill in the blank: Ibrahim silenced the king by saying: 'Allah brings the sun from the east — bring it from the ______!'",
    "west",
    hint="Book: فأت بها من المغرب")
add(13, "mcq",
    "In Makkah, Hajar ran between which two hills searching for water?",
    "Safa and Marwa (الصفا والمروة)",
    ["Safa and Marwa (الصفا والمروة)", "Arafat and Mina", "Uhud and Badr", "Taur and Hira"],
    "Book section 13: بئر زمزم")
add(13, "qa",
    "What did Ismail (عليه السلام) reply when Ibrahim told him about the dream of sacrifice?",
    "He said: 'O my father, do what you are commanded — you will find me, if Allah wills, among the patient.' (يا أبت افعل ما تؤمر ستجدني إن شاء الله من الصابرين). Allah then sent a ram (كبش) from Paradise instead, and commanded the sacrifice on Eid al-Adha.")

# ============ Lesson 14: Yusuf — The Dream and the Well (sections 1-7) ============
add(14, "mcq",
    "What did Yusuf see in his strange dream (الرؤيا العجيبة)?",
    "Eleven stars, the sun and the moon prostrating to him",
    ["Eleven stars, the sun and the moon prostrating to him", "Seven fat cows eating seven lean cows", "A big fire in the desert", "Birds carrying bread"],
    "Book: رأى أحد عشر كوكباً والشمس والقمر كل يسجد له")
add(14, "fill_blank",
    "Fill in the blank: Yaqub warned Yusuf: 'Do not tell your dream to your brothers — they will ______ you.' (يحسدونك)",
    "envy",
    hint="Book: فإنهم يحسدونك ويكونون لك عدواً")
add(14, "mcq",
    "What excuse did the brothers give Yaqub for taking Yusuf with them?",
    "'Send him with us tomorrow to enjoy and play — we will guard him' (أرسله معنا غداً يرتع ويلعب وإنا له لحافظون)",
    ["'We want him to work in the fields'", "'Send him with us tomorrow to enjoy and play — we will guard him' (أرسله معنا غداً يرتع ويلعب وإنا له لحافظون)", "'The king invited him'", "'He wants to travel to Egypt'"],
    "Book section 3: وفد إلى يعقوب")
add(14, "qa",
    "How did Yaqub (عليه السلام) know the 'wolf ate Yusuf' story was a lie?",
    "He knew that if a wolf eats a man, it tears him and rips his shirt — but Yusuf's shirt (قميص) was intact (سالماً), only stained with false blood (دم كذب). So he said: 'This is a story you made up — beautiful patience!' (فصبر جميل).")

# ============ Lesson 15: Yusuf — From Prison to the Throne (sections 8-25) ============
add(15, "mcq",
    "When the Aziz's wife tried to seduce him, what did Yusuf say?",
    "'No! I will not betray my master — he treated me well. I fear Allah.' (إني أخاف الله)",
    ["'I agree, but keep it secret'", "'No! I will not betray my master — he treated me well. I fear Allah.' (إني أخاف الله)", "'Let me think about it'", "'I will tell the king'"],
    "Book section 8: الوفاء والأمانة")
add(15, "fill_blank",
    "Fill in the blank: In prison Yusuf preached Tawhid: 'Are many different lords better, or Allah, the One, the ______?' (الواحد القهار)",
    "Irresistible",
    hint="Book: أأرباب متفرقون خير أم الله الواحد القهار")
add(15, "mcq",
    "What position did Yusuf request from the king, and why?",
    "'Put me over the storehouses of the land — I am a knowing guardian' (اجعلني على خزائن الأرض إني حفيظ عليم) — because rulers wasted the storehouses while people starved",
    ["To be the army commander", "'Put me over the storehouses of the land — I am a knowing guardian' (اجعلني على خزائن الأرض إني حفيظ عليم) — because rulers wasted the storehouses while people starved", "To be the king's cupbearer", "To return to Canaan immediately"],
    "Book section 16: على خزائن الأرض")
add(15, "qa",
    "How did Yusuf finally reveal himself to his brothers, and what did he say to forgive them?",
    "When they came a third time complaining of poverty, he could not control himself and said: 'Do you know what you did to Yusuf and his brother when you were ignorant?' (هل علمتم ما فعلتم بيوسف وأخيه إذ أنتم جاهلون). They realised he was Yusuf. He forgave them saying: 'May Allah forgive you — He is the most merciful.' (يغفر الله لكم وهو أرحم الراحمين). His dream then came true when his parents and brothers prostrated to him.")

print("done;", Exercise.objects.filter(lesson__track=track, lesson__level=level,
      lesson__order__in=[11,12,13,14,15]).count(), "exercises for Qasas 1 lessons")
