"""Book-faithful ENGLISH quizzes for Madinah Book 1.
Based on actual pages read from Madinah-Arabic-Book-1-Abdur-Rahim.pdf:
pp.2-14 (hadha/dhalika), p.17 (al + adjectives), p.22 (fi/ala),
p.28 (idafa), p.33 (hadhihi), pp.37-40 (tilka), p.46 (min/ila, amam/khalf),
p.52 (adjectives), p.55 (possessive li/laka/lahu/laha), pp.66-72 (past tense, plurals),
pp.80-98 (plurals), p.110 (numbers).
"""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=1)

TITLES = {
    1: "Madinah 1: Demonstrative Pronouns (هذا، ذلك، هذه، تلك)",
    2: "Madinah 1: Personal & Possessive Pronouns (هو، هي، لي، لك...)",
    3: "Madinah 1: Prepositions (في، على، من، إلى، أمام، خلف)",
    4: "Madinah 1: Nominal Sentences (الجملة الاسمية)",
    5: "Madinah 1: The Definite Article (ال)",
    6: "Madinah 1: Plurals (الجمع)",
    7: "Madinah 1: Numbers (الأعداد)",
    8: "Madinah 1: Adjectives (الصفة)",
    9: "Madinah 1: Past Tense Verbs (الفعل الماضي)",
    10: "Madinah 1: Conjunctions (حروف العطف)",
}

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kw = dict(lesson=lesson, order=n, question_type=qtype,
              question=question, options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer; kw["auto_grade"] = False; kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

# Update titles + wipe old exercises
for order, title in TITLES.items():
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    lesson.title = title
    lesson.source_reference = "دروس اللغة العربية — کتاب 1 (Madinah Book 1)"
    lesson.save()
    Exercise.objects.filter(lesson=lesson).delete()
print("titles updated, old exercises deleted")

# ============ Lesson 1: Demonstratives ============
add(1, "mcq", "What does هَذَا mean?", "this (masculine)",
    ["this (masculine)", "that (masculine)", "this (feminine)", "these"],
    "Book Lesson 1: مَا هَذَا؟ هَذَا مَسْجِدٌ")
add(1, "mcq", "In the book: مَا هَذَا؟ هَذَا مَسْجِدٌ. What does هَذَا مَسْجِدٌ mean?",
    "This is a mosque",
    ["This is a mosque", "That is a house", "What is this?", "This is a book"])
add(1, "fill_blank", "Fill in the blank: ___ نَجْمٌ (That is a star).", "ذَلِكَ",
    hint="Book Lesson 2: مَا ذَلِكَ؟ ذَلِكَ نَجْمٌ")
add(1, "qa", "Explain the difference between هَذَا and ذَلِكَ using examples from the book.",
    "هَذَا means 'this' (near): هَذَا مَسْجِدٌ (this is a mosque). ذَلِكَ means 'that' (far): ذَلِكَ نَجْمٌ (that is a star). The book contrasts them: هَذَا مَسْجِدٌ وَذَلِكَ بَيْتٌ (this is a mosque and that is a house).")

# ============ Lesson 2: Pronouns ============
add(2, "mcq", "أَيْنَ زَيْنَبُ؟ هِيَ فِي الْغُرْفَةِ. Who does هِيَ refer to?",
    "Zainab (she)",
    ["Zainab (she)", "The teacher (he)", "The students", "The room"])
add(2, "mcq", "What does هَذَا قَلَمِي mean?", "This is my pen",
    ["This is my pen", "This is your pen", "This is his pen", "This is her pen"],
    "Book: هَذَا قَلَمِي، هَذَا قَلَمُكَ، هَذَا قَلَمُهُ، هَذَا قَلَمُهَا")
add(2, "fill_blank", "Fill in: ___ أَخٌ؟ لَا، مَا لِي أَخٌ (Do YOU have a brother? No, I have no brother).", "أَلَكَ",
    hint="Book: أَلَكَ أَخٌ؟ لَا، مَا لِي أَخٌ")
add(2, "qa", "What do the endings in هَذَا قَلَمِي / قَلَمُكَ / قَلَمُهُ / قَلَمُهَا mean?",
    "ي = my (قَلَمِي = my pen), كَ = your (masc.) (قَلَمُكَ = your pen), هُ = his (قَلَمُهُ = his pen), هَا = her (قَلَمُهَا = her pen). The book teaches these as attached possessive pronouns.")

# ============ Lesson 3: Prepositions ============
add(3, "mcq", "What does الْقَلَمُ عَلَى الْمَكْتَبِ mean?", "The pen is on the desk",
    ["The pen is on the desk", "The pen is in the bag", "The book is on the desk", "The pen is under the desk"],
    "Book: مَاذَا عَلَى الْمَكْتَبِ؟")
add(3, "mcq", "ذَهَبَ حَامِدٌ إِلَى فَرَنْسَا. What does إِلَى mean here?", "to",
    ["to", "from", "in", "on"],
    "Hamid went TO France")
add(3, "fill_blank", "Fill in: آمِنَةُ ___ الْغُرْفَةِ (Amina is IN the room).", "فِي",
    hint="Book: آمِنَةُ فِي الْغُرْفَةِ")
add(3, "qa", "Translate into English: بَيْتُ الْإِمَامِ خَلْفَ الْمَسْجِدِ",
    "The imam's house is behind the mosque. (خَلْفَ = behind; أَمَامَ = in front of, e.g. السَّبُّورَةُ أَمَامَ الطَّالِبِ — the blackboard is in front of the student.)")

# ============ Lesson 4: Nominal sentences ============
add(4, "mcq", "What does الطَّالِبُ مَرِيضٌ mean?", "The student is sick",
    ["The student is sick", "The student is standing", "The teacher is sick", "The student went"],
    "Book: الطَّالِبُ مَرِيضٌ")
add(4, "mcq", "Which of these is a nominal sentence from the book?", "الدُّكَّانُ مَفْتُوحٌ",
    ["ذَهَبَ حَامِدٌ", "الدُّكَّانُ مَفْتُوحٌ", "خَرَجَ مُحَمَّدٌ", "أَيْنَ السَّاعَةُ؟"],
    "A nominal sentence starts with a noun: الدُّكَّانُ مَفْتُوحٌ (the shop is open)")
add(4, "fill_blank", "Fill in: ___ حُلْوٌ (The sugar is sweet).", "السُّكَّرُ",
    hint="Book: السُّكَّرُ حُلْوٌ")
add(4, "qa", "What are the two parts of a nominal sentence? Give one example from the book.",
    "A nominal sentence has a subject (مبتدأ) and a predicate (خبر). Example from the book: الرَّجُلُ وَاقِفٌ — الرَّجُلُ (the man) is the subject, وَاقِفٌ (standing) is the predicate.")

# ============ Lesson 5: Definite article ============
add(5, "mcq", "What does adding ال to a noun do?", 'Makes it definite ("the")',
    ['Makes it definite ("the")', "Makes it plural", "Makes it feminine", "Makes it a verb"],
    "بَيْتٌ (a house) → الْبَيْتُ (the house)")
add(5, "mcq", "بَيْتٌ means 'a house'. What does الْبَيْتُ mean?", "the house",
    ["the house", "a house", "houses", "my house"])
add(5, "fill_blank", "Write 'the mosque' in Arabic.", "الْمَسْجِدُ",
    hint="مَسْجِدٌ → الْمَسْجِدُ")
add(5, "qa", "The book writes النَّجْمُ بَعِيدٌ. Break it into ال + noun and translate.",
    "النَّجْمُ = ال + نَجْم (the star), بَعِيدٌ = far. Full meaning: The star is far.")

# ============ Lesson 6: Plurals ============
add(6, "mcq", "What is the plural of طَالِبٌ (student)?", "طُلَّابٌ",
    ["طُلَّابٌ", "طَالِبَانِ", "طَالِبَةٌ", "طَالِبُونَ"],
    "Book: الطُّلَّابُ فِي الْفَصْلِ (the students are in the classroom)")
add(6, "mcq", "مَنْ هَؤُلَاءِ الرِّجَالُ؟ هُمْ ضُيُوفٌ. What does هُمْ ضُيُوفٌ mean?",
    "They are guests",
    ["They are guests", "They are students", "We are guests", "They are farmers"])
add(6, "fill_blank", "Fill in the plural: أُمٌّ (mother) → ___ (mothers).", "أُمَّهَاتٌ",
    hint="Book: أُمٌّ → أُمَّهَاتٌ")
add(6, "qa", "Give three broken plurals from the book with their singular forms.",
    "طَالِبٌ → طُلَّابٌ (students), بَيْتٌ → بُيُوتٌ (houses), قَلَمٌ → أَقْلَامٌ (pens). Also: بَابٌ → أَبْوَابٌ, نَجْمٌ → نُجُومٌ, أَخٌ → إِخْوَةٌ.")

# ============ Lesson 7: Numbers ============
add(7, "mcq", "What does ثَلَاثُ طَالِبَاتٍ mean?", "three students (female)",
    ["three students (female)", "three students (male)", "thirty students", "the third student"],
    "Book: ثَلَاثُ طَالِبَاتٍ، أَرْبَعُ طَالِبَاتٍ، خَمْسُ طَالِبَاتٍ...")
add(7, "mcq", "لِي خَمْسَةُ إِخْوَةٍ وَسِتُّ أَخَوَاتٍ. What does it mean?",
    "I have five brothers and six sisters",
    ["I have five brothers and six sisters", "I have six brothers and five sisters", "He has five brothers", "My brother has six sisters"])
add(7, "fill_blank", "Fill in: فِي بَيْتِنَا ___ غُرَفٍ (In our house there are THREE rooms).", "ثَلَاثُ",
    hint="Book: فِي بَيْتِنَا ثَلَاثُ غُرَفٍ")
add(7, "qa", "The book writes لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ وَأَرْبَعُ بَنَاتٍ. Why ثَلَاثَةُ for sons but أَرْبَعُ for daughters?",
    "In Arabic, the numbers 3–10 take the OPPOSITE gender of the counted noun: أَبْنَاء (sons, masculine) → ثَلَاثَةُ (feminine form), بَنَات (daughters, feminine) → أَرْبَعُ (masculine form). Meaning: Khalid has three sons and four daughters.")

# ============ Lesson 8: Adjectives ============
add(8, "mcq", "الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ. What does it mean?",
    "The doctor is tall and the teacher is short",
    ["The doctor is tall and the teacher is short", "The doctor is short and the teacher is tall", "The doctor is sick", "The teacher is tall"])
add(8, "mcq", "Which word means 'new'?", "جَدِيدٌ",
    ["جَدِيدٌ", "قَدِيمٌ", "كَبِيرٌ", "جَمِيلٌ"],
    "Book: الدَّفْتَرُ جَدِيدٌ (the notebook is new), هَذَا طَالِبٌ جَدِيدٌ")
add(8, "fill_blank", "Fill in: السِّكِّينُ الْكَبِيرُ ___ جِدًّا (The big knife is very sharp).", "حَادٌّ",
    hint="Book: السِّكِّينُ الْكَبِيرُ حَادٌّ جِدًّا")
add(8, "qa", "In هَذَا طَالِبٌ جَدِيدٌ, why does جَدِيدٌ have no ال?",
    "The adjective matches the noun in definiteness: طَالِبٌ is indefinite (a student), so the adjective is also indefinite: جَدِيدٌ (new). Compare الطَّالِبُ الْجَدِيدُ (the new student) where both have ال.")

# ============ Lesson 9: Past tense ============
add(9, "mcq", "خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ. What does it mean?", "Muhammad left the house",
    ["Muhammad left the house", "Muhammad entered the house", "Amina left the house", "Muhammad is leaving"],
    "Book: خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ")
add(9, "mcq", "What is the feminine form of ذَهَبَ (he went)?", "ذَهَبَتْ",
    ["ذَهَبَتْ", "ذَهَبُوا", "ذَهَبْتَ", "يَذْهَبُ"],
    "Book: خَرَجَتْ آمِنَةُ مِنَ الْبَيْتِ (Amina left the house)")
add(9, "fill_blank", "Fill in: أَنْتَ ___ إِلَى الْمَدْرَسَةِ (YOU went to the school).", "ذَهَبْتَ",
    hint="Book: أَنْتَ ذَهَبْتَ إِلَى الْمَدْرَسَةِ")
add(9, "qa", "Conjugate خَرَجَ (to leave) for 'he' and 'she' with the book's example sentences.",
    "He: خَرَجَ — خَرَجَ مُحَمَّدٌ مِنَ الْبَيْتِ (Muhammad left the house). She: خَرَجَتْ — خَرَجَتْ آمِنَةُ مِنَ الْبَيْتِ (Amina left the house). The ة/ت marks the feminine.")

# ============ Lesson 10: Conjunctions ============
add(10, "mcq", "In الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ, what does وَ mean?", "and",
    ["and", "or", "but", "then"],
    "Book: الطَّبِيبُ طَوِيلٌ وَالْمُدَرِّسُ قَصِيرٌ")
add(10, "mcq", "الْفَلَّاحُونَ فِي الْحُقُولِ وَأَبْنَاؤُهُمْ فِي الْمَدْرَسَةِ. What does it mean?",
    "The farmers are in the fields and their sons are in the school",
    ["The farmers are in the fields and their sons are in the school", "The farmers and their sons are in the fields", "The farmers went to the school", "The sons are farmers"])
add(10, "fill_blank", "Fill in: لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ ___ أَرْبَعُ بَنَاتٍ (Khalid has three sons AND four daughters).", "وَ",
    hint="Book: لِخَالِدٍ ثَلَاثَةُ أَبْنَاءٍ وَأَرْبَعُ بَنَاتٍ")
add(10, "qa", "How is وَ attached to the following word in the book's examples?",
    "وَ is written attached to the next word with no space: وَالْمُدَرِّسُ, وَأَبْنَاؤُهُمْ, وَأَرْبَعُ. It means 'and' and joins two sentences or phrases, e.g. فِي الْمُسْتَشْفَى عَشْرُ طَبِيبَاتٍ وَأَرْبَعُ مُمَرِّضَاتٍ (in the hospital are ten female doctors and four nurses).")

print("done")
from apps.courses.models import Exercise as E
print("Total Madinah-1 exercises:", E.objects.filter(lesson__track=track, lesson__level=level, lesson__order__lte=10).count())
