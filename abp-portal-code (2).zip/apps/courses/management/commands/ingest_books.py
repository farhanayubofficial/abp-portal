"""Ingest the owner's curriculum books from docs/books-inbox/ into Book records.

Usage:
    python manage.py ingest_books                 # metadata only (fast)
    python manage.py ingest_books --extract-text  # also extract per-page text
    python manage.py ingest_books --extract-text --ocr --max-ocr-pages 20
"""
import shutil
from pathlib import Path

from django.conf import settings
from django.core.files import File
from django.core.management.base import BaseCommand

from apps.courses.models import Book, CourseTrack
from apps.courses.services import ingest_book_text

# (inbox relative path, title, author, publisher, language, track_code)
BOOKS = [
    ("quranic-arabic/Muallam-Al-Quran-01.pdf", "معلم القرآن — حصہ 1", "", "", "ur", "quranic-arabic"),
    ("quranic-arabic/Muallam-Al-Quran-02.pdf", "معلم القرآن — حصہ 2", "", "", "ur", "quranic-arabic"),
    ("quranic-arabic/Muallam-Al-Quran-03.pdf", "معلم القرآن — حصہ 3", "", "", "ur", "quranic-arabic"),
    ("quranic-arabic/Lisan-ul-Quran-Amir-Sohail.pdf", "لسان القرآن (جدید ایڈیشن)",
     "عامر سہیل", "لسان القرآن فاؤنڈیشن", "ur", "quranic-arabic"),
    ("quranic-arabic/Qurani-Arabi-Seekhiye-Level1-Shah-Mansoor.pdf",
     "قرآنی عربی سیکھیے — لیول 1", "مفتی ابو لبابہ شاہ منصور", "السعید", "ur", "quranic-arabic"),
    ("quranic-arabic/Qurani-Arabi-Seekhiye-Level2-3-Shah-Mansoor.pdf",
     "قرآنی عربی سیکھیے — لیول 2 و 3", "مفتی ابو لبابہ شاہ منصور", "السعید", "ur", "quranic-arabic"),
    ("quranic-arabic/Alfaz-ul-Quran-Shah-Mansoor.pdf", "الفاظ القرآن (قرآنی الفاظ سیکھیے)",
     "مفتی ابو لبابہ شاہ منصور", "السعید", "ur", "quranic-arabic"),
    ("arabic-language/Al-Qiraat-ar-Rashida-1-2.pdf", "القراءة الرشيدة — حصہ 1 و 2",
     "", "", "ar", "arabic-language"),
    ("arabic-language/Qasas-un-Nabiyeen-1-Nadwi.pdf", "قصص النبیین — حصہ 1",
     "ابو الحسن الندوی", "", "ar", "arabic-language"),
    ("arabic-language/Qasas-un-Nabiyeen-2-Nadwi.pdf", "قصص النبیین — حصہ 2",
     "ابو الحسن الندوی", "", "ar", "arabic-language"),
    ("arabic-language/Qasas-un-Nabiyeen-3-Nadwi.pdf", "قصص النبیین — حصہ 3",
     "ابو الحسن الندوی", "", "ar", "arabic-language"),
    ("arabic-language/Madinah-Arabic-Book-1-Abdur-Rahim.pdf",
     "دروس اللغة العربية — کتاب 1", "ڈاکٹر وی. عبدالرحیم", "", "ar", "arabic-language"),
    ("arabic-language/Madinah-Arabic-Book-2-Abdur-Rahim.pdf",
     "دروس اللغة العربية — کتاب 2", "ڈاکٹر وی. عبدالرحیم", "", "ar", "arabic-language"),
    ("arabic-language/Madinah-Arabic-Book-3-Abdur-Rahim.pdf",
     "دروس اللغة العربية — کتاب 3", "ڈاکٹر وی. عبدالرحیم", "", "ar", "arabic-language"),
]

INBOX = Path(settings.BASE_DIR) / "docs" / "books-inbox"


class Command(BaseCommand):
    help = "Ingest curriculum books from docs/books-inbox/"

    def add_arguments(self, parser):
        parser.add_argument("--extract-text", action="store_true",
                            help="Extract per-page text for each book")
        parser.add_argument("--ocr", action="store_true",
                            help="Run Tesseract OCR on pages without text")
        parser.add_argument("--max-ocr-pages", type=int, default=None,
                            help="Cap OCR pages per book (default: no cap)")

    def handle(self, *args, **opts):
        for rel, title, author, publisher, language, track_code in BOOKS:
            src = INBOX / rel
            if not src.exists():
                self.stdout.write(self.style.WARNING(f"SKIP (missing): {rel}"))
                continue
            track = CourseTrack.objects.filter(code=track_code).first()
            book, created = Book.objects.get_or_create(
                title=title,
                defaults={"author": author, "publisher": publisher,
                          "language": language, "track": track},
            )
            if created:
                with src.open("rb") as fh:
                    book.file.save(src.name, File(fh), save=True)
                self.stdout.write(self.style.SUCCESS(f"ADDED: {title}"))
            else:
                self.stdout.write(f"EXISTS: {title}")
            if opts["extract_text"]:
                ingest_book_text(book, ocr=opts["ocr"], max_ocr_pages=opts["max_ocr_pages"])
                n = book.pages_records.count()
                self.stdout.write(f"  -> {n} pages extracted (ocr={book.ocr_status})")
        self.stdout.write(self.style.SUCCESS("Done."))
