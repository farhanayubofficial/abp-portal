"""Book-faithful ENGLISH quizzes for Quranic Arabic Level 3.
Based on actual pages read from 'Qurani Arabi Seekhiye Level 2-3' (Shah Mansoor).
Level 3 = اعلیٰ قواعد (Advanced Grammar), 20 lessons.
"""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="quranic-arabic")
level = CourseLevel.objects.get(track=track, order=3)

TITLES = {
    1: "Lesson 1: Mufrad & Murakkab — Possessive and Adjective Phrases",
    2: "Lesson 2: Nominal (Ismiyyah) and Verbal (Fi'liyyah) Sentences",
    3: "Lesson 3: Masculine (Muzakkar) and Feminine (Muannas)",
    4: "Lesson 4: Sound Plural (Jam' Salim) and Broken Plural (Jam' Mukassar)",
    5: "Lesson 5: Definite (Ma'rifah) and Indefinite (Nakirah)",
    6: "Lesson 6: Intensive Noun (Mubalaghah) and Comparative Noun (Tafdeel)",
    7: "Lesson 7: Noun of Time/Place (Zarf) and Noun of Instrument (Aalah)",
    8: "Lesson 8: Four Types of Object (Maf'ool)",
    9: "Lesson 9: Haal (Circumstantial Accusative)",
    10: "Lesson 10: Tamyeez (Specification)",
    11: "Lesson 11: Near Past (Madi Qareeb with QAD)",
    12: "Lesson 12: Continuous Past (Madi Istimrari with KAANA)",
    13: "Lesson 13: Future Tense (Mudari' with SA / SAWFA)",
    14: "Lesson 14: Emphatic Mudari' (Khafeef & Saqeel with NOON)",
    15: "Lesson 15: Intransitive (Lazim) and Transitive (Muta'addi) Verbs",
    16: "Lesson 16: Deficient Verbs (Af'aal Naqisah — KAANA etc.)",
    17: "Lesson 17: Verbs of Proximity (Af'aal Muqarabah — KAADA)",
    18: "Lesson 18: Verbs of Praise and Blame (NI'MA, BI'SA)",
    19: "Lesson 19: Verbs of the Heart (Af'aal Quloob)",
    20: "Lesson 20: Quadrilateral Verbs (Fi'l Ruba'i)",
}

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kw = dict(lesson=lesson, order=n, question_type=qtype, question=question,
              options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer; kw["auto_grade"] = False; kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

for order, title in TITLES.items():
    lsn = Lesson.objects.get(track=track, level=level, order=order)
    lsn.title = title
    lsn.source_reference = "Qurani Arabi Seekhiye — Level 3 (Advanced Grammar), " + title
    lsn.save()
    Exercise.objects.filter(lesson=lsn).delete()

# ---- Lesson 1: Mufrad & Murakkab, Mudaf, Mausoof-Sifat ----
add(1, "mcq", "What is the meaning of بَیْتُ اللَّهِ?", "The house of Allah",
    ["The houses of Allah", "The house of Allah", "Allah's houses", "A house"],
    "Book example: Mudaf + Mudaf Ilaih")
add(1, "fill_blank", "Fill in: رَبُّ ___ = 'your Lord' (attached pronoun)", "کَ",
    hint="Book: رَبُّکَ — مخاطب کی ضمیر")
add(1, "mcq", "Which of these is a MURAKKAB (phrase)?", "رَبُّ الْعَالَمِینَ",
    ["رَبٌّ", "عَلَی", "رَبُّ الْعَالَمِینَ", "أَنْعَمْتَ"])
add(1, "qa", "Explain Mudaf + Mudaf Ilaih with a book example.",
    "Two words joined by possession: first word = Mudaf, second = Mudaf Ilaih. Example: بَیْتُ اللَّهِ (the house of Allah), دُعَاءُ الرَّسُولِ (the call of the Messenger).")

# ---- Lesson 2: Jumlah Ismiyyah & Fi'liyyah ----
add(2, "mcq", "اللَّهُ أَحَدٌ is which type of sentence?", "Jumlah Ismiyyah (nominal)",
    ["Jumlah Ismiyyah (nominal)", "Jumlah Fi'liyyah (verbal)", "Murakkab Naqis", "Idafah phrase"])
add(2, "fill_blank", "In a Jumlah Ismiyyah, the two parts are Mubtada and ___", "Khabar",
    hint="Subject and predicate")
add(2, "mcq", "صَدَقَ اللَّهُ is a Jumlah Fi'liyyah because it starts with:", "A verb (Fi'l)",
    ["A noun", "A verb (Fi'l)", "A particle", "A pronoun"])
add(2, "qa", "What are the parts of خَلَقَ اللَّهُ السَّمَاوَاتِ?",
    "Fi'l (خَلَقَ - created) + Fa'il (اللَّهُ - Allah) + Maf'ool (السَّمَاوَاتِ - the heavens). This is a Jumlah Fi'liyyah.")

# ---- Lesson 3: Muzakkar & Muannas ----
add(3, "mcq", "Which word is MUANNAS (feminine)?", "جَنَّۃٌ",
    ["زَیْدٌ", "کِتَابٌ", "جَنَّۃٌ", "قَلَمٌ"], "Look for the feminine sign")
add(3, "fill_blank", "The feminine of مُسْلِم is ___", "مُسْلِمَۃٌ",
    hint="Add ة at the end")
add(3, "mcq", "بُشْرَی is feminine because of:", "Alif Maqsoorah (ی)",
    ["Round ta (ۃ)", "Alif Maqsoorah (ی)", "Alif Mamdoodah (اء)", "No sign — it is masculine"])
add(3, "qa", "Name the three signs of feminine (Muannas) with one example each.",
    "1. Round ta (ۃ): مُسْلِمَۃٌ. 2. Alif Maqsoorah (ی): بُشْرَی. 3. Alif Mamdoodah (اء): حَمْرَاءُ.")

# ---- Lesson 4: Jam' Salim & Mukassar ----
add(4, "mcq", "مُسْلِمُونَ is which type of plural?", "Jam' Salim (sound plural)",
    ["Jam' Salim (sound plural)", "Jam' Mukassar (broken plural)", "Tasniyah", "Mufrad"])
add(4, "fill_blank", "The broken plural of کِتَاب is ___", "کُتُب",
    hint="Book example: the singular pattern is broken")
add(4, "mcq", "Which pair shows Jam' Mukassar?", "قَلْب → قُلُوب",
    ["مُسْلِم → مُسْلِمُونَ", "مُفْلِح → مُفْلِحُونَ", "قَلْب → قُلُوب", "کَاتِب → کَاتِبُونَ"])
add(4, "qa", "What is the difference between Jam' Salim and Jam' Mukassar?",
    "In Jam' Salim the singular pattern stays intact (مُسْلِم → مُسْلِمُونَ). In Jam' Mukassar the singular pattern is broken (کِتَاب → کُتُب، قَلْب → قُلُوب).")

# ---- Lesson 5: Ma'rifah & Nakirah ----
add(5, "mcq", "Which word is MA'RIFAH (definite)?", "اَلْکِتَاب",
    ["کِتَاب", "اَلْکِتَاب", "قَلَم", "بَیْت"], "Definite = specific")
add(5, "fill_blank", "Add ___ at the start of کِتَاب to make it definite", "اَلْ",
    hint="The definite article")
add(5, "mcq", "مَکَّۃ is Ma'rifah because it is:", "A specific place name",
    ["Has ال", "A specific place name", "A pronoun", "A verb"])
add(5, "qa", "How does a Nakirah become a Ma'rifah? Give an example.",
    "By adding ال at the beginning: کِتَاب (a book, Nakirah) → اَلْکِتَاب (the book, Ma'rifah).")

# ---- Lesson 6: Ism Mubalaghah & Tafdeel ----
add(6, "mcq", "What does اَکْبَر mean?", "The biggest / greater",
    ["Big", "The biggest / greater", "Bigness", "To enlarge"])
add(6, "fill_blank", "اَرْحَم means 'more ___ than all the merciful'", "merciful",
    hint="Book: تمام رحم والوں سے زیادہ رحم کرنے والا")
add(6, "mcq", "Ism Tafdeel is made on which pattern?", "أَفْعَل",
    ["فَاعِل", "مَفْعُول", "أَفْعَل", "فَعِیل"])
add(6, "qa", "What is Ism Tafdeel? Give two book examples.",
    "A noun showing one thing has more of a quality than another (comparative/superlative), on the pattern أَفْعَل. Examples: اَکْبَر (biggest), اَحْسَن (best/most excellent).")

# ---- Lesson 7: Ism Zarf & Ism Aalah ----
add(7, "mcq", "Ism Zarf is a word used for:", "A place or time",
    ["An instrument", "A place or time", "A person", "An action"])
add(7, "fill_blank", "Ism ___ is the word used for an instrument", "Aalah",
    hint="آلہ = tool/instrument")
add(7, "mcq", "Which is an Ism Aalah?", "مِفْتَاح (key)",
    ["مَسْجِد (mosque)", "مِفْتَاح (key)", "کِتَاب (book)", "قَلَم (pen) — actually also an instrument!"],
    "Think: which is a tool?")
add(7, "qa", "Define Ism Zarf and Ism Aalah.",
    "Ism Zarf: a word used for a place or time (e.g., مَسْجِد — place of prostration). Ism Aalah: a word used for an instrument/tool (e.g., مِفْتَاح — key).")

# ---- Lesson 8: Four types of Maf'ool ----
add(8, "mcq", "How many types of Maf'ool does the book teach?", "Four",
    ["Two", "Three", "Four", "Five"])
add(8, "fill_blank", "Maf'ool ___ is the object on which the action falls (e.g., السَّمَاوَاتِ in خَلَقَ اللَّهُ السَّمَاوَاتِ)", "bihi (بہ)",
    hint="The direct object")
add(8, "mcq", "In رَتِّلِ الْقُرْآنَ تَرْتِیلًا, تَرْتِیلًا is:", "Maf'ool Mutlaq (absolute object for emphasis)",
    ["Maf'ool bihi", "Maf'ool feehi", "Maf'ool Mutlaq (absolute object for emphasis)", "Haal"])
add(8, "qa", "Name the four types of Maf'ool with their meanings.",
    "1. Maf'ool bihi — the thing the action falls on. 2. Maf'ool feehi — the time/place of the action. 3. Maf'ool lahu — the reason for the action. 4. Maf'ool mutlaq — the verbal noun for emphasis (e.g., تَرْتِیلًا).")

# ---- Lesson 9: Haal ----
add(9, "mcq", "What does HAAL describe?", "The state of the doer or the object",
    ["The time of action", "The state of the doer or the object", "The reason for action", "The place of action"])
add(9, "fill_blank", "In قُومُوا لِلَّهِ قَانِتِینَ, the word قَانِتِینَ is the ___", "Haal",
    hint="It describes the state: 'obediently'")
add(9, "mcq", "Haal is usually in which grammatical state?", "Nasb (accusative)",
    ["Raf' (nominative)", "Nasb (accusative)", "Jarr (genitive)", "Jazm"])
add(9, "qa", "Define Haal with the book's example.",
    "Haal is the word that describes the state of the Fa'il or Maf'ool at the time of the action. Example: قُومُوا لِلَّهِ قَانِتِینَ — 'Stand for Allah in a state of obedience'; قَانِتِینَ is the Haal.")

# ---- Lesson 10: Tamyeez ----
add(10, "mcq", "What does TAMYEEZ do?", "Removes ambiguity (وضح)",
    ["Shows time", "Removes ambiguity (وضح)", "Shows emphasis", "Joins sentences"])
add(10, "fill_blank", "In رَأَیْتُ أَحَدَ عَشَرَ کَوْکَبًا, the Tamyeez is ___", "کَوْکَبًا",
    hint="It clarifies 'eleven what?'")
add(10, "mcq", "Tamyeez commonly clarifies ambiguity of:", "Number, quantity, or manner",
    ["Only verbs", "Number, quantity, or manner", "Only pronouns", "Only prepositions"])
add(10, "qa", "Explain Tamyeez with the book's example رَأَیْتُ أَحَدَ عَشَرَ کَوْکَبًا.",
    "'I saw eleven...' — eleven what? The word کَوْکَبًا (stars) removes the ambiguity of the number. Tamyeez clarifies ambiguity of number (عدد), quantity (مقدار), or manner (کیفیت).")

# ---- Lesson 11: Madi Qareeb (QAD) ----
add(11, "mcq", "What does قَدْ before a past verb mean?", "Certainly / surely",
    ["Maybe", "Certainly / surely", "Never", "If"])
add(11, "fill_blank", "قَدْ أَفْلَحَ الْمُؤْمِنُونَ means '___ the believers have succeeded'", "Certainly",
    hint="Book: یقیناً، ضرور")
add(11, "mcq", "How many times does قَدْ come in the Quran (per the book)?", "122",
    ["12", "122", "1220", "22"])
add(11, "qa", "What is Madi Qareeb? Give an example.",
    "The past tense with قَدْ before it, giving certainty: قَدْ ضَرَبَ = 'he certainly struck'. Example: قَدْ أَفْلَحَ الْمُؤْمِنُونَ — 'Certainly the believers have succeeded'.")

# ---- Lesson 12: Madi Istimrari (KAANA) ----
add(12, "mcq", "کَانَ یَفْعَلُ means:", "He used to do / was doing",
    ["He will do", "He used to do / was doing", "He did once", "Do!"])
add(12, "fill_blank", "کَانَ + ___ gives the continuous past meaning", "یَفْعَلُ (mudari')",
    hint="Kaana + present-tense verb")
add(12, "mcq", "Which gives 'he was writing'?", "کَانَ یَکْتُبُ",
    ["قَدْ کَتَبَ", "کَانَ یَکْتُبُ", "سَیَکْتُبُ", "اُکْتُبْ"])
add(12, "qa", "How is the continuous past (Madi Istimrari) formed?",
    "By putting کَانَ before the mudari' verb: کَانَ یَفْعَلُ = 'he used to do / was doing'. It describes a repeated or ongoing action in the past.")

# ---- Lesson 13: Future (SA / SAWFA) ----
add(13, "mcq", "سَیَفْعَلُ means:", "He will do (near future)",
    ["He did", "He is doing", "He will do (near future)", "He would do"])
add(13, "fill_blank", "سَوْفَ is used for the ___ future", "distant",
    hint="سَ = near, سَوْفَ = far")
add(13, "mcq", "Which is the near-future marker?", "سَ",
    ["سَ", "سَوْفَ", "قَدْ", "لَنْ"])
add(13, "qa", "What is the difference between سَ and سَوْفَ?",
    "Both make the mudari' future. سَ is for the near future (سَیَفْعَلُ = he will do soon), سَوْفَ for the distant future (سَوْفَ یَفْعَلُ = he will do later).")

# ---- Lesson 14: Khafeef & Saqeel ----
add(14, "mcq", "لَیَفْعَلَنَّ shows:", "Strong emphasis (he will SURELY do)",
    ["Past tense", "Strong emphasis (he will SURELY do)", "Prohibition", "Question"])
add(14, "fill_blank", "The heavy noon (نَّ) at the end gives ___ emphasis", "strong (saqeel)",
    hint="ثقیل = heavy")
add(14, "mcq", "Khafeef (light) emphasis uses which noon?", "نْ (single, light)",
    ["نَّ (doubled, heavy)", "نْ (single, light)", "No noon", "Two noons"])
add(14, "qa", "Explain the emphatic mudari' (Khafeef and Saqeel).",
    "Adding لَ + ن at the end of the mudari' gives strong emphasis. Khafeef (light): لَیَفْعَلَنْ with single نْ. Saqeel (heavy): لَیَفْعَلَنَّ with doubled نَّ — 'he will surely do'.")

# ---- Lesson 15: Lazim & Muta'addi ----
add(15, "mcq", "Fi'l Lazim is a verb that:", "Needs only a doer (Fa'il)",
    ["Needs doer + object", "Needs only a doer (Fa'il)", "Needs two objects", "Has no doer"])
add(15, "fill_blank", "نَزَلَ (he descended) is Fi'l ___", "Lazim",
    hint="Book example: needs only a Fa'il")
add(15, "mcq", "أَنْزَلَ (he sent down) is Muta'addi because:", "It needs an object too",
    ["It has no object", "It needs an object too", "It is past tense", "It is feminine"])
add(15, "qa", "Define Fi'l Lazim and Fi'l Muta'addi with examples.",
    "Lazim: needs only a Fa'il, e.g., نَزَلَ (he descended). Muta'addi: needs Fa'il + Maf'ool, e.g., أَنْزَلَ (he sent down [something]).")

# ---- Lesson 16: Af'aal Naqisah ----
add(16, "mcq", "How many Af'aal Naqisah are there (per the book)?", "17",
    ["7", "11", "17", "10"])
add(16, "fill_blank", "The most famous Naqis verb is ___", "کَانَ",
    hint="Means 'was'")
add(16, "mcq", "Why are they called 'Naqisah' (deficient)?", "They need a subject AND a predicate to complete meaning",
    ["They have no meaning", "They need a subject AND a predicate to complete meaning", "They are always past", "They have no doer"])
add(16, "qa", "Name five Af'aal Naqisah with meanings.",
    "کَانَ (was), ظَلَّ (became/remained), بَاتَ (spent the night), أَصْبَحَ (became morning), أَمْسَی (became evening), لَیْسَ (is not). The book says 17 exist, 11 come in the Quran, 1533 times.")

# ---- Lesson 17: Af'aal Muqarabah ----
add(17, "mcq", "کَادَ means:", "He was near (to doing)",
    ["He did", "He was near (to doing)", "He hoped", "He began"])
add(17, "fill_blank", "عَسَی gives the meaning of ___", "hope (امید ہے)",
    hint="Book: امید ہے")
add(17, "mcq", "How many Af'aal Muqarabah come in the Quran?", "3",
    ["10", "7", "3", "17"])
add(17, "qa", "What are Af'aal Muqarabah? Name the three in the Quran.",
    "Verbs showing nearness to an action, hope, or beginning. Three come in the Quran (57 times): کَادَ (he was near), عَسَی (it is hoped), طَفِقَ (he began).")

# ---- Lesson 18: Madh & Zamm ----
add(18, "mcq", "نِعْمَ is used for:", "Praise (مدح)",
    ["Blame (ذم)", "Praise (مدح)", "Hope", "Prohibition"])
add(18, "fill_blank", "بِئْسَ means 'how ___' (used for blame)", "evil",
    hint="Opposite of نِعْمَ")
add(18, "mcq", "نِعْمَ الْمَوْلَی وَنِعْمَ النَّصِیرُ means:", "How excellent the Protector and how excellent the Helper",
    ["How evil the protector", "How excellent the Protector and how excellent the Helper", "The protector helped", "Allah is one"])
add(18, "qa", "Name the four Af'aal of Madh and Zamm.",
    "For praise (مدح): نِعْمَ (how excellent). For blame (ذم): بِئْسَ (how evil), سَاءَ (how evil). The book says 4 verbs, coming 79 times in the Quran.")

# ---- Lesson 19: Af'aal Quloob ----
add(19, "mcq", "Af'aal Quloob are verbs of:", "The heart — certainty and doubt",
    ["The hands", "The heart — certainty and doubt", "The feet", "The eyes"])
add(19, "fill_blank", "عَلِمَ (he knew) is a verb of ___", "certainty (یقین)",
    hint="484 times in the Quran")
add(19, "mcq", "Which verb is for DOUBT (شک)?", "ظَنَّ",
    ["عَلِمَ", "ظَنَّ", "وَجَدَ", "رَأَی"])
add(19, "qa", "Name the Af'aal Quloob for certainty and doubt.",
    "Certainty (یقین): عَلِمَ (knew), وَجَدَ (found), رَأَی (saw). Doubt (شک): حَسِبَ (thought), ظَنَّ (assumed). One verb (زَعَمَ) is used for both. 7 verbs, 864 times in the Quran.")

# ---- Lesson 20: Fi'l Ruba'i ----
add(20, "mcq", "A Ruba'i verb has how many root letters?", "Four",
    ["Three", "Four", "Five", "Two"])
add(20, "fill_blank", "The pattern of the Ruba'i verb is ___", "فَعْلَلَ",
    hint="Like فَعَلَ but with 4 letters")
add(20, "mcq", "Which is a Ruba'i verb?", "زَلْزَلَ",
    ["ضَرَبَ", "زَلْزَلَ", "کَتَبَ", "فَتَحَ"])
add(20, "qa", "How many Ruba'i verbs come in the Quran? Name them.",
    "Five verbs, 13 times: زَحْزَحَ (moved away), عَسْعَسَ (covered), دَمْدَمَ (destroyed), وَسْوَسَ (whispered), زَلْزَلَ (shook). Pattern: فَعْلَلَ.")

print("done")
