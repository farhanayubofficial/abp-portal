"""Book-faithful ENGLISH quizzes for Qasas al-Nabiyyin Part 2 (Nadwi).
Based on actual pages read visually: Nuh (pp.8-38), Hud (pp.39-54), Salih (pp.55-68).
Lesson slots 11-15, Level 2, arabic-language track."""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=2)

TITLES = {
    11: "Qasas 2: Nuh (AS) \u2014 The Call to His People",
    12: "Qasas 2: Nuh (AS) \u2014 The Ark and the Flood",
    13: "Qasas 2: Hud (AS) \u2014 The People of \u2018Ad",
    14: "Qasas 2: Salih (AS) \u2014 The People of Thamud",
    15: "Qasas 2: Review \u2014 Nuh, Hud and Salih",
}

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kw = dict(lesson=lesson, order=n, question_type=qtype,
              question=question, options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer
        kw["auto_grade"] = False
        kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

for order, title in TITLES.items():
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    lesson.title = title
    lesson.source_reference = "Qasas al-Nabiyyin Part 2 (Nadwi) \u2014 from the actual book"
    lesson.save()
    n, _ = Exercise.objects.filter(lesson=lesson).delete()
    print(f"{title}: {n} old deleted")

# ============ Lesson 11: Nuh (AS) \u2014 The Call ============
add(11, "mcq",
    "According to the book, how did idol worship begin among Nuh's people?",
    "Satan suggested making images of righteous men, which later became idols",
    ["People always worshipped idols",
     "Satan suggested making images of righteous men, which later became idols",
     "Nuh himself told them to make idols",
     "The idols fell from the sky"],
    "Read the sections \u062d\u0633\u062f \u0627\u0644\u0634\u064a\u0637\u0627\u0646 and \u0641\u0643\u0631\u0629 \u0627\u0644\u0634\u064a\u0637\u0627\u0646")
add(11, "fill",
    "Fill in the blank: Allah sent Nuh as a messenger to his ___ (people).",
    "people",
    hint="The book says: \u0623\u0646 \u064a\u064f\u0631\u0633\u0644 \u0646\u0648\u062d\u064b\u0627 \u0625\u0644\u0649 \u0642\u0648\u0645\u0647")
add(11, "mcq",
    "What did Nuh call his people to?",
    "To worship Allah alone",
    ["To worship Allah alone",
     "To build more idols",
     "To leave their city",
     "To fight the neighboring tribe"])
add(11, "qa",
    "The book says there were rich and leading men among Nuh's people, yet Allah chose Nuh. What does this teach?",
    "Allah chooses whom He wills for His message \u2014 not the richest or most powerful. The book says: \u0643\u0627\u0646 \u0641\u064a \u0627\u0644\u0642\u0648\u0645 \u0623\u063a\u0646\u064a\u0627\u0621 \u0648\u0631\u0624\u0633\u0627\u0621\u060c \u0648\u0644\u0643\u0646 \u0627\u0644\u0644\u0647 \u0627\u062e\u062a\u0627\u0631 \u0646\u0648\u062d\u064b\u0627 \u0644\u0631\u0633\u0627\u0644\u062a\u0647 (there were rich men and leaders, but Allah chose Nuh for His message).")

# ============ Lesson 12: Nuh (AS) \u2014 The Ark and the Flood ============
add(12, "mcq",
    "What did Allah command Nuh to take with him into the Ark (\u0627\u0644\u0633\u0641\u064a\u0646\u0629)?",
    "The believers, his family, and a male-and-female pair of every animal and bird",
    ["Only his family",
     "The believers, his family, and a male-and-female pair of every animal and bird",
     "Gold and treasure",
     "Only the animals"])
add(12, "fill",
    "Fill in the blank: After the Flood, the Ark rested on Mount ___ .",
    "Judi",
    hint="\u0648\u0627\u0633\u062a\u0648\u062a \u0627\u0644\u0633\u0641\u064a\u0646\u0629 \u0639\u0644\u0649 \u062c\u0628\u0644 \u0627\u0644\u062c\u0648\u062f\u064a")
add(12, "mcq",
    "The book says the Ark sailed \u201cin waves like ___ \u201d.",
    "mountains",
    ["mountains", "hills", "clouds", "rivers"],
    hint="\u0641\u064a \u0645\u0648\u062c \u0643\u0627\u0644\u062c\u0628\u0627\u0644")
add(12, "qa",
    "What dua did Nuh make after the Flood, as quoted in the book?",
    "Model answer: \u0631\u0628 \u0625\u0646\u064a \u0623\u0639\u0648\u0630 \u0628\u0643 \u0623\u0646 \u0623\u0633\u0623\u0644\u0643 \u0645\u0627 \u0644\u064a\u0633 \u0644\u064a \u0628\u0647 \u0639\u0644\u0645 \u0648\u0625\u0644\u0627 \u062a\u063a\u0641\u0631 \u0644\u064a \u0648\u062a\u0631\u062d\u0645\u0646\u064a \u0623\u0643\u0646 \u0645\u0646 \u0627\u0644\u062e\u0627\u0633\u0631\u064a\u0646 \u2014 \u201cMy Lord, I seek refuge in You from asking You about what I have no knowledge of; if You do not forgive me and have mercy on me, I will be among the losers.\u201d")

# ============ Lesson 13: Hud (AS) \u2014 People of 'Ad ============
add(13, "mcq",
    "To which people was Hud (AS) sent?",
    "\u2018Ad (\u0639\u0627\u062f)",
    ["Thamud (\u062b\u0645\u0648\u062f)", "\u2018Ad (\u0639\u0627\u062f)", "Madyan (\u0645\u062f\u064a\u0646)", "Banu Isra\u2019il"])
add(13, "fill",
    "Fill in the blank: Hud said to his people, \u201cI am your ___ and your friend.\u201d",
    "brother",
    hint="\u064a\u0627 \u0642\u0648\u0645 \u0623\u0646\u0627 \u0623\u062e\u0648\u0643\u0645 \u0648\u0635\u062f\u064a\u0642\u0643\u0645")
add(13, "mcq",
    "How did the people of \u2018Ad look after their punishment, according to the book?",
    "Like fallen palm trunks; birds ate the dead and owls lived in the ruined houses",
    ["Like fallen palm trunks; birds ate the dead and owls lived in the ruined houses",
     "They turned into stone statues",
     "They were swallowed by the sea",
     "They simply disappeared"])
add(13, "qa",
    "What did Hud say when his people accused him of wanting their wealth?",
    "Model answer: \u064a\u0627 \u0642\u0648\u0645 \u0644\u0627 \u0623\u0633\u0623\u0644\u0643\u0645 \u0639\u0644\u064a\u0647 \u0645\u0627\u0644\u064b\u0627 \u0625\u0646 \u0623\u062c\u0631\u064a \u0625\u0644\u0627 \u0639\u0644\u0649 \u0627\u0644\u0644\u0647 \u2014 \u201cO my people, I do not ask you for any wealth for this; my reward is only from Allah.\u201d He also promised that belief would bring blessing in provision and strength.")

# ============ Lesson 14: Salih (AS) \u2014 People of Thamud ============
add(14, "mcq",
    "What did Salih remind his people about their palaces, gardens and rivers?",
    "They will not last forever \u2014 their forefathers died though they had palaces too",
    ["They will not last forever \u2014 their forefathers died though they had palaces too",
     "They should build even bigger palaces",
     "The gardens belong to him",
     "They should worship the rivers"])
add(14, "fill",
    "Fill in the blank: The people of Thamud killed the ___ (she-camel), the sign of Salih.",
    "she-camel",
    hint="\u0627\u0644\u0646\u0627\u0642\u0629")
add(14, "mcq",
    "How did Salih call his people to Allah, according to the book?",
    "With wisdom and gentleness",
    ["With wisdom and gentleness", "With harsh threats only", "With an army", "He did not call them at all"],
    hint="\u0628\u062d\u0643\u0645\u0629 \u0648\u0631\u0641\u0642")
add(14, "qa",
    "Salih asked his people several \u201cDo you think...?\u201d questions. Mention two of them.",
    "Model answer: \u0623\u062a\u0638\u0646\u0648\u0646 \u0623\u0646\u0643\u0645 \u0647\u0646\u0627 \u0625\u0644\u0649 \u0627\u0644\u0623\u0628\u062f\u061f (\u201cDo you think you are here forever?\u201d) and \u0623\u062a\u0638\u0646\u0648\u0646 \u0623\u0646\u0643\u0645 \u062a\u0633\u0643\u0646\u0648\u0646 \u0641\u064a \u0647\u0630\u0647 \u0627\u0644\u0642\u0635\u0648\u0631 \u062f\u0627\u0626\u0645\u064b\u0627\u061f (\u201cDo you think you will live in these palaces forever?\u201d) \u2014 also about gardens, rivers, crops, and houses carved from mountains.")

# ============ Lesson 15: Review ============
add(15, "mcq",
    "Which three prophets\u2019 stories are told in Qasas al-Nabiyyin Part 2?",
    "Nuh, Hud and Salih",
    ["Nuh, Hud and Salih", "Yusuf, Musa and Shuayb", "Ibrahim, Isma\u2018il and Ishaq", "Adam, Idris and Nuh"])
add(15, "fill",
    "Fill in the blank (Quranic verse quoted in the book): \u201c\u0623\u0644\u0627 \u0625\u0646 \u0639\u0627\u062f\u064b\u0627 \u0643\u0641\u0631\u0648\u0627 \u0631\u0628\u0647\u0645\u060c \u0623\u0644\u0627 \u0628\u0639\u062f\u064b\u0627 \u0644\u0639\u0627\u062f \u0642\u0648\u0645 ___\u201d",
    "Hud",
    hint="The people of \u2018Ad \u2014 \u0642\u0648\u0645 \u0647\u0648\u062f")
add(15, "mcq",
    "Where did the disbelievers try to escape when the Flood came?",
    "They climbed every high place and hill",
    ["They climbed every high place and hill", "They hid in caves", "They built another ark", "They fled to Egypt"])
add(15, "qa",
    "What is the common lesson from the stories of Nuh, Hud and Salih in this book?",
    "Model answer: In each story, the prophet called his people to worship Allah alone with wisdom and gentleness; those who believed were saved, and those who persisted in disbelief and arrogance perished \u2014 \u0648\u0646\u062c\u0627 ... \u0628\u0625\u064a\u0645\u0627\u0646\u0647\u0645\u060c \u0648\u0647\u0644\u0643\u062a ... \u0628\u0643\u0641\u0631\u0647\u0627 (saved by their faith, destroyed by their disbelief).")

print("done")
from apps.courses.models import Exercise as E
print("Total Qasas2 exercises:", E.objects.filter(lesson__track=track, lesson__level=level, lesson__order__gte=11).count())
