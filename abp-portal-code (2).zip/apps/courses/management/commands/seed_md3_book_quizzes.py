"""Book-faithful quizzes for Madinah Book 3 - from actual book pages read visually.
All in English. Arabic terms kept in Arabic script."""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=3)

TITLES = {
    1: "Madinah 3: The Five Verbs (الأفعال الخمسة)",
    2: "Madinah 3: Inflection of the Present Tense",
    3: "Madinah 3: Declinable and Indeclinable (المعرب والمبني)",
    4: "Madinah 3: The Followers (التوابع)",
    5: "Madinah 3: Diptotes (الممنوع من الصرف)",
    6: "Madinah 3: Numbers and Counted Nouns",
    7: "Madinah 3: Conditional Sentences",
    8: "Madinah 3: Relative Pronouns",
    9: "Madinah 3: The Interpreted Infinitive (المصدر المؤول)",
    10: "Madinah 3: Dialogue Practice",
}

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kw = dict(lesson=lesson, order=n, question_type=qtype,
              question=question, options=options or [], explanation=hint)
    if qtype == "qa":
        kw["model_answer"] = answer; kw["auto_grade"] = False; kw["correct_answer"] = ""
    else:
        kw["correct_answer"] = answer
    Exercise.objects.create(**kw)

# Clear old + set titles
for order, title in TITLES.items():
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    lesson.title = title
    lesson.source_reference = "Duroos al-Lughah al-Arabiyah Book 3 — Dr. V. Abdur Rahim"
    lesson.save()
    Exercise.objects.filter(lesson=lesson).delete()
print("cleared, titles set")

# ===== Lesson 1: The Five Verbs (p.18: ثبوت النون / حذف النون) =====
add(1, "mcq", "In the five verbs (الأفعال الخمسة), what is the sign of raf' (nominative)?",
    "The nūn is retained (ثبوت النون)",
    ["The nūn is retained (ثبوت النون)", "The nūn is dropped (حذف النون)", "A ḍammah appears", "A fatḥah appears"],
    "Book: علامة الرفع فيها ثبوت النون")
add(1, "fill_blank", "Complete the book's example: أَتُرِيدُونَ أَنْ ___؟ (Do you all want to go?)", "تَذْهَبُوا",
    "Book p.18: أن + five-verb → nūn dropped")
add(1, "mcq", "In the book's example «أَمْ تَذْهَبْنَ إِلَى الْمَدْرَسَةِ يَا مَرْيَمُ؟», why is the nūn kept in تَذْهَبْنَ?",
    "It is the feminine plural nūn (نُون النسوة), not the inflectional nūn",
    ["It is the feminine plural nūn (نُون النسوة), not the inflectional nūn", "Because it is marfū'", "Because of أم", "It is a mistake in the book"])
add(1, "qa", "What are the five verbs (الأفعال الخمسة), and what are their signs of inflection?",
    "The five verbs are the present-tense forms attached to: ألف الاثنين (e.g. يَذْهَبَانِ)، واو الجماعة (يَذْهَبُونَ)، ياء المخاطبة (تَذْهَبِينَ). Sign of raf': retention of nūn (ثبوت النون). Signs of naṣb and jazm: dropping the nūn (حذف النون).")

# ===== Lesson 2: Present-tense inflection (p.18) =====
add(2, "mcq", "What are the three original signs of inflection (علامات الإعراب الأصلية) for the present-tense verb?",
    "Ḍammah for raf', fatḥah for naṣb, sukūn for jazm",
    ["Ḍammah for raf', fatḥah for naṣb, sukūn for jazm", "Wāw, alif, yā'", "Nūn for all cases", "Fatḥah for raf', ḍammah for naṣb"])
add(2, "fill_blank", "In the book's example «لَمْ يَمْشِ», the sign of jazm is ___ (the last letter is dropped).", "حَذْفُ الْآخِر",
    "Book: الفعل الناقص — علامة الجزم فيه حذف آخره")
add(2, "mcq", "The book gives «لَمْ يَدْعُ» and «لَمْ يَنْسَ» as examples of:",
    "The defective verb (الفعل الناقص) — jazm by dropping the final weak letter",
    ["The sound verb — jazm by sukūn", "The defective verb (الفعل الناقص) — jazm by dropping the final weak letter", "The five verbs", "The passive verb"])
add(2, "qa", "Explain the book's three examples of the defective verb in jazm: لَمْ يَمْشِ، لَمْ يَدْعُ، لَمْ يَنْسَ.",
    "These are defective verbs (آخرها حرف علة). In jazm, the sign is dropping the final weak letter: يَمْشِي → لَمْ يَمْشِ، يَدْعُو → لَمْ يَدْعُ، يَنْسَى → لَمْ يَنْسَ.")

# ===== Lesson 3: Declinable and Indeclinable (p.6, 8-9) =====
add(3, "mcq", "According to the book, which of these is معرب (declinable)?",
    "هذان (dual of هذا)",
    ["هذا", "هذان (dual of هذا)", "الذي", "أَيْنَ"],
    "Book: «هذان» وهاتان معربان — the rest are مبني")
add(3, "fill_blank", "The book defines المقصور as the declinable noun ending in a fixed alif, e.g. ___ (the hospital).", "الْمُسْتَشْفَى",
    "Book p.9: نحو المستشفى، الفتى، العصا")
add(3, "mcq", "In the book's example «قَتَلَ الْفَتَى الْأَفْعَى بِالْعَصَا», why does الفتى not show its case endings?",
    "It is مقصور — all three case signs are assumed (مقدرة)",
    ["It is مبني", "It is مقصور — all three case signs are assumed (مقدرة)", "It is منقوص", "It has no case"])
add(3, "qa", "The book lists seven groups of indeclinable (مبني) words. Name them with one example each.",
    "1. Accusative pronouns: رَأَيْتُهُ 2. Genitive pronouns: كِتَابُهُ 3. Demonstratives: هٰذَا 4. Relative pronouns: اَلَّذِي 5. Interrogatives: مَنْ 6. Some adverbs: أَمْسِ 7. Compound numbers: أَحَدَ عَشَرَ. (Book p.6)")

# ===== Lesson 4: The Followers — التوابع =====
add(4, "mcq", "The followers (التوابع) are four. Which is NOT one of them?",
    "الحال (the circumstantial accusative)",
    ["النعت (adjective)", "العطف (conjunction)", "البدل (apposition)", "الحال (the circumstantial accusative)"],
    "Book: التوابع أربعة — النعت، العطف، البدل، التوكيد")
add(4, "fill_blank", "The follower takes the same ___ as the word it follows.", "case (إعراب)",
    "التابع يتبع المتبوع في الإعراب")
add(4, "mcq", "In «جَاءَ الطَّالِبُ الْمُجْتَهِدُ», الْمُجْتَهِدُ is:",
    "نعت (adjective) — marfū' like الطالب",
    ["نعت (adjective) — marfū' like الطالب", "حال — manṣūb", "بدل — majrūr", "توكيد"])
add(4, "qa", "Define each of the four followers with a short example.",
    "النعت (adjective): جاء الطالب المجتهد — describes. العطف (conjunction): جاء محمد وخالد — joined by a particle. البدل (apposition): قرأت الكتاب نصفه — substitutes. التوكيد (emphasis): جاء الطلاب كلهم — emphasizes. Each follows its noun in case.")

# ===== Lesson 5: Diptotes (p.292) =====
add(5, "mcq", "The book gives قَنَادِيل، قَرَاطِيس، عَصَافِير، فَنَاجِين as examples of:",
    "صيغ منتهى الجموع (patterns of ultimate plurals) — diptotes",
    ["صيغ منتهى الجموع (patterns of ultimate plurals) — diptotes", "Sound plurals", "Dual forms", "Diminutives"])
add(5, "fill_blank", "مَسْجِدٌ → ___ (the book's example of شبه فعالل).", "مَسَاجِدُ",
    "Book p.292: مسجد → مساجد")
add(5, "mcq", "مِفْتَاحٌ → مَفَاتِيحُ is an example of which pattern?",
    "شبه فعاليل",
    ["فعالل", "شبه فعالل", "شبه فعاليل", "فعول"])
add(5, "qa", "What is الممنوع من الصرف, and how does the book illustrate it with broken plurals?",
    "The diptote is the noun that does not take tanwīn and takes fatḥah instead of kasrah in jarr. The book illustrates it with صيغ منتهى الجموع: فعالل (قناديل)، فعاليل (فناجين)، and their likes: مساجد، منابر، أسابيع، مفاتيح.")

# ===== Lesson 6: Numbers (p.14, p.296) =====
add(6, "mcq", "The book's example «اِشْتَرَيْتُ هٰذَا بِخَمْسَةَ عَشَرَ رِيَالاً» shows that with 11–99, the counted noun is:",
    "Manṣūb and singular (تمييز)",
    ["Majrūr and plural", "Manṣūb and singular (تمييز)", "Marfū' and singular", "Manṣūb and plural"])
add(6, "fill_blank", "Complete the book's exercise: أَكَلْتُ ثَلَاثَ ___ (I ate three dates).", "تَمَرَاتٍ",
    "Book p.296: أكلت ثلاث تمرات")
add(6, "mcq", "In «كَمْ رِيَالاً عِنْدَكَ؟» (book's exercise), رِيَالاً is:",
    "تمييز — manṣūb after كم",
    ["مفعول به", "تمييز — manṣūb after كم", "حال", "مبتدأ"])
add(6, "qa", "Using the book's exercises, explain the rule of the counted noun with the number 3.",
    "With 3–10, the counted noun (معدود) is plural and majrūr: ثلاث تمراتٍ، ثلاث طبعاتٍ، ثلاث ساعاتٍ، ثلاث أخواتٍ. (Book p.296)")

# ===== Lesson 7: Conditional Sentences (p.126) =====
add(7, "mcq", "In the āyah «وَمَنْ يَبْتَغِ غَيْرَ الْإِسْلَامِ دِينًا فَلَنْ يُقْبَلَ مِنْهُ» (cited in the book), the conditional particle is:",
    "مَنْ",
    ["إِنْ", "مَنْ", "مَا", "لَنْ"])
add(7, "fill_blank", "Complete the ḥadīth cited in the book: «مَنْ كَانَ يُؤْمِنُ بِاللَّهِ وَالْيَوْمِ الْآخِرِ فَلْيَقُلْ خَيْرًا أَوْ ___».", "لِيَصْمُتْ",
    "Book p.126")
add(7, "mcq", "In «إِنْ يَكُنْ مِنْكُمْ عِشْرُونَ صَابِرُونَ يَغْلِبُوا مِائَتَيْنِ» (book's example), يَغْلِبُوا is:",
    "The apodosis (جواب الشرط) — majzūm by dropping the nūn",
    ["The protasis (فعل الشرط)", "The apodosis (جواب الشرط) — majzūm by dropping the nūn", "A ḥāl", "Marfū'"])
add(7, "qa", "Identify the three parts of a conditional sentence using the book's example «فَمَنْ تَطَوَّعَ خَيْرًا فَهُوَ خَيْرٌ لَهُ».",
    "أداة الشرط: مَنْ. فعل الشرط: تَطَوَّعَ. جواب الشرط: فَهُوَ خَيْرٌ لَهُ (a nominal sentence, hence joined with فَ).")

# ===== Lesson 8: Relative Pronouns (p.6, p.26) =====
add(8, "mcq", "The book lists اَلَّذِي، اَلَّتِي، اَلَّذِينَ as:",
    "الأسماء الموصولة — indeclinable (مبنية)",
    ["أسماء الإشارة", "الأسماء الموصولة — indeclinable (مبنية)", "أسماء الاستفهام", "الضمائر"])
add(8, "fill_blank", "Complete the āyah cited in the book: «وَلَدَيْنَا كِتَابٌ يَنْطِقُ ___» (الجاثية: 29).", "بِالْحَقِّ",
    "Book p.26")
add(8, "mcq", "In «وَكُلُّ حِزْبٍ بِمَا لَدَيْهِمْ فَرِحُونَ» (book's example), لَدَيْهِمْ means:",
    "'with them' — لَدَى is an adverb of place meaning عِنْدَ",
    ["'to them'", "'with them' — لَدَى is an adverb of place meaning عِنْدَ", "'from them'", "'about them'"])
add(8, "qa", "The book teaches لَدَى as a ظرف مكان. Give its meaning and two examples from the book.",
    "لَدَى means عِنْدَ ('at/with'). Examples: وَجَدْتُهُ لَدَى الْبَابِ (I found him at the door)، مَاذَا لَدَيْكَ؟ (What do you have?).")

# ===== Lesson 9: Interpreted Infinitive (p.86) =====
add(9, "mcq", "In the book's exercise «تَنَاوُلُ هٰذَا مِنَ الْغَلَّةِ أَحْسَنُ لَكَ», the student must convert the maṣdar into:",
    "A مصدر مؤول (e.g. أَنْ تَتَنَاوَلَ)",
    ["A ṣifah", "A مصدر مؤول (e.g. أَنْ تَتَنَاوَلَ)", "A ḥāl", "A plural"])
add(9, "fill_blank", "The maṣdar of عَفَا يَغْفِرُ (book's example) is ___.", "عَفْوٌ",
    "Book p.86: عفا مصدره عفو")
add(9, "mcq", "The book says طَفِقَ، جَعَلَ، أَخَذَ (when meaning شَرَعَ) work like كَانَ except that their khabar must be:",
    "A verbal sentence whose verb is in the present tense (جملة فعلية فعلها مضارع)",
    ["A single word", "A verbal sentence whose verb is in the present tense (جملة فعلية فعلها مضارع)", "A prepositional phrase", "In the past tense"])
add(9, "qa", "What is the المصدر المؤول? Illustrate with the book's exercise.",
    "It is أَنْ + present-tense verb (or أَنَّ + its sentence), interpreted as a maṣdar. E.g. سَكَنُكَ فِي الْمَهْجَعِ أَفْضَلُ لَنَا → أَنْ تَسْكُنَ فِي الْمَهْجَعِ أَفْضَلُ لَنَا.")

# ===== Lesson 10: Dialogue Practice (p.52, 70, 172) =====
add(10, "mcq", "In the book's dialogue, the manager says: «أَدْعُوكَ لِزِيَارَةِ مَعْهَدِنَا، هٰذِهِ بِطَاقَتِي». بِطَاقَتِي means:",
    "My card",
    ["My office", "My card", "My book", "My car"])
add(10, "fill_blank", "Complete the ḥadīth quoted in Lesson 20 of the book: «خَيْرُكُمْ مَنْ تَعَلَّمَ الْقُرْآنَ وَ___».", "عَلَّمَهُ",
    "رواه البخاري — book p.172")
add(10, "mcq", "In the shop dialogue (book p.70), the customer quotes: «مَا عِنْدَكُمْ يَنْفَدُ وَمَا عِنْدَ اللَّهِ بَاقٍ». This is from:",
    "Sūrah al-Naḥl (16:96)",
    ["Sūrah al-Baqarah", "Sūrah al-Naḥl (16:96)", "Sūrah al-Fātiḥah", "A ḥadīth"])
add(10, "qa", "The book's Lesson 20 dialogue teaches the kunyah ذُو النُّورَيْنِ. Who was called by it and why?",
    "ʿUthmān ibn ʿAffān (رضي الله عنه). He was called ذو النورين (the one with two lights) because he married two of the Prophet's ﷺ daughters: Ruqayyah, then after her death, Umm Kulthūm.")

print("done")
print("Total Madinah 3 exercises:",
      Exercise.objects.filter(lesson__track=track, lesson__level=level, lesson__order__lte=10).count())
