"""Free DB backup: copies SQLite file or runs pg_dump. Usage: manage.py backup_db"""

import os
import shutil
import subprocess
from datetime import datetime

from django.conf import settings
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Back up the database to workspace/backups/ (free)."

    def handle(self, *args, **options):
        outdir = os.path.expanduser("~/workspace/backups")
        os.makedirs(outdir, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        eng = settings.DATABASES["default"]["ENGINE"]
        if "sqlite" in eng:
            src = settings.DATABASES["default"]["NAME"]
            if src == ":memory:" or str(src).startswith("file:"):
                self.stdout.write(self.style.WARNING("In-memory DB — nothing to back up."))
                return
            dst = os.path.join(outdir, f"db-{stamp}.sqlite3")
            shutil.copy2(src, dst)
            self.stdout.write(self.style.SUCCESS(f"SQLite backup → {dst}"))
        elif "postgres" in eng:
            dst = os.path.join(outdir, f"db-{stamp}.sql")
            cfg = settings.DATABASES["default"]
            env = dict(os.environ, PGPASSWORD=cfg.get("PASSWORD", ""))
            with open(dst, "w") as f:
                subprocess.run(["pg_dump", "-h", cfg.get("HOST", "localhost"),
                                "-U", cfg.get("USER", ""), cfg.get("NAME", "")],
                               stdout=f, env=env, check=True)
            self.stdout.write(self.style.SUCCESS(f"Postgres backup → {dst}"))
        else:
            self.stdout.write(self.style.ERROR(f"Unsupported engine: {eng}"))
