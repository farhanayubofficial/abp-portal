"""Book-faithful quizzes for QAS Level 2 - from the actual book pages (English).
Book: Qurani Arabi Seekhiye Level 2 (Shah Mansoor) - Qawaid al-Quran, Intermediate.
"""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="quranic-arabic")
level = CourseLevel.objects.get(track=track, order=2)

REAL_TITLES = {
    1: "Lesson 1: The Doubled Verb (Muda'af)",
    2: "Lesson 2: The Hamzah Verb (Mahmuz)",
    3: "Lesson 3: Weak First Letter (Mithal)",
    4: "Lesson 4: Mithal - More Examples",
    5: "Lesson 5: Weak Middle Letter (Ajwaf)",
    6: "Lesson 6: Weak Last Letter (Naqis)",
    7: "Lesson 7: Naqis - More Examples",
    8: "Lesson 8: The If'al Pattern (Bab Af'al)",
    9: "Lesson 9: If'al - More Examples",
    10: "Lesson 10: If'al - Pattern Practice",
    11: "Lesson 11: If'al - Examples Practice",
    12: "Lesson 12: If'al - More Practice",
    13: "Lesson 13: The Taf'il Pattern (Bab Taf'il)",
    14: "Lesson 14: Taf'il - Practice",
    15: "Lesson 15: The Mufa'ala Pattern (Bab Mufa'ala)",
    16: "Lesson 16: The Tafa''ul Pattern (Bab Tafa''ul)",
    17: "Lesson 17: The Tafa'ul Pattern (Bab Tafa'ul)",
    18: "Lesson 18: The Ifti'al Pattern (Bab Ifti'al)",
    19: "Lesson 19: The Infi'al Pattern (Bab Infi'al)",
    20: "Lesson 20: The Istif'al Pattern (Bab Istif'al)",
}

for order, title in REAL_TITLES.items():
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    lesson.title = title
    lesson.source_reference = f"Qurani Arabi Seekhiye Level 2 - {title}"
    lesson.save()
    n, _ = Exercise.objects.filter(lesson=lesson).delete()
    print(f"{title}: {n} old deleted")

def add(order, qtype, question, answer, options=None, hint=""):
    lesson = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=lesson).count() + 1
    kwargs = dict(lesson=lesson, order=n, question_type=qtype,
                  question=question, options=options or [], explanation=hint)
    if qtype == "qa":
        kwargs["model_answer"] = answer
        kwargs["auto_grade"] = False
        kwargs["correct_answer"] = ""
    else:
        kwargs["correct_answer"] = answer
    Exercise.objects.create(**kwargs)

# ============ Lesson 1: Muda'af (doubled verb) ============
add(1, "mcq", "What is a muda'af verb?", "A verb in which one letter is doubled",
    ["A verb with a hamzah", "A verb in which one letter is doubled",
     "A verb with a weak letter", "A verb with an extra alif"])
add(1, "fill_blank", "Fill in the blank: عَزَّ originally was ___", "عَزَزَ",
    hint="The book shows the doubled letter opened up")
add(1, "mcq", "How many times does عَزَّ appear in the Quran according to the book?", "118",
    ["33", "118", "20", "8"])
add(1, "qa", "Explain the muda'af verb with the book's examples.",
    "A muda'af verb is one in which a letter is doubled, e.g. عَزَّ (= عَزَزَ), مَرَّ (= مَرَرَ), ضَلَّ (= ضَلَلَ), ھَمَّ (= ھَمَمَ). The book counts 99 such verbs used 2013 times in the Quran.")

# ============ Lesson 2: Mahmuz (hamzah verb) ============
add(2, "mcq", "What is a mahmuz verb?", "A verb containing a hamzah",
    ["A verb with a doubled letter", "A verb containing a hamzah",
     "A verb with a weak letter", "A passive verb"])
add(2, "mcq", "أَکَلَ is an example of which type?", "Mahmuz al-fa (hamzah first)",
    ["Mahmuz al-fa (hamzah first)", "Mahmuz al-ain (hamzah middle)", "Mahmuz al-lam (hamzah last)", "Muda'af"])
add(2, "fill_blank", "Fill in the blank: the imperative of أَخَذَ is ___", "خُذْ",
    hint="The book shows the hamzah drops in the imperative")
add(2, "qa", "What are the three natural types of mahmuz verbs? Give the book's examples.",
    "Mahmuz al-fa: أَکَلَ (he ate). Mahmuz al-ain: سَأَلَ (he asked). Mahmuz al-lam: قَرَأَ (he read). The book counts 62 mahmuz verbs used 3085 times in the Quran.")

# ============ Lesson 3: Mithal ============
add(3, "mcq", "What is a mithal verb?", "A verb with a weak letter at the start",
    ["A verb with a weak letter at the start", "A verb with a weak letter in the middle",
     "A verb with a weak letter at the end", "A doubled verb"])
add(3, "mcq", "وَجَدَ is an example of:", "Mithal",
    ["Mithal", "Ajwaf", "Naqis", "Mahmuz"])
add(3, "fill_blank", "The weak letters (huruf 'illah) are: ا, و, ___", "ی",
    hint="Three weak letters")
add(3, "qa", "Define the mithal verb with an example from the book.",
    "A mithal verb has a weak letter (ا، و، ی) as its first root letter, e.g. وَجَدَ (he found). The book notes it appears 108 times in the Quran.")

# ============ Lesson 4: Mithal more examples ============
add(4, "mcq", "In وَجَدَ, which letter is the weak letter?", "و (first letter)",
    ["و (first letter)", "ج (middle letter)", "د (last letter)", "None"])
add(4, "fill_blank", "Mithal verbs begin with one of the weak letters, for example وَجَدَ begins with ___", "و")
add(4, "mcq", "Which of these is a mithal verb?", "وَجَدَ",
    ["قَالَ", "دَعَا", "وَجَدَ", "عَزَّ"])
add(4, "qa", "How do you recognize a mithal verb in the Quran?",
    "Look for a verb whose first root letter is و, ا, or ی, like وَجَدَ. The weak first letter often changes or drops in different forms.")

# ============ Lesson 5: Ajwaf ============
add(5, "mcq", "What is an ajwaf verb?", "A verb with a weak letter in the middle",
    ["A verb with a weak letter at the start", "A verb with a weak letter in the middle",
     "A verb with a weak letter at the end", "A hamzah verb"])
add(5, "mcq", "قَالَ یَقُولُ is an example of:", "Ajwaf wawi",
    ["Ajwaf wawi", "Ajwaf ya'i", "Mithal", "Naqis"])
add(5, "fill_blank", "Fill in the blank: قَالَ becomes ___ in the present tense", "یَقُولُ",
    hint="The book's conjugation table")
add(5, "qa", "Explain ajwaf wawi and ajwaf ya'i with the book's examples.",
    "Ajwaf wawi: middle letter is و, e.g. قَالَ یَقُولُ (he said / he says). Ajwaf ya'i: middle letter is ی, e.g. بَاعَ یَبِیعُ (he sold / he sells). The book counts 116 ajwaf-wawi verbs used 5366 times. Example: وَقُولُوا لِلنَّاسِ حُسْنًا (and speak to people kindly).")

# ============ Lesson 6: Naqis ============
add(6, "mcq", "What is a naqis verb?", "A verb with a weak letter at the end",
    ["A verb with a weak letter at the start", "A verb with a weak letter in the middle",
     "A verb with a weak letter at the end", "A doubled verb"])
add(6, "mcq", "دَعَا is an example of:", "Naqis",
    ["Mithal", "Ajwaf", "Naqis", "Mahmuz"])
add(6, "fill_blank", "In دَعَا the weak letter at the end is ___", "ا",
    hint="The last root letter")
add(6, "qa", "Define the naqis verb with the book's example.",
    "A naqis verb has a weak letter (ا، و، ی) as its last root letter, e.g. دَعَا (he called/prayed). The book notes 207 occurrences in the Quran.")

# ============ Lesson 7: Naqis more examples ============
add(7, "mcq", "Which letter pattern marks a naqis verb?", "Weak letter as the last root letter",
    ["Weak letter as the first root letter", "Doubled middle letter",
     "Weak letter as the last root letter", "Hamzah in the middle"])
add(7, "fill_blank", "دَعَا is naqis because its ___ letter is weak", "last")
add(7, "mcq", "Which of these is naqis?", "دَعَا",
    ["وَجَدَ", "قَالَ", "دَعَا", "سَأَلَ"])
add(7, "qa", "How does a naqis verb change in conjugation? Use دَعَا as an example.",
    "The final weak letter of دَعَا changes with pronouns: دَعَا (he called), دَعَوَا (they two called), دَعَوْا (they called). The weak ending drops or changes - this is the key sign of naqis verbs.")

# ============ Lesson 8: Bab Af'al (أَفْعَلَ) ============
add(8, "mcq", "What is the pattern of Bab Af'al?", "أَفْعَلَ",
    ["فَعَّلَ", "أَفْعَلَ", "فَاعَلَ", "اِفْتَعَلَ"])
add(8, "mcq", "أَسْلَمَ (he submitted/accepted Islam) belongs to which bab?", "Bab Af'al",
    ["Bab Af'al", "Bab Taf'il", "Bab Mufa'ala", "Bab Istif'al"])
add(8, "fill_blank", "Bab Af'al adds a ___ at the beginning of the three-letter root", "hamzah (أ)",
    hint="أَفْعَلَ pattern")
add(8, "qa", "Explain Bab Af'al with the book's example.",
    "Bab Af'al follows the pattern أَفْعَلَ, formed by adding a hamzah before the root. Example: أَسْلَمَ (he submitted). The book counts 186 occurrences in the Quran. It often gives a causative or transitive meaning.")

# ============ Lesson 9: If'al more examples ============
add(9, "mcq", "Which of these follows the أَفْعَلَ pattern?", "أَسْلَمَ",
    ["سَبَّحَ", "أَسْلَمَ", "قَاتَلَ", "اِسْتَغْفَرَ"])
add(9, "fill_blank", "The present tense of أَسْلَمَ is ___", "یُسْلِمُ",
    hint="Bab Af'al present tense")
add(9, "mcq", "What does the extra hamzah in Bab Af'al usually add to the meaning?", "Causative/transitive force",
    ["Past tense only", "Causative/transitive force", "Plural meaning", "Negation"])
add(9, "qa", "Give two Quranic words from Bab Af'al and their meanings.",
    "Examples from the book's method: أَسْلَمَ (he submitted), آمَنَ (he believed - from أَفْعَلَ pattern). Both show the hamzah of Af'al added to the root.")

# ============ Lesson 10: If'al pattern practice ============
add(10, "mcq", "Identify the bab: أَنْزَلَ", "Bab Af'al",
    ["Bab Af'al", "Bab Taf'il", "Bab Infi'al", "Bab Istif'al"])
add(10, "fill_blank", "أَنْزَلَ means 'he sent down'. Its root letters are ن ز ___", "ل",
    hint="Three root letters")
add(10, "mcq", "The imperative of أَسْلَمَ is:", "أَسْلِمْ",
    ["سَلِّمْ", "أَسْلِمْ", "اِسْتَسْلِمْ", "سَالِمْ"])
add(10, "qa", "How do you identify a Bab Af'al verb in the Quran?",
    "Look for the أَ prefix with a sukoon on the first root letter: أَفْعَلَ pattern, e.g. أَسْلَمَ، أَنْزَلَ، آمَنَ. The present tense is یُفْعِلُ and imperative is أَفْعِلْ.")

# ============ Lesson 11: If'al examples practice ============
add(11, "mcq", "آمَنَ belongs to which bab?", "Bab Af'al",
    ["Bab Af'al", "Bab Fa'ala (simple)", "Bab Taf'il", "Bab Mufa'ala"])
add(11, "fill_blank", "آمَنَ is originally أَأْمَنَ on the pattern ___", "أَفْعَلَ")
add(11, "mcq", "What is the verbal noun (masdar) pattern of Bab Af'al?", "إِفْعَال",
    ["تَفْعِیل", "إِفْعَال", "مُفَاعَلَۃ", "اِفْتِعَال"])
add(11, "qa", "Why does آمَنَ look different from أَسْلَمَ though both are Bab Af'al?",
    "آمَنَ comes from the root ا-م-ن where the first root letter is a hamzah; two hamzahs merge (أَأْمَنَ → آمَنَ). The pattern is still أَفْعَلَ - this is the mahmuz + Af'al combination the book teaches.")

# ============ Lesson 12: If'al more practice ============
add(12, "mcq", "Which sentence contains a Bab Af'al verb: إِنَّ الَّذِینَ آمَنُوا...?", "آمَنُوا",
    ["الَّذِینَ", "آمَنُوا", "إِنَّ", "No Af'al verb"])
add(12, "fill_blank", "In وَأَقِیمُوا الصَّلَاۃَ, أَقِیمُوا is Bab ___", "Af'al",
    hint="أَفْعَلَ pattern imperative")
add(12, "mcq", "The ism fa'il (doer noun) of Bab Af'al follows which pattern?", "مُفْعِل",
    ["فَاعِل", "مُفْعِل", "مُفَعِّل", "مُفْتَعِل"])
add(12, "qa", "Write the full pattern set of Bab Af'al using أَسْلَمَ.",
    "Past: أَسْلَمَ, present: یُسْلِمُ, imperative: أَسْلِمْ, doer: مُسْلِم, done-to: مُسْلَم, verbal noun: إِسْلَام. The book teaches all forms together so students recognize them in the Quran.")

# ============ Lesson 13: Bab Taf'il (فَعَّلَ) ============
add(13, "mcq", "What is the pattern of Bab Taf'il?", "فَعَّلَ",
    ["أَفْعَلَ", "فَعَّلَ", "فَاعَلَ", "تَفَعَّلَ"])
add(13, "mcq", "سَبَّحَ (he glorified) belongs to which bab?", "Bab Taf'il",
    ["Bab Af'al", "Bab Taf'il", "Bab Mufa'ala", "Bab Tafa'ul"])
add(13, "fill_blank", "Bab Taf'il doubles the ___ root letter", "middle",
    hint="فَعَّلَ - shaddah on the middle letter")
add(13, "qa", "Explain Bab Taf'il with the book's five examples.",
    "Bab Taf'il follows فَعَّلَ with a shaddah on the middle letter. The book's five examples: صَدَّقَ (33 times), سَبَّحَ (48), سَخَّرَ (26), سَلَّمَ (12), زَوَّجَ (5). Example ayah: وَاذْکُرْ رَبَّکَ کَثِیرًا وَسَبِّحْ بِالْعَشِيِّ وَالْإِبْکَارِ (3:41) - glorify your Lord morning and evening.")

# ============ Lesson 14: Taf'il practice ============
add(14, "mcq", "وَسَبِّحْ in وَسَبِّحْ بِالْعَشِيِّ is:", "Imperative of Bab Taf'il",
    ["Past tense", "Imperative of Bab Taf'il", "Present tense", "Verbal noun"])
add(14, "fill_blank", "زَوَّجَ means 'he married (someone) off'. Its bab is ___", "Taf'il")
add(14, "mcq", "The verbal noun pattern of Bab Taf'il is:", "تَفْعِیل",
    ["إِفْعَال", "تَفْعِیل", "مُفَاعَلَۃ", "اِسْتِفْعَال"])
add(14, "qa", "What meaning does the shaddah (doubling) add in Bab Taf'il?",
    "The doubled middle letter in فَعَّلَ adds intensity or causation: سَبَّحَ (he glorified repeatedly), صَدَّقَ (he confirmed firmly), کَذَّبَ (he denied strongly). Compare simple سَبَحَ (he swam).")

# ============ Lesson 15: Bab Mufa'ala (فَاعَلَ) ============
add(15, "mcq", "What is the pattern of Bab Mufa'ala?", "فَاعَلَ",
    ["فَعَّلَ", "فَاعَلَ", "تَفَاعَلَ", "أَفْعَلَ"])
add(15, "mcq", "قَاتَلَ (he fought) belongs to which bab?", "Bab Mufa'ala",
    ["Bab Af'al", "Bab Taf'il", "Bab Mufa'ala", "Bab Ifti'al"])
add(15, "fill_blank", "Bab Mufa'ala adds an ___ after the first root letter", "alif (ا)",
    hint="فَاعَلَ pattern")
add(15, "qa", "Explain Bab Mufa'ala with its meaning.",
    "Bab Mufa'ala follows فَاعَلَ with an alif after the first root letter, e.g. قَاتَلَ (he fought), جَاھَدَ (he struggled). It usually shows mutual or shared action between two sides. The book counts 44 occurrences in the Quran.")

# ============ Lesson 16: Bab Tafa''ul (تَفَعَّلَ) ============
add(16, "mcq", "What is the pattern of Bab Tafa''ul?", "تَفَعَّلَ",
    ["تَفَاعَلَ", "تَفَعَّلَ", "اِفْتَعَلَ", "اِنْفَعَلَ"])
add(16, "mcq", "تَذَکَّرَ (he reminded himself / took heed) belongs to which bab?", "Bab Tafa''ul",
    ["Bab Taf'il", "Bab Tafa''ul", "Bab Istif'al", "Bab Af'al"])
add(16, "fill_blank", "Bab Tafa''ul is the reflexive of Bab ___", "Taf'il",
    hint="تَفَعَّلَ relates to فَعَّلَ")
add(16, "qa", "Explain the relationship between Bab Taf'il and Bab Tafa''ul.",
    "Bab Tafa''ul (تَفَعَّلَ) is the reflexive of Bab Taf'il (فَعَّلَ): the action comes back on the doer. E.g. عَلَّمَ (he taught) → تَعَلَّمَ (he learned/taught himself). The book counts 63 occurrences.")

# ============ Lesson 17: Bab Tafa'ul (تَفَاعَلَ) ============
add(17, "mcq", "What is the pattern of Bab Tafa'ul?", "تَفَاعَلَ",
    ["تَفَعَّلَ", "تَفَاعَلَ", "اِفْتَعَلَ", "اِسْتَفْعَلَ"])
add(17, "mcq", "تَقَاتَلَ (they fought one another) belongs to which bab?", "Bab Tafa'ul",
    ["Bab Mufa'ala", "Bab Tafa'ul", "Bab Tafa''ul", "Bab Infi'al"])
add(17, "fill_blank", "Bab Tafa'ul is the mutual form of Bab ___", "Mufa'ala",
    hint="تَفَاعَلَ relates to فَاعَلَ")
add(17, "qa", "Explain the relationship between Bab Mufa'ala and Bab Tafa'ul.",
    "Bab Tafa'ul (تَفَاعَلَ) is the mutual/reflexive of Bab Mufa'ala (فَاعَلَ): قَاتَلَ (he fought someone) → تَقَاتَلَ (they fought one another). It shows shared action. The book counts 23 occurrences.")

# ============ Lesson 18: Bab Ifti'al (اِفْتَعَلَ) ============
add(18, "mcq", "What is the pattern of Bab Ifti'al?", "اِفْتَعَلَ",
    ["اِنْفَعَلَ", "اِفْتَعَلَ", "اِسْتَفْعَلَ", "أَفْعَلَ"])
add(18, "mcq", "آتَى (he gave) - its masdar إِیتَاء belongs to which bab?", "Bab Ifti'al",
    ["Bab Af'al", "Bab Ifti'al", "Bab Taf'il", "Bab Istif'al"])
add(18, "fill_blank", "In وَآتُوا الزَّکَاۃَ (and give zakah), آتُوا is the ___ of آتَى", "imperative (plural)",
    hint="Al-Baqarah 2:43")
add(18, "qa", "Explain Bab Ifti'al with the book's example of آتَى.",
    "Bab Ifti'al follows اِفْتَعَلَ. The book's example: آتَى یُؤْتِي إِیتَاء (he gave). Quranic example: وَآتُوا الصَّلَاۃَ... وَآتُوا الزَّکَاۃَ وَارْکَعُوا مَعَ الرَّاکِعِینَ (2:43) - establish prayer, give zakah, bow with those who bow. Also: إِنَّ الَّذِینَ آمَنُوا... وَآتَوُا الزَّکَاۃَ (2:277).")

# ============ Lesson 19: Bab Infi'al (اِنْفَعَلَ) ============
add(19, "mcq", "What is the pattern of Bab Infi'al?", "اِنْفَعَلَ",
    ["اِفْتَعَلَ", "اِنْفَعَلَ", "اِسْتَفْعَلَ", "تَفَعَّلَ"])
add(19, "mcq", "اِنْقَطَعَ (it was cut off) belongs to which bab?", "Bab Infi'al",
    ["Bab Ifti'al", "Bab Infi'al", "Bab Istif'al", "Bab Af'al"])
add(19, "fill_blank", "Bab Infi'al usually gives a ___ (passive-like) meaning", "reflexive/passive",
    hint="The action happens by itself")
add(19, "qa", "Explain the meaning of Bab Infi'al.",
    "Bab Infi'al (اِنْفَعَلَ) shows the action happening to the subject by itself, like a reflexive passive: قَطَعَ (he cut) → اِنْقَطَعَ (it got cut off). The book counts 63 occurrences in the Quran.")

# ============ Lesson 20: Bab Istif'al (اِسْتَفْعَلَ) ============
add(20, "mcq", "What is the pattern of Bab Istif'al?", "اِسْتَفْعَلَ",
    ["اِسْتَفْعَلَ", "اِفْتَعَلَ", "اِنْفَعَلَ", "تَفَاعَلَ"])
add(20, "mcq", "اِسْتَغْفَرَ (he sought forgiveness) belongs to which bab?", "Bab Istif'al",
    ["Bab Af'al", "Bab Ifti'al", "Bab Istif'al", "Bab Taf'il"])
add(20, "fill_blank", "Bab Istif'al usually means seeking or ___ something", "requesting",
    hint="اِسْتَغْفَرَ = he sought forgiveness")
add(20, "qa", "Explain the meaning of Bab Istif'al with examples.",
    "Bab Istif'al (اِسْتَفْعَلَ) usually means seeking or requesting: اِسْتَغْفَرَ (he sought forgiveness), اِسْتَعَانَ (he sought help - as in إِیَّاکَ نَسْتَعِینُ, You alone we ask for help). The book counts 55 occurrences in the Quran.")

print("done")
print("Total:", Exercise.objects.filter(lesson__track=track, lesson__level=level).count())
