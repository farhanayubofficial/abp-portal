"""Book-faithful ENGLISH quizzes for Qasas al-Nabiyyin Part 3 (Musa AS).
Based on pages actually read from Qasas-un-Nabiyeen-3-Nadwi.pdf."""
import os
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
import django
django.setup()
from apps.courses.models import CourseTrack, CourseLevel, Lesson, Exercise

track = CourseTrack.objects.get(code="arabic-language")
level = CourseLevel.objects.get(track=track, order=3)

# 5 lessons mapped to the book's real chapters (all about Musa AS)
LESSONS = {
    11: ("Qasas 3: The Birth of Musa - In Pharaoh's Palace",
         "Chapters: في قصر فرعون، من يرضع الطفل — Allah's command to Musa's mother, the box in the Nile"),
    12: ("Qasas 3: The Fatal Blow and the Flight to Midian",
         "Chapters: الضربة القاضية، من مصر إلى مدين — Musa's strength, the two men fighting, repentance"),
    13: ("Qasas 3: Musa's Call - Before Pharaoh",
         "Chapters: اذهب إلى فرعون إنه طغى، الدعوة إلى الله — the debate, علمها عند ربي"),
    14: ("Qasas 3: The Five Signs and the Exodus",
         "Chapters: خمس آيات، الخروج، غرق فرعون — الطوفان والجراد والقمل والضفادع والدم"),
    15: ("Qasas 3: In the Wilderness - The Tablets and the Forty Years",
         "Chapters: الألواح، العجل، في سبيل العلم — the seventy men, the thunderbolt, forty years"),
}

for order, (title, ref) in LESSONS.items():
    les = Lesson.objects.get(track=track, level=level, order=order)
    les.title = title
    les.source_reference = "Qasas al-Nabiyyin Part 3 (Nadwi) — " + ref
    les.save()
    n, _ = Exercise.objects.filter(lesson=les).delete()
    print(f"{title}: deleted {n} old exercises")

def add(order, qtype, question, answer, options=None, explanation=""):
    les = Lesson.objects.get(track=track, level=level, order=order)
    n = Exercise.objects.filter(lesson=les).count() + 1
    kw = dict(lesson=les, order=n, question_type=qtype, question=question,
              options=options or [], explanation=explanation)
    if qtype == "qa":
        kw.update(model_answer=answer, auto_grade=False, correct_answer="")
    else:
        kw.update(correct_answer=answer)
    Exercise.objects.create(**kw)

# ============ Lesson 11: The Birth of Musa ============
add(11, "mcq",
    "What did Allah command the mother of Musa to do when she feared for him?",
    "Nurse him, then cast him into the river",
    ["Hide him in the palace", "Nurse him, then cast him into the river",
     "Flee to Midian with him", "Give him to the queen"],
    "From the verse: أن أرضعيه فإذا خفت عليه فألقيه في اليم")
add(11, "fill_blank",
    "Musa's mother placed her beautiful baby in a ___ (Arabic: صندوق) and cast it into the Nile.",
    "box", explanation="صندوق means box")
add(11, "mcq",
    "According to the book, where did Pharaoh have his large palaces?",
    "On the bank of the Nile",
    ["In the desert", "On the bank of the Nile", "In Midian", "On a mountain"],
    "كان فرعون له قصور كبيرة على شاطئ النيل")
add(11, "qa",
    "Why did Musa's mother trust Allah's command even though casting a baby into the river seemed dangerous?",
    "She trusted in Allah and relied on His revelation (توكلت على الله واعتمدت على وحي الله). "
    "She reasoned that the house was not safer than the box, because the police were everywhere "
    "and the enemy of children was watching. After her grief, she was patient and trusted Allah.")

# ============ Lesson 12: The Fatal Blow and the Flight to Midian ============
add(12, "mcq",
    "When Musa was a strong young man, what did Allah grant him?",
    "Wisdom and knowledge (حكماً وعلماً)",
    ["Wealth and palaces", "Wisdom and knowledge (حكماً وعلماً)",
     "An army of followers", "The Torah"],
    "ولما كان موسى شاباً قوياً آتاه الله حكماً وعلماً")
add(12, "fill_blank",
    "The two men fighting in the city were one from Bani Israel and one from the ___ (الأقباط).",
    "Copts", explanation="الأقباط = the Copts, the native Egyptians")
add(12, "mcq",
    "What did Musa say after the Copt died from his blow?",
    "This is from the work of Satan, he is an enemy",
    ["I did nothing wrong", "This is from the work of Satan, he is an enemy",
     "Pharaoh ordered me", "The man deserved it"],
    "قال: هذا من عمل الشيطان إنه عدو")
add(12, "qa",
    "What does this chapter teach about Musa's character before prophethood?",
    "Musa hated the wrongdoers (يبغض الظالمين) and loved the weak and the oppressed, "
    "helping them — as does every prophet. When he made a mistake, he regretted it deeply "
    "and repented to Allah at once (فتاب موسى إلى الله وأناب).")

# ============ Lesson 13: Musa's Call - Before Pharaoh ============
add(13, "mcq",
    "What was Allah's command to Musa concerning Pharaoh?",
    "Go to Pharaoh, for he has transgressed",
    ["Avoid Pharaoh completely", "Go to Pharaoh, for he has transgressed",
     "Fight Pharaoh's army", "Flee Egypt at once"],
    "اذهب إلى فرعون إنه طغى")
add(13, "fill_blank",
    "Musa said: 'Knowledge of them is with my Lord in a Book; my Lord neither errs nor ___.'",
    "forgets", explanation="لا يضل ربي ولا ينسى (Quran 20:52)")
add(13, "mcq",
    "How does the book describe Musa in comparison to Pharaoh during the debate?",
    "Musa was wiser than Pharaoh",
    ["Pharaoh was wiser than Musa", "Musa was wiser than Pharaoh",
     "They were equally wise", "Neither was wise"],
    "ولكن موسى كان أعقل من فرعون — and Musa was upon light from his Lord")
add(13, "qa",
    "How did Pharaoh's council react when Musa spoke about their forefathers?",
    "The people of the council became angry and said that Musa had insulted their forefathers "
    "(غضب أهل المجلس وقالوا إن موسى سب آباءنا). Pharaoh himself tried to escape from Musa's words "
    "rather than answer them.")

# ============ Lesson 14: The Five Signs and the Exodus ============
add(14, "mcq",
    "Which of the following was NOT among the five distinct signs sent upon Pharaoh's people?",
    "Earthquake",
    ["Flood (الطوفان)", "Locusts (الجراد)", "Frogs (الضفادع)", "Earthquake"],
    "The five: الطوفان والجراد والقمل والضفادع والدم — flood, locusts, lice, frogs, blood")
add(14, "fill_blank",
    "Each time Allah removed the affliction from them, they ___ their promise (نكثوا عهدهم).",
    "broke", explanation="نكثوا عهدهم = they broke their covenant")
add(14, "mcq",
    "What did the people promise Musa whenever they saw a sign?",
    "We will repent, believe, and let Bani Israel go with you",
    ["We will fight you", "We will repent, believe, and let Bani Israel go with you",
     "We will build you a palace", "We will worship your Lord forever"],
    "قالوا لموسى: ادع لنا ربك أن يكشف عنا البلاء ونتوب ونؤمن ونرسل معك بني إسرائيل")
add(14, "qa",
    "Why did the signs not benefit Pharaoh's people?",
    "Because they were arrogant (فاستكبروا) and were a criminal people (قوماً مجرمين). "
    "Every time a sign came they promised to believe, but when Allah removed the affliction "
    "they broke their promise (نكثوا عهدهم).")

# ============ Lesson 15: In the Wilderness ============
add(15, "mcq",
    "What did the seventy men demand when Musa brought them the Tablets?",
    "We will not believe until we see Allah openly",
    ["Give us more tablets", "We will not believe until we see Allah openly",
     "Let us return to Egypt", "Forgive our sins first"],
    "قالوا: لن نؤمن حتى نرى الله جهرة")
add(15, "fill_blank",
    "Allah decreed the holy land forbidden to them for ___ years, wandering in the earth.",
    "forty", explanation="أربعين سنة يتيهون في الأرض (Quran 5:26)")
add(15, "mcq",
    "What seized the seventy men when they made their insolent demand?",
    "The thunderbolt (الصاعقة)",
    ["A flood", "The thunderbolt (الصاعقة)", "An army", "A famine"],
    "فأخذتهم الصاعقة وهم ينظرون")
add(15, "qa",
    "What did Bani Israel say when asked to enter the holy land?",
    "They said: 'O Musa, we will never enter it while they are in it. Go, you and your Lord, "
    "and fight; we are sitting here.' (قالوا يا موسى إنا لن ندخلها أبداً ما داموا فيها فاذهب أنت "
    "وربك فقاتلا إنا هاهنا قاعدون). Musa despaired of them and prayed to Allah.")

print("done")
print("Total Qasas-3 exercises:",
      Exercise.objects.filter(lesson__track=track, lesson__level=level,
                              lesson__order__in=[11,12,13,14,15]).count())
