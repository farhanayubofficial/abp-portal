"""Shared views (landing page, etc.)."""
from django.views.generic import TemplateView


class LandingView(TemplateView):
    template_name = "core/landing.html"
