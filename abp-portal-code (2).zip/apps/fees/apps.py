from django.apps import AppConfig


class FeesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = "apps.fees"
    verbose_name = "Fees & Finance"
