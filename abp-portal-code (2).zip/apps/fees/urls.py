from django.urls import path

from . import views

app_name = "fees"

urlpatterns = [
    path("plans/", views.FeePlanListView.as_view(), name="feeplan_list"),
    path("invoices/", views.InvoiceListView.as_view(), name="invoice_list"),
    path("invoices/generate/", views.GenerateInvoicesView.as_view(), name="generate_invoices"),
    path("invoices/<int:pk>/", views.InvoiceDetailView.as_view(), name="invoice_detail"),
    path("my/", views.MyInvoicesView.as_view(), name="my_invoices"),
    path("receipt/<int:pk>/", views.ReceiptPDFView.as_view(), name="receipt_pdf"),
    path("salaries/", views.SalaryListView.as_view(), name="salary_list"),
    path("report/", views.FinanceReportView.as_view(), name="finance_report"),
]
