"""Phase 6 views: fee plans, invoices, manual payments, PDF receipts, salaries, reports."""

from datetime import date
from decimal import Decimal, InvalidOperation
from io import BytesIO

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db.models import Sum
from django.http import FileResponse, Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import DetailView, ListView, TemplateView, View

from .models import CURRENCY_CHOICES, FeePlan, Invoice, Payment, SalaryPayment


class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        u = self.request.user
        return u.is_authenticated and (u.is_teacher or u.is_admin)


# ---------- Fee plans ----------

class FeePlanListView(StaffRequiredMixin, ListView):
    model = FeePlan
    template_name = "fees/feeplan_list.html"
    context_object_name = "plans"

    def get_queryset(self):
        return FeePlan.objects.select_related("track").order_by("track__name")

    def post(self, request):
        from apps.courses.models import CourseTrack

        track = get_object_or_404(CourseTrack, pk=request.POST.get("track"))
        try:
            amount = Decimal(request.POST.get("amount") or "0")
        except InvalidOperation:
            amount = Decimal("0")
        FeePlan.objects.create(
            track=track,
            name=request.POST.get("name", "Monthly Fee").strip(),
            amount=amount,
            currency=request.POST.get("currency", "PKR"),
        )
        messages.success(request, "Fee plan created.")
        return redirect("fees:feeplan_list")

    def get_context_data(self, **kwargs):
        from apps.courses.models import CourseTrack

        ctx = super().get_context_data(**kwargs)
        ctx["tracks"] = CourseTrack.objects.all()
        ctx["currencies"] = CURRENCY_CHOICES
        return ctx


# ---------- Invoices ----------

class GenerateInvoicesView(StaffRequiredMixin, TemplateView):
    template_name = "fees/generate.html"

    def get_context_data(self, **kwargs):
        from apps.courses.models import CourseTrack

        ctx = super().get_context_data(**kwargs)
        ctx["plans"] = FeePlan.objects.filter(is_active=True).select_related("track")
        ctx["today"] = date.today().strftime("%b %Y")
        return ctx

    def post(self, request):
        from apps.accounts.models import StudentProfile

        plan = get_object_or_404(FeePlan, pk=request.POST.get("plan"), is_active=True)
        period = request.POST.get("period_label", "").strip() or date.today().strftime("%b %Y")
        due = request.POST.get("due_date") or str(date.today())
        students = StudentProfile.objects.filter(tracks=plan.track, is_enrolled=True)
        created = 0
        for profile in students.select_related("user"):
            inv, was_created = Invoice.objects.get_or_create(
                student=profile.user, fee_plan=plan, period_label=period,
                defaults={"amount": plan.amount, "currency": plan.currency, "due_date": due},
            )
            created += was_created
            # Phase 7: notify student of new invoice
            if was_created:
                from apps.notifications.models import invoice_url, notify, Notification
                due = inv.due_date
                due_str = due.strftime("%d %b %Y") if hasattr(due, "strftime") else str(due)
                notify(profile.user, f"Fee invoice: {period}",
                       f"{inv.amount} {inv.currency} — due {due_str}",
                       invoice_url(inv.pk), Notification.TYPE_FEE)
        messages.success(request, f"{created} invoices created for {period}.")
        return redirect("fees:invoice_list")


class InvoiceListView(StaffRequiredMixin, ListView):
    model = Invoice
    template_name = "fees/invoice_list.html"
    context_object_name = "invoices"
    paginate_by = 50

    def get_queryset(self):
        qs = Invoice.objects.select_related("student", "fee_plan__track").order_by("-created_at")
        f = self.request.GET.get("filter", "")
        if f == "unpaid":
            qs = qs.filter(status=Invoice.STATUS_UNPAID)
        elif f == "paid":
            qs = qs.filter(status=Invoice.STATUS_PAID)
        elif f == "overdue":
            qs = qs.filter(status=Invoice.STATUS_UNPAID, due_date__lt=timezone.now().date())
        return qs


class InvoiceDetailView(LoginRequiredMixin, DetailView):
    model = Invoice
    template_name = "fees/invoice_detail.html"
    context_object_name = "invoice"

    def get_queryset(self):
        qs = super().get_queryset().select_related("student", "fee_plan__track")
        u = self.request.user
        if not (u.is_teacher or u.is_admin):
            qs = qs.filter(student=u)
        return qs

    def post(self, request, pk):
        # staff: record a manual payment OR adjust this student's invoice amount
        u = request.user
        if not (u.is_teacher or u.is_admin):
            raise Http404
        inv = self.get_object()
        if request.POST.get("action") == "adjust_amount":
            try:
                new_amount = Decimal(request.POST.get("new_amount") or "0")
            except InvalidOperation:
                new_amount = Decimal("0")
            if new_amount <= 0:
                messages.error(request, "Amount must be positive.")
            else:
                inv.amount = new_amount
                inv.save(update_fields=["amount"])
                inv.refresh_status()
                messages.success(request, f"Invoice amount set to {new_amount} {inv.currency}.")
            return redirect("fees:invoice_detail", pk=pk)
        try:
            amount = Decimal(request.POST.get("amount") or "0")
        except InvalidOperation:
            amount = Decimal("0")
        if amount <= 0:
            messages.error(request, "Amount must be positive.")
            return redirect("fees:invoice_detail", pk=pk)
        Payment.objects.create(
            invoice=inv, amount=amount,
            currency=request.POST.get("currency", inv.currency),
            method=request.POST.get("method", "cash"),
            notes=request.POST.get("notes", "").strip(),
            received_by=u,
        )
        # Phase 7: notify the student
        from apps.notifications.models import invoice_url, notify, Notification
        notify(inv.student, "Payment received — JazakAllah!",
               f"{amount} {inv.currency} for {inv.period_label}",
               invoice_url(inv.pk), Notification.TYPE_FEE)
        messages.success(request, f"Payment of {amount} recorded.")
        return redirect("fees:invoice_detail", pk=pk)


class MyInvoicesView(LoginRequiredMixin, ListView):
    template_name = "fees/my_invoices.html"
    context_object_name = "invoices"

    def get_queryset(self):
        return (
            Invoice.objects.filter(student=self.request.user)
            .select_related("fee_plan__track")
            .order_by("-created_at")
        )


# ---------- PDF receipt (free, reportlab) ----------

class ReceiptPDFView(LoginRequiredMixin, View):
    def get(self, request, pk):
        payment = get_object_or_404(Payment.objects.select_related("invoice__student", "invoice__fee_plan__track"), pk=pk)
        u = request.user
        inv = payment.invoice
        if not (u.is_teacher or u.is_admin) and inv.student != u:
            raise Http404
        buf = BytesIO()
        self._build_pdf(buf, payment)
        buf.seek(0)
        return FileResponse(buf, as_attachment=True,
                            filename=f"receipt-{payment.pk}.pdf",
                            content_type="application/pdf")

    def _build_pdf(self, buf, p):
        from reportlab.lib.pagesizes import A5
        from reportlab.lib.units import mm
        from reportlab.pdfgen import canvas

        c = canvas.Canvas(buf, pagesize=A5)
        w, h = A5
        y = h - 25 * mm
        c.setFont("Helvetica-Bold", 16)
        c.drawString(20 * mm, y, "Arabic Bridge Program")
        y -= 8 * mm
        c.setFont("Helvetica", 10)
        c.drawString(20 * mm, y, "Fee Receipt")
        y -= 10 * mm
        c.setFont("Helvetica", 11)
        rows = [
            ("Receipt #", str(p.pk)),
            ("Date", p.paid_at.strftime("%d %b %Y, %H:%M")),
            ("Student", p.invoice.student.email),
            ("Track", p.invoice.fee_plan.track.name),
            ("Period", p.invoice.period_label),
            ("Amount", f"{p.amount} {p.currency}"),
            ("Method", p.get_method_display()),
            ("Received by", p.received_by.email if p.received_by else "—"),
        ]
        for label, val in rows:
            c.setFont("Helvetica-Bold", 11)
            c.drawString(20 * mm, y, label + ":")
            c.setFont("Helvetica", 11)
            c.drawString(55 * mm, y, str(val))
            y -= 7 * mm
        y -= 5 * mm
        c.setFont("Helvetica-Oblique", 9)
        c.drawString(20 * mm, y, "JazakAllah for your payment. — Founded and Managed by Farhan Khan")
        c.showPage()
        c.save()


# ---------- Salaries ----------

class SalaryListView(StaffRequiredMixin, ListView):
    model = SalaryPayment
    template_name = "fees/salary_list.html"
    context_object_name = "salaries"

    def get_queryset(self):
        return SalaryPayment.objects.select_related("teacher").order_by("-paid_at")[:100]

    def post(self, request):
        from apps.accounts.models import User

        teacher = get_object_or_404(User, pk=request.POST.get("teacher"))
        try:
            amount = Decimal(request.POST.get("amount") or "0")
        except InvalidOperation:
            amount = Decimal("0")
        SalaryPayment.objects.create(
            teacher=teacher, amount=amount,
            currency=request.POST.get("currency", "PKR"),
            month_label=request.POST.get("month_label", "").strip() or date.today().strftime("%b %Y"),
            notes=request.POST.get("notes", "").strip(),
        )
        messages.success(request, "Salary recorded.")
        return redirect("fees:salary_list")

    def get_context_data(self, **kwargs):
        from apps.accounts.models import User

        ctx = super().get_context_data(**kwargs)
        ctx["teachers"] = User.objects.filter(role="teacher")
        ctx["currencies"] = CURRENCY_CHOICES
        return ctx


# ---------- Finance report ----------

class FinanceReportView(StaffRequiredMixin, TemplateView):
    template_name = "fees/report.html"

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        start = timezone.now().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        month_payments = Payment.objects.filter(paid_at__gte=start)
        collected = {}
        for cur, _ in CURRENCY_CHOICES:
            collected[cur] = month_payments.filter(currency=cur).aggregate(t=Sum("amount"))["t"] or Decimal("0")
        outstanding = {}
        for cur, _ in CURRENCY_CHOICES:
            outstanding[cur] = (
                Invoice.objects.filter(status=Invoice.STATUS_UNPAID, currency=cur)
                .aggregate(t=Sum("amount"))["t"]
                or Decimal("0")
            )
        overdue_count = Invoice.objects.filter(
            status=Invoice.STATUS_UNPAID, due_date__lt=timezone.now().date()
        ).count()
        salaries = {}
        for cur, _ in CURRENCY_CHOICES:
            salaries[cur] = (
                SalaryPayment.objects.filter(paid_at__gte=start, currency=cur)
                .aggregate(t=Sum("amount"))["t"]
                or Decimal("0")
            )
        ctx.update({
            "month_label": start.strftime("%b %Y"),
            "collected": collected,
            "outstanding": outstanding,
            "overdue_count": overdue_count,
            "salaries": salaries,
        })
        return ctx
