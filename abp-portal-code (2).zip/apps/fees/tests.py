"""Phase 6 tests: fee plans, invoices, payments, receipts, salaries, reports."""

from datetime import date, timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from apps.accounts.models import StudentProfile
from apps.courses.models import CourseTrack

from .models import FeePlan, Invoice, Payment, SalaryPayment

User = get_user_model()


class Phase6Tests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user(email="fee_admin@abp.test", password="x", role="admin")
        self.teacher = User.objects.create_user(email="fee_teacher@abp.test", password="x", role="teacher")
        self.student = User.objects.create_user(email="fee_student@abp.test", password="x", role="student")
        self.track = CourseTrack.objects.create(code="fee", name="Fee Track")
        self.profile = StudentProfile.objects.create(user=self.student, student_id="FEE001")
        self.profile.tracks.add(self.track)
        self.plan = FeePlan.objects.create(track=self.track, name="Monthly Fee",
                                           amount=Decimal("5000"), currency="PKR")

    def test_admin_creates_fee_plan(self):
        self.client.force_login(self.admin)
        r = self.client.post("/fees/plans/", {"track": self.track.pk, "name": "Monthly",
                                              "amount": "50", "currency": "USD"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(FeePlan.objects.filter(amount=50, currency="USD").exists())

    def test_student_cannot_create_plan(self):
        self.client.force_login(self.student)
        self.assertEqual(self.client.get("/fees/plans/").status_code, 403)

    def test_generate_invoices(self):
        self.client.force_login(self.admin)
        r = self.client.post("/fees/invoices/generate/", {
            "plan": self.plan.pk, "period_label": "Oct 2026",
            "due_date": str(date.today() + timedelta(days=10))})
        self.assertEqual(r.status_code, 302)
        inv = Invoice.objects.get(student=self.student, period_label="Oct 2026")
        self.assertEqual(inv.amount, Decimal("5000"))
        self.assertEqual(inv.status, "unpaid")
        # second run skips existing
        self.client.post("/fees/invoices/generate/", {
            "plan": self.plan.pk, "period_label": "Oct 2026",
            "due_date": str(date.today() + timedelta(days=10))})
        self.assertEqual(Invoice.objects.filter(period_label="Oct 2026").count(), 1)

    def test_record_payment_marks_paid(self):
        inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                     period_label="Oct 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today())
        self.client.force_login(self.admin)
        r = self.client.post(f"/fees/invoices/{inv.pk}/", {"amount": "5000",
                                                            "currency": "PKR", "method": "easypaisa"})
        self.assertEqual(r.status_code, 302)
        inv.refresh_from_db()
        self.assertEqual(inv.status, "paid")
        self.assertEqual(inv.total_paid, Decimal("5000"))

    def test_partial_payment_stays_unpaid(self):
        inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                     period_label="Oct 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today())
        Payment.objects.create(invoice=inv, amount=Decimal("2000"), currency="PKR",
                               received_by=self.admin)
        inv.refresh_from_db()
        self.assertEqual(inv.status, "unpaid")

    def test_overdue_detection(self):
        inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                     period_label="Sep 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today() - timedelta(days=1))
        self.assertTrue(inv.is_overdue)
        self.client.force_login(self.admin)
        r = self.client.get("/fees/invoices/?filter=overdue")
        self.assertContains(r, "Sep 2026")

    def test_receipt_pdf(self):
        inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                     period_label="Oct 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today())
        p = Payment.objects.create(invoice=inv, amount=Decimal("5000"), currency="PKR",
                                   received_by=self.admin)
        self.client.force_login(self.student)
        r = self.client.get(f"/fees/receipt/{p.pk}/")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r["Content-Type"], "application/pdf")

    def test_student_cannot_see_others_receipt(self):
        other = User.objects.create_user(email="other@abp.test", password="x", role="student")
        inv = Invoice.objects.create(student=other, fee_plan=self.plan,
                                     period_label="Oct 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today())
        p = Payment.objects.create(invoice=inv, amount=Decimal("5000"), currency="PKR")
        self.client.force_login(self.student)
        self.assertEqual(self.client.get(f"/fees/receipt/{p.pk}/").status_code, 404)

    def test_student_my_invoices(self):
        Invoice.objects.create(student=self.student, fee_plan=self.plan,
                               period_label="Oct 2026", amount=Decimal("5000"),
                               currency="PKR", due_date=date.today())
        self.client.force_login(self.student)
        r = self.client.get("/fees/my/")
        self.assertContains(r, "Oct 2026")

    def test_salary_record(self):
        self.client.force_login(self.admin)
        r = self.client.post("/fees/salaries/", {"teacher": self.teacher.pk, "amount": "30000",
                                                 "currency": "PKR", "month_label": "Oct 2026"})
        self.assertEqual(r.status_code, 302)
        self.assertTrue(SalaryPayment.objects.filter(teacher=self.teacher).exists())

    def test_finance_report(self):
        inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                     period_label="Oct 2026", amount=Decimal("5000"),
                                     currency="PKR", due_date=date.today())
        Payment.objects.create(invoice=inv, amount=Decimal("5000"), currency="PKR",
                               received_by=self.admin)
        self.client.force_login(self.admin)
        r = self.client.get("/fees/report/")
        self.assertContains(r, "Finance Report")
        self.assertContains(r, "5000")

    def test_dashboard_widgets(self):
        Invoice.objects.create(student=self.student, fee_plan=self.plan,
                               period_label="Oct 2026", amount=Decimal("5000"),
                               currency="PKR", due_date=date.today())
        self.client.force_login(self.student)
        r = self.client.get("/accounts/dashboard/")
        self.assertContains(r, "My Unpaid Fees")
        self.client.force_login(self.admin)
        r = self.client.get("/accounts/dashboard/")
        self.assertContains(r, "Finance")

    def test_requires_login(self):
        self.assertEqual(self.client.get("/fees/my/").status_code, 302)

class InvoiceAdjustTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user(email="adj_admin@abp.test", password="x", role="admin")
        self.student = User.objects.create_user(email="adj_student@abp.test", password="x", role="student")
        self.track = CourseTrack.objects.create(code="adj", name="Adj Track")
        self.plan = FeePlan.objects.create(track=self.track, name="Monthly Fee",
                                           amount=Decimal("5000"), currency="PKR")
        self.inv = Invoice.objects.create(student=self.student, fee_plan=self.plan,
                                          period_label="Oct 2026", amount=Decimal("5000"),
                                          currency="PKR", due_date=date.today())

    def test_admin_can_set_student_fee(self):
        self.client.force_login(self.admin)
        r = self.client.post(f"/fees/invoices/{self.inv.pk}/",
                             {"action": "adjust_amount", "new_amount": "3500"})
        self.assertEqual(r.status_code, 302)
        self.inv.refresh_from_db()
        self.assertEqual(self.inv.amount, Decimal("3500"))

    def test_student_cannot_adjust_fee(self):
        self.client.force_login(self.student)
        r = self.client.post(f"/fees/invoices/{self.inv.pk}/",
                             {"action": "adjust_amount", "new_amount": "1"})
        self.assertEqual(r.status_code, 404)
        self.inv.refresh_from_db()
        self.assertEqual(self.inv.amount, Decimal("5000"))

    def test_adjust_rejects_zero(self):
        self.client.force_login(self.admin)
        self.client.post(f"/fees/invoices/{self.inv.pk}/",
                         {"action": "adjust_amount", "new_amount": "0"})
        self.inv.refresh_from_db()
        self.assertEqual(self.inv.amount, Decimal("5000"))
