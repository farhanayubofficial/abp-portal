"""Phase 6 — Fees & Finance. Manual payment recording (no gateway, all free). USD + PKR."""

from decimal import Decimal

from django.conf import settings
from django.db import models
from django.db.models import Sum
from django.utils import timezone

CURRENCY_USD = "USD"
CURRENCY_PKR = "PKR"
CURRENCY_CHOICES = [(CURRENCY_USD, "USD"), (CURRENCY_PKR, "PKR")]


class FeePlan(models.Model):
    """Monthly fee for a track, in USD or PKR."""

    track = models.ForeignKey(
        "courses.CourseTrack", on_delete=models.CASCADE, related_name="fee_plans"
    )
    name = models.CharField(max_length=100, help_text="e.g. Monthly Fee")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES, default=CURRENCY_PKR)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["track__name", "name"]

    def __str__(self):
        return f"{self.track.name} — {self.name}: {self.amount} {self.currency}"


class Invoice(models.Model):
    """Fee bill for one student for one period."""

    STATUS_UNPAID = "unpaid"
    STATUS_PAID = "paid"
    STATUS_CHOICES = [(STATUS_UNPAID, "Unpaid"), (STATUS_PAID, "Paid")]

    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="invoices"
    )
    fee_plan = models.ForeignKey(FeePlan, on_delete=models.PROTECT, related_name="invoices")
    period_label = models.CharField(max_length=20, help_text="e.g. Oct 2026")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES)
    due_date = models.DateField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_UNPAID)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        unique_together = [("student", "fee_plan", "period_label")]

    def __str__(self):
        return f"#{self.pk} {self.student.email} — {self.period_label} ({self.status})"

    @property
    def is_overdue(self):
        return self.status == self.STATUS_UNPAID and self.due_date < timezone.now().date()

    @property
    def total_paid(self):
        return self.payments.aggregate(t=Sum("amount"))["t"] or Decimal("0")

    def refresh_status(self):
        self.status = (
            self.STATUS_PAID if self.total_paid >= self.amount else self.STATUS_UNPAID
        )
        self.save(update_fields=["status"])


class Payment(models.Model):
    """One manual payment against an invoice (cash / bank / Easypaisa / JazzCash...)."""

    METHOD_CASH = "cash"
    METHOD_BANK = "bank"
    METHOD_EASYPAISA = "easypaisa"
    METHOD_JAZZCASH = "jazzcash"
    METHOD_OTHER = "other"
    METHOD_CHOICES = [
        (METHOD_CASH, "Cash"),
        (METHOD_BANK, "Bank transfer"),
        (METHOD_EASYPAISA, "Easypaisa"),
        (METHOD_JAZZCASH, "JazzCash"),
        (METHOD_OTHER, "Other"),
    ]

    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name="payments")
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES)
    method = models.CharField(max_length=20, choices=METHOD_CHOICES, default=METHOD_CASH)
    paid_at = models.DateTimeField(default=timezone.now)
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="received_payments",
    )
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-paid_at"]

    def __str__(self):
        return f"{self.amount} {self.currency} → Invoice #{self.invoice_id}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        self.invoice.refresh_status()


class SalaryPayment(models.Model):
    """Teacher salary record (manual, free)."""

    teacher = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="salary_payments"
    )
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=3, choices=CURRENCY_CHOICES, default=CURRENCY_PKR)
    month_label = models.CharField(max_length=20, help_text="e.g. Oct 2026")
    paid_at = models.DateTimeField(default=timezone.now)
    notes = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["-paid_at"]

    def __str__(self):
        return f"{self.teacher.email} — {self.month_label}: {self.amount} {self.currency}"
