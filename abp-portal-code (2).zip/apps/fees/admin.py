from django.contrib import admin

from .models import FeePlan, Invoice, Payment, SalaryPayment


class PaymentInline(admin.TabularInline):
    model = Payment
    extra = 0


@admin.register(FeePlan)
class FeePlanAdmin(admin.ModelAdmin):
    list_display = ["track", "name", "amount", "currency", "is_active"]
    list_filter = ["currency", "is_active"]


@admin.register(Invoice)
class InvoiceAdmin(admin.ModelAdmin):
    list_display = ["id", "student", "period_label", "amount", "currency", "status", "due_date"]
    list_filter = ["status", "currency"]
    inlines = [PaymentInline]


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ["invoice", "amount", "currency", "method", "paid_at"]


@admin.register(SalaryPayment)
class SalaryPaymentAdmin(admin.ModelAdmin):
    list_display = ["teacher", "month_label", "amount", "currency", "paid_at"]
