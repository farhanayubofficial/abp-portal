"""Vocabulary Game views: home, play, profile, leaderboard."""

import json
import random
from datetime import timedelta

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.models import User
from apps.courses.models import CourseTrack

from .models import (BADGES, DIFF_EASY, DIFF_HARD, DIFF_MEDIUM, POINTS,
                     GameSession, StudentBadge, VocabWord)

QUESTIONS_PER_GAME = 10


def _award(student, key):
    badge, created = StudentBadge.objects.get_or_create(
        student=student, badge_key=key)
    return badge if created else None


def _check_badges(student, session):
    """Award any newly-earned badges. Returns list of (name, icon)."""
    new = []
    sessions = GameSession.objects.filter(student=student)
    if sessions.count() == 1:
        b = _award(student, "first_game")
        if b: new.append(BADGES["first_game"][:2])
    if session.best_streak >= 3:
        b = _award(student, "streak_3")
        if b: new.append(BADGES["streak_3"][:2])
    if session.score >= 100:
        b = _award(student, "century")
        if b: new.append(BADGES["century"][:2])
    total_correct = sessions.aggregate(s=Sum("correct"))["s"] or 0
    if total_correct >= 50:
        b = _award(student, "half_century_words")
        if b: new.append(BADGES["half_century_words"][:2])
    # 7 consecutive days
    days = sorted({s.created_at.date() for s in sessions})
    run, best = 1, 1
    for i in range(1, len(days)):
        run = run + 1 if days[i] - days[i-1] == timedelta(days=1) else 1
        best = max(best, run)
    if best >= 7:
        b = _award(student, "week_warrior")
        if b: new.append(BADGES["week_warrior"][:2])
    # per-track badges
    q_correct = (sessions.filter(track__name__icontains="quran")
                 .aggregate(s=Sum("correct"))["s"] or 0)
    if q_correct >= 50:
        b = _award(student, "quran_scholar")
        if b: new.append(BADGES["quran_scholar"][:2])
    l_correct = (sessions.filter(track__name__icontains="language")
                 .aggregate(s=Sum("correct"))["s"] or 0)
    if l_correct >= 50:
        b = _award(student, "language_star")
        if b: new.append(BADGES["language_star"][:2])
    return [{"name": n, "icon": i} for n, i in new]


def _make_questions(track, difficulty, n=QUESTIONS_PER_GAME):
    words = list(VocabWord.objects.filter(
        track=track, is_published=True))
    if len(words) < 4:
        return []
    picked = random.sample(words, min(n, len(words)))
    questions = []
    for w in picked:
        others = random.sample([x for x in words if x.id != w.id], 3)
        if difficulty == DIFF_EASY:
            options = [w.meaning_en] + [o.meaning_en for o in others]
            random.shuffle(options)
            questions.append({
                "prompt": w.arabic, "prompt_lang": "ar",
                "options": options, "answer": w.meaning_en,
                "type": "mcq",
                "example": w.example, "meaning_ur": w.meaning_ur,
            })
        elif difficulty == DIFF_MEDIUM:
            options = [w.arabic] + [o.arabic for o in others]
            random.shuffle(options)
            questions.append({
                "prompt": w.meaning_en, "prompt_lang": "en",
                "options": options, "answer": w.arabic,
                "type": "mcq",
                "example": w.example, "meaning_ur": w.meaning_ur,
            })
        else:
            questions.append({
                "prompt": w.arabic, "prompt_lang": "ar",
                "answer": w.root_letters.replace(" ", ""),
                "type": "type",
                "hint": "Root letters likhein (masalan ع ل م)",
                "example": w.example,
            })
    return questions


@login_required
def game_home(request):
    tracks = CourseTrack.objects.all()
    counts = {t.id: VocabWord.objects.filter(track=t, is_published=True).count()
              for t in tracks}
    return render(request, "vocab/game_home.html",
                  {"tracks": tracks, "counts": counts})


@login_required
def play(request, track_id, difficulty):
    track = get_object_or_404(CourseTrack, pk=track_id)
    difficulty = int(difficulty)
    if difficulty not in (DIFF_EASY, DIFF_MEDIUM, DIFF_HARD):
        difficulty = DIFF_EASY
    questions = _make_questions(track, difficulty)
    if not questions:
        return render(request, "vocab/game_home.html", {
            "tracks": CourseTrack.objects.all(), "counts": {},
            "error": "Is track mein abhi alfaz nahi hain."})
    return render(request, "vocab/play.html", {
        "track": track, "difficulty": difficulty,
        "points_per_q": POINTS[difficulty],
        "questions_json": json.dumps(questions, ensure_ascii=False),
    })


@login_required
@require_POST
def submit_game(request, track_id, difficulty):
    track = get_object_or_404(CourseTrack, pk=track_id)
    difficulty = int(difficulty)
    try:
        data = json.loads(request.body.decode("utf-8") or "{}")
    except Exception:
        return JsonResponse({"ok": False}, status=400)
    session = GameSession.objects.create(
        student=request.user, track=track, difficulty=difficulty,
        score=int(data.get("score", 0) or 0),
        correct=int(data.get("correct", 0) or 0),
        wrong=int(data.get("wrong", 0) or 0),
        best_streak=int(data.get("best_streak", 0) or 0),
    )
    new_badges = _check_badges(request.user, session)
    total = (GameSession.objects.filter(student=request.user)
             .aggregate(s=Sum("score"))["s"] or 0)
    return JsonResponse({"ok": True, "score": session.score,
                         "total_points": total, "new_badges": new_badges})


@login_required
def profile(request):
    sessions = GameSession.objects.filter(student=request.user)
    total = sessions.aggregate(s=Sum("score"))["s"] or 0
    badges = StudentBadge.objects.filter(student=request.user)
    return render(request, "vocab/profile.html", {
        "total_points": total,
        "games": sessions.count(),
        "badges": badges,
        "recent": sessions[:10],
    })


@login_required
def leaderboard(request):
    top = (User.objects
           .filter(vocab_sessions__isnull=False)
           .annotate(total=Sum("vocab_sessions__score"))
           .order_by("-total")[:20])
    return render(request, "vocab/leaderboard.html", {"top": top})
