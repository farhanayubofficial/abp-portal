from django.contrib import admin

from .models import GameSession, StudentBadge, VocabWord


@admin.register(VocabWord)
class VocabWordAdmin(admin.ModelAdmin):
    list_display = ("arabic", "meaning_en", "track", "difficulty",
                    "is_published")
    list_filter = ("track", "difficulty", "is_published")
    search_fields = ("arabic", "meaning_en")


@admin.register(GameSession)
class GameSessionAdmin(admin.ModelAdmin):
    list_display = ("student", "track", "difficulty", "score", "correct",
                    "wrong", "created_at")
    list_filter = ("track", "difficulty")


@admin.register(StudentBadge)
class StudentBadgeAdmin(admin.ModelAdmin):
    list_display = ("student", "badge_key", "awarded_at")
    list_filter = ("badge_key",)
