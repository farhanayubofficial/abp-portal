from django.contrib import admin

from .models import MazeAttempt, MazeChallenge


@admin.register(MazeChallenge)
class MazeChallengeAdmin(admin.ModelAdmin):
    list_display = ("__str__", "mode", "created_by", "is_active", "created_at")
    list_filter = ("mode", "is_active")


@admin.register(MazeAttempt)
class MazeAttemptAdmin(admin.ModelAdmin):
    list_display = ("student", "challenge", "listened_at", "completed",
                    "score")
    list_filter = ("completed",)
