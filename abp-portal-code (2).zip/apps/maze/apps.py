from django.apps import AppConfig


class MazeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.maze"
    verbose_name = "Maze Game"
