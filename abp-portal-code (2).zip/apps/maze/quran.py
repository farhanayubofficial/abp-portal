"""Full Quran data access (6236 ayahs, bundled JSON)."""

import json
from functools import lru_cache
from pathlib import Path

DATA_PATH = Path(__file__).parent / "data" / "quran.json"


@lru_cache(maxsize=1)
def _data():
    with open(DATA_PATH, encoding="utf-8") as f:
        return json.load(f)


def surah_list():
    """[(number, arabic_name, ayah_count), ...]"""
    return [(s["number"], s["name"], len(s["verses"]))
            for s in _data()["surahs"]]


def surah(surah_no):
    for s in _data()["surahs"]:
        if s["number"] == surah_no:
            return s
    return None


def get_ayah(surah_no, ayah_no):
    s = surah(surah_no)
    if not s:
        return None
    for v in s["verses"]:
        if v["n"] == ayah_no:
            return v["text"]
    return None


def ayah_words(surah_no, ayah_no):
    text = get_ayah(surah_no, ayah_no)
    return text.split() if text else []


def qari_audio_url(surah_no, ayah_no):
    """Free per-ayah recitation (Mishary Alafasy, EveryAyah)."""
    return (f"https://everyayah.com/data/Alafasy_128kbps/"
            f"{surah_no:03d}{ayah_no:03d}.mp3")
