"""Verified maze layouts (15x10). Every word is reachable from start."""

COLS, ROWS = 15, 10


def _rect(x0, y0, x1, y1):
    return [(x, y) for x in range(x0, x1 + 1) for y in range(y0, y1 + 1)]


LAYOUTS = [
    {
        "walls": _rect(4, 1, 4, 7) + _rect(10, 2, 10, 8) + _rect(2, 8, 5, 8),
        "words": [(1, 1), (13, 1), (7, 8), (1, 8), (7, 4), (13, 5)],
        "start": (7, 0),
    },
    {
        "walls": _rect(2, 2, 8, 2) + _rect(6, 7, 12, 7) + _rect(11, 3, 11, 6),
        "words": [(1, 5), (13, 8), (7, 0), (13, 4), (4, 8), (1, 1)],
        "start": (7, 5),
    },
    {
        "walls": _rect(6, 0, 6, 4) + _rect(6, 6, 6, 9) + _rect(0, 5, 4, 5) + _rect(9, 4, 13, 4),
        "words": [(2, 2), (12, 2), (2, 8), (12, 8), (7, 5), (4, 6)],
        "start": (7, 0),
    },
]

WORDS_PER_ROUND = 6
