from django.urls import path

from . import views

app_name = "maze"

urlpatterns = [
    path("", views.home, name="home"),
    path("library/", views.library, name="library"),
    path("library/<int:surah_no>/", views.surah_detail, name="surah"),
    path("create/", views.create, name="create"),
    path("challenge/<int:pk>/", views.detail, name="detail"),
    path("challenge/<int:pk>/toggle/", views.toggle_active, name="toggle"),
    path("play/<int:pk>/", views.play, name="play"),
]
