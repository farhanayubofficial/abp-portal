"""Maze Game views: teacher library + challenges, student listen-once + maze."""

import json
import random

from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator
from django.db.models import Max
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_POST

from apps.accounts.models import User
from apps.sentences.models import Sentence

from . import quran
from .layouts import LAYOUTS, WORDS_PER_ROUND
from .models import MazeAttempt, MazeChallenge

TEACHER_ROLES = (User.ROLE_ADMIN, User.ROLE_TEACHER)


def _is_teacher(user):
    return user.is_authenticated and user.role in TEACHER_ROLES


@login_required
def home(request):
    if _is_teacher(request.user):
        challenges = MazeChallenge.objects.filter(
            created_by=request.user).prefetch_related("students")
        return render(request, "maze/teacher_home.html",
                      {"challenges": challenges})
    assigned = MazeChallenge.objects.filter(
        students=request.user, is_active=True)
    attempts = MazeAttempt.objects.filter(
        student=request.user).select_related("challenge")[:10]
    best = MazeAttempt.objects.filter(
        student=request.user).aggregate(b=Max("score"))["b"] or 0
    return render(request, "maze/student_home.html",
                  {"assigned": assigned, "attempts": attempts, "best": best})


# ---------- Teacher: Quran library ----------

@login_required
def library(request):
    if not _is_teacher(request.user):
        return redirect("maze:home")
    return render(request, "maze/library.html",
                  {"surahs": quran.surah_list()})


@login_required
def surah_detail(request, surah_no):
    if not _is_teacher(request.user):
        return redirect("maze:home")
    s = quran.surah(surah_no)
    if not s:
        return redirect("maze:library")
    verses = [{"n": v["n"], "text": v["text"],
               "words": len(v["text"].split())} for v in s["verses"]]
    return render(request, "maze/surah.html",
                  {"surah": s, "verses": verses})


@login_required
def create(request):
    """Teacher creates a challenge: quran (surah+ayah) or lang (sentence)."""
    if not _is_teacher(request.user):
        return redirect("maze:home")
    if request.method == "POST":
        mode = request.POST.get("mode", MazeChallenge.MODE_QURAN)
        ch = MazeChallenge(mode=mode, created_by=request.user,
                           layout=random.randrange(len(LAYOUTS)))
        if mode == MazeChallenge.MODE_QURAN:
            ch.surah_number = int(request.POST.get("surah") or 0)
            ch.ayah_number = int(request.POST.get("ayah") or 0)
            if not quran.get_ayah(ch.surah_number, ch.ayah_number):
                return redirect("maze:library")
        else:
            ch.sentence_id = int(request.POST.get("sentence") or 0)
            if not ch.sentence_id:
                return redirect("maze:create")
        if request.FILES.get("teacher_audio"):
            ch.teacher_audio = request.FILES["teacher_audio"]
        ch.save()
        ids = request.POST.getlist("students")
        if ids:
            ch.students.set(User.objects.filter(id__in=ids,
                                                role=User.ROLE_STUDENT))
        return redirect("maze:detail", pk=ch.pk)
    students = User.objects.filter(role=User.ROLE_STUDENT,
                                   is_active=True).order_by("first_name")
    sentences = Sentence.objects.filter(is_published=True)
    pre = {"surah": request.GET.get("surah", ""),
           "ayah": request.GET.get("ayah", "")}
    return render(request, "maze/create.html",
                  {"students": students, "sentences": sentences, "pre": pre})


@login_required
def detail(request, pk):
    ch = get_object_or_404(MazeChallenge, pk=pk)
    if not _is_teacher(request.user) or ch.created_by != request.user:
        return redirect("maze:home")
    attempts = ch.attempts.select_related("student")
    return render(request, "maze/detail.html",
                  {"ch": ch, "attempts": attempts,
                   "words": ch.words()})


@login_required
@require_POST
def toggle_active(request, pk):
    ch = get_object_or_404(MazeChallenge, pk=pk)
    if _is_teacher(request.user) and ch.created_by == request.user:
        ch.is_active = not ch.is_active
        ch.save()
    return redirect("maze:detail", pk=pk)


# ---------- Student: listen once + maze ----------

@login_required
def play(request, pk):
    ch = get_object_or_404(MazeChallenge, pk=pk, is_active=True)
    if request.user not in ch.students.all():
        return redirect("maze:home")
    attempt, _ = MazeAttempt.objects.get_or_create(
        student=request.user, challenge=ch,
        defaults={"completed": False})
    words = ch.words()
    if request.method == "POST":
        action = request.POST.get("action")
        payload = {}
        if not action:
            try:
                payload = json.loads(request.body.decode("utf-8") or "{}")
            except Exception:
                payload = {}
            action = payload.get("action")
        if action == "listened" and not attempt.listened_at:
            attempt.listened_at = timezone.now()
            attempt.save()
            return JsonResponse({"ok": True})
        if action == "submit":
            data = payload or {}
            # server-side sanity caps
            attempt.score = max(0, min(int(data.get("score", 0) or 0), 99999))
            attempt.lives_left = int(data.get("lives_left", 0) or 0)
            attempt.rounds_done = int(data.get("rounds_done", 0) or 0)
            attempt.completed = bool(data.get("completed", False))
            attempt.save()
            return JsonResponse({"ok": True})
        return JsonResponse({"ok": False}, status=400)

    listened = bool(attempt.listened_at)
    audio_url = None
    if not listened:
        # audio is served ONLY before first listen
        if ch.teacher_audio:
            audio_url = ch.teacher_audio.url
            audio_kind = "teacher"
        elif ch.mode == MazeChallenge.MODE_QURAN:
            audio_url = quran.qari_audio_url(ch.surah_number, ch.ayah_number)
            audio_kind = "qari"
        else:
            audio_url = None  # language: browser TTS
            audio_kind = "tts"
    else:
        audio_kind = None
    # NEVER expose the full text to the student
    layout = LAYOUTS[ch.layout % len(LAYOUTS)]
    maze_cfg = {
        "words": words,
        "walls": layout["walls"],
        "word_pos": layout["words"],
        "start": layout["start"],
        "per_round": WORDS_PER_ROUND,
        "mode": ch.mode,
    } if listened else None
    return render(request, "maze/play.html", {
        "ch": ch, "attempt": attempt, "listened": listened,
        "audio_url": audio_url, "audio_kind": audio_kind,
        "maze_cfg_json": json.dumps(maze_cfg, ensure_ascii=False) if maze_cfg else "null",
        "sentence_text": (ch.sentence.arabic if ch.sentence else "") if not listened else "",
    })
