"""Maze Game: listen once (teacher's permission), then collect words in order
through a walled maze.

- Quran mode: noorani child, ayah words, noor grows.
- Language mode: snake, sentence words.
The student NEVER sees the full ayah/sentence text — only hears it once.
"""

from django.conf import settings
from django.db import models


class MazeChallenge(models.Model):
    MODE_QURAN = "quran"
    MODE_LANG = "lang"
    MODES = [(MODE_QURAN, "Quranic Arabic"), (MODE_LANG, "Language Arabic")]

    mode = models.CharField(max_length=10, choices=MODES, default=MODE_QURAN)
    surah_number = models.PositiveIntegerField(null=True, blank=True)
    ayah_number = models.PositiveIntegerField(null=True, blank=True)
    sentence = models.ForeignKey(
        "sentences.Sentence", null=True, blank=True,
        on_delete=models.SET_NULL, related_name="maze_challenges")
    teacher_audio = models.FileField(
        upload_to="maze_teacher_audio/", null=True, blank=True)
    layout = models.PositiveIntegerField(default=0)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="maze_challenges")
    students = models.ManyToManyField(
        settings.AUTH_USER_MODEL, related_name="maze_assigned", blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        if self.mode == self.MODE_QURAN:
            return f"Quran {self.surah_number}:{self.ayah_number}"
        return f"Lang: {self.sentence}"

    def words(self):
        from .quran import ayah_words
        if self.mode == self.MODE_QURAN:
            return ayah_words(self.surah_number or 0, self.ayah_number or 0)
        return self.sentence.words() if self.sentence else []

    def label(self):
        from .quran import surah
        if self.mode == self.MODE_QURAN:
            s = surah(self.surah_number or 0)
            name = s["name"] if s else ""
            return f"Surah {name} ({self.surah_number}:{self.ayah_number})"
        return self.sentence.english if self.sentence else ""


class MazeAttempt(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="maze_attempts")
    challenge = models.ForeignKey(
        MazeChallenge, on_delete=models.CASCADE, related_name="attempts")
    listened_at = models.DateTimeField(null=True, blank=True)
    completed = models.BooleanField(default=False)
    score = models.PositiveIntegerField(default=0)
    lives_left = models.PositiveIntegerField(default=0)
    rounds_done = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} — {self.challenge} — {self.score}"
