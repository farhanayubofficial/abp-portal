"""Maze Game tests (Phase 14)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User
from apps.sentences.models import Sentence

from .models import MazeAttempt, MazeChallenge


def make_user(email, role):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U", role=role)


class MazeTests(TestCase):
    def setUp(self):
        self.teacher = make_user("t@x.com", User.ROLE_TEACHER)
        self.student = make_user("s@x.com", User.ROLE_STUDENT)
        self.ch = MazeChallenge.objects.create(
            mode=MazeChallenge.MODE_QURAN, surah_number=112, ayah_number=1,
            created_by=self.teacher, layout=0)
        self.ch.students.add(self.student)

    def test_quran_data(self):
        from .quran import ayah_words, get_ayah, qari_audio_url, surah_list
        self.assertEqual(len(surah_list()), 114)
        self.assertTrue(get_ayah(112, 1))
        self.assertTrue(len(ayah_words(112, 1)) >= 2)
        self.assertIn("112001.mp3", qari_audio_url(112, 1))

    def test_layouts_reachable(self):
        from collections import deque
        from .layouts import COLS, LAYOUTS, ROWS
        for L in LAYOUTS:
            W = set(L["walls"])
            seen = {L["start"]}
            q = deque([L["start"]])
            while q:
                x, y = q.popleft()
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if (0 <= nx < COLS and 0 <= ny < ROWS
                            and (nx, ny) not in W and (nx, ny) not in seen):
                        seen.add((nx, ny))
                        q.append((nx, ny))
            for wp in L["words"]:
                self.assertIn(wp, seen)

    def test_teacher_library(self):
        self.client.force_login(self.teacher)
        r = self.client.get(reverse("maze:library"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Quran Library")

    def test_student_cannot_see_library(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("maze:library"))
        self.assertEqual(r.status_code, 302)

    def test_play_hides_ayah_text_before_and_after_listen(self):
        self.client.force_login(self.student)
        url = reverse("maze:play", args=[self.ch.pk])
        r = self.client.get(url)
        self.assertEqual(r.status_code, 200)
        # audio served before listen
        self.assertContains(r, "112001.mp3")
        # mark listened
        r = self.client.post(url, {"action": "listened"})
        self.assertTrue(r.json()["ok"])
        r = self.client.get(url)
        # after listen: no audio url, no full ayah text anywhere
        self.assertNotContains(r, "112001.mp3")
        from .quran import get_ayah
        full = get_ayah(112, 1)
        self.assertNotContains(r, full)

    def test_listen_once_enforced(self):
        self.client.force_login(self.student)
        url = reverse("maze:play", args=[self.ch.pk])
        self.client.post(url, {"action": "listened"})
        a = MazeAttempt.objects.get()
        first = a.listened_at
        self.client.post(url, {"action": "listened"})
        a.refresh_from_db()
        self.assertEqual(a.listened_at, first)

    def test_submit_score(self):
        self.client.force_login(self.student)
        url = reverse("maze:play", args=[self.ch.pk])
        self.client.post(url, {"action": "listened"})
        r = self.client.post(
            url, json.dumps({"action": "submit", "score": 120,
                             "lives_left": 2, "rounds_done": 1,
                             "completed": True}),
            content_type="application/json")
        self.assertTrue(r.json()["ok"])
        a = MazeAttempt.objects.get()
        self.assertEqual(a.score, 120)
        self.assertTrue(a.completed)

    def test_unassigned_student_blocked(self):
        other = make_user("o@x.com", User.ROLE_STUDENT)
        self.client.force_login(other)
        r = self.client.get(reverse("maze:play", args=[self.ch.pk]))
        self.assertEqual(r.status_code, 302)

    def test_lang_challenge_words(self):
        s = Sentence.objects.create(arabic="الولد يقرأ الكتاب",
                                    is_published=True)
        ch = MazeChallenge.objects.create(
            mode=MazeChallenge.MODE_LANG, sentence=s,
            created_by=self.teacher)
        self.assertEqual(ch.words(), ["الولد", "يقرأ", "الكتاب"])
