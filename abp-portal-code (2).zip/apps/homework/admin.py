from django.contrib import admin

from .models import Homework, Submission


class SubmissionInline(admin.TabularInline):
    model = Submission
    extra = 0
    readonly_fields = ["submitted_at"]


@admin.register(Homework)
class HomeworkAdmin(admin.ModelAdmin):
    list_display = ["title", "track", "homework_type", "status", "due_date", "max_marks"]
    list_filter = ["status", "homework_type", "track"]
    inlines = [SubmissionInline]


@admin.register(Submission)
class SubmissionAdmin(admin.ModelAdmin):
    list_display = ["homework", "student", "status", "marks", "is_late", "submitted_at"]
    list_filter = ["status", "is_late"]
