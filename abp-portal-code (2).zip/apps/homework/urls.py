from django.urls import path

from . import views

app_name = "homework"

urlpatterns = [
    path("", views.HomeworkListView.as_view(), name="homework_list"),
    path("create/", views.HomeworkCreateView.as_view(), name="homework_create"),
    path("grades/", views.MyGradesView.as_view(), name="my_grades"),
    path("<int:pk>/", views.HomeworkDetailView.as_view(), name="homework_detail"),
    path("<int:pk>/submit/", views.SubmitHomeworkView.as_view(), name="homework_submit"),
    path("submission/<int:sub_pk>/grade/", views.GradeSubmissionView.as_view(), name="grade_submission"),
]
