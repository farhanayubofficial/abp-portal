"""Phase 5 tests: homework create, submit, grade, permissions."""

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.utils import timezone

from apps.courses.models import CourseTrack

from .models import Homework, Submission

User = get_user_model()


class Phase5Tests(TestCase):
    def setUp(self):
        self.teacher = User.objects.create_user(email="hw_teacher@abp.test", password="x", role="teacher")
        self.student = User.objects.create_user(email="hw_student@abp.test", password="x", role="student")
        self.admin = User.objects.create_user(email="hw_admin@abp.test", password="x", role="admin")
        self.track = CourseTrack.objects.create(code="hw", name="HW Track")
        # enroll student
        from apps.accounts.models import StudentProfile
        self.profile = StudentProfile.objects.create(user=self.student, student_id="HW001")
        self.profile.tracks.add(self.track)
        self.hw = Homework.objects.create(
            track=self.track, title="Write 5 sentences", instructions="Use new words.",
            homework_type="written", max_marks=10, status="published", created_by=self.teacher,
        )
        self.draft = Homework.objects.create(
            track=self.track, title="Draft HW", instructions="...", status="draft",
            created_by=self.teacher,
        )

    def test_teacher_can_create_homework(self):
        self.client.force_login(self.teacher)
        r = self.client.post("/homework/create/", {
            "track": self.track.pk, "title": "New HW", "instructions": "Do it.",
            "homework_type": "speaking", "max_marks": "20", "status": "published",
        })
        self.assertEqual(r.status_code, 302)
        hw = Homework.objects.get(title="New HW")
        self.assertEqual(hw.homework_type, "speaking")
        self.assertEqual(hw.max_marks, 20)

    def test_student_cannot_create_homework(self):
        self.client.force_login(self.student)
        r = self.client.get("/homework/create/")
        self.assertEqual(r.status_code, 403)

    def test_student_sees_only_published(self):
        self.client.force_login(self.student)
        r = self.client.get("/homework/")
        self.assertContains(r, "Write 5 sentences")
        self.assertNotContains(r, "Draft HW")

    def test_student_submit_and_resubmit(self):
        self.client.force_login(self.student)
        r = self.client.post(f"/homework/{self.hw.pk}/submit/", {"text_answer": "my answer"})
        self.assertEqual(r.status_code, 302)
        sub = Submission.objects.get(homework=self.hw, student=self.student)
        self.assertEqual(sub.text_answer, "my answer")
        # resubmit updates (no duplicate)
        self.client.post(f"/homework/{self.hw.pk}/submit/", {"text_answer": "better answer"})
        self.assertEqual(Submission.objects.filter(homework=self.hw, student=self.student).count(), 1)
        sub.refresh_from_db()
        self.assertEqual(sub.text_answer, "better answer")

    def test_late_submission_flagged(self):
        self.hw.due_date = timezone.now() - timezone.timedelta(days=1)
        self.hw.save()
        self.client.force_login(self.student)
        self.client.post(f"/homework/{self.hw.pk}/submit/", {"text_answer": "late"})
        sub = Submission.objects.get(homework=self.hw, student=self.student)
        self.assertTrue(sub.is_late)

    def test_teacher_grades_submission(self):
        sub = Submission.objects.create(homework=self.hw, student=self.student, text_answer="ans")
        self.client.force_login(self.teacher)
        r = self.client.post(f"/homework/submission/{sub.pk}/grade/", {"marks": "8", "feedback": "Good!"})
        self.assertEqual(r.status_code, 302)
        sub.refresh_from_db()
        self.assertEqual(sub.status, "graded")
        self.assertEqual(sub.marks, 8)
        self.assertEqual(sub.feedback, "Good!")

    def test_marks_capped_at_max(self):
        sub = Submission.objects.create(homework=self.hw, student=self.student, text_answer="ans")
        self.client.force_login(self.teacher)
        self.client.post(f"/homework/submission/{sub.pk}/grade/", {"marks": "999", "feedback": ""})
        sub.refresh_from_db()
        self.assertEqual(sub.marks, 10)

    def test_student_cannot_grade(self):
        sub = Submission.objects.create(homework=self.hw, student=self.student, text_answer="ans")
        self.client.force_login(self.student)
        r = self.client.get(f"/homework/submission/{sub.pk}/grade/")
        self.assertEqual(r.status_code, 403)

    def test_my_grades_page(self):
        Submission.objects.create(homework=self.hw, student=self.student, text_answer="ans",
                                  status="graded", marks=9)
        self.client.force_login(self.student)
        r = self.client.get("/homework/grades/")
        self.assertContains(r, "9/10")

    def test_dashboard_widgets(self):
        Submission.objects.create(homework=self.hw, student=self.student, text_answer="ans")
        self.client.force_login(self.teacher)
        r = self.client.get("/accounts/dashboard/")
        self.assertContains(r, "Submissions to Grade")
        self.client.force_login(self.student)
        r = self.client.get("/accounts/dashboard/")
        self.assertContains(r, "Pending Homework")

    def test_requires_login(self):
        r = self.client.get("/homework/")
        self.assertEqual(r.status_code, 302)
