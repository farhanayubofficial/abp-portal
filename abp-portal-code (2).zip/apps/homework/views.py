"""Phase 5 views: teacher creates homework + grades; student submits + sees grades."""

from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.generic import DetailView, ListView

from .models import Homework, Submission


class StaffRequiredMixin(UserPassesTestMixin):
    def test_func(self):
        u = self.request.user
        return u.is_authenticated and (u.is_teacher or u.is_admin)


def _student_tracks(user):
    try:
        return user.student_profile.tracks.all()
    except Exception:
        return []


class HomeworkListView(LoginRequiredMixin, ListView):
    """Students: published homework for their tracks. Staff: all homework."""

    model = Homework
    template_name = "homework/homework_list.html"
    context_object_name = "homeworks"

    def get_queryset(self):
        qs = Homework.objects.select_related("track", "lesson").order_by("-created_at")
        u = self.request.user
        if u.is_teacher or u.is_admin:
            return qs[:50]
        tracks = _student_tracks(u)
        if tracks:
            qs = qs.filter(track__in=tracks)
        return qs.filter(status=Homework.STATUS_PUBLISHED)[:50]

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        u = self.request.user
        if not (u.is_teacher or u.is_admin):
            submitted = set(
                Submission.objects.filter(student=u).values_list("homework_id", flat=True)
            )
            ctx["submitted_ids"] = submitted
        return ctx


class HomeworkDetailView(LoginRequiredMixin, DetailView):
    model = Homework
    template_name = "homework/homework_detail.html"
    context_object_name = "homework"

    def get_queryset(self):
        qs = super().get_queryset()
        u = self.request.user
        if not (u.is_teacher or u.is_admin):
            qs = qs.filter(status=Homework.STATUS_PUBLISHED)
        return qs

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        u = self.request.user
        hw = self.object
        if u.is_teacher or u.is_admin:
            ctx["submissions"] = hw.submissions.select_related("student").order_by("-submitted_at")
        else:
            ctx["my_submission"] = hw.submissions.filter(student=u).first()
        return ctx


class HomeworkCreateView(StaffRequiredMixin, ListView):
    """Teacher: create homework (GET form, POST creates)."""

    template_name = "homework/create.html"

    def get(self, request):
        from apps.courses.models import CourseTrack

        return render(request, self.template_name, {"tracks": CourseTrack.objects.all()})

    def post(self, request):
        from apps.courses.models import CourseTrack

        track = get_object_or_404(CourseTrack, pk=request.POST.get("track"))
        hw = Homework.objects.create(
            track=track,
            title=request.POST.get("title", "").strip(),
            instructions=request.POST.get("instructions", "").strip(),
            homework_type=request.POST.get("homework_type", Homework.TYPE_WRITTEN),
            max_marks=int(request.POST.get("max_marks") or 10),
            due_date=request.POST.get("due_date") or None,
            status=request.POST.get("status", Homework.STATUS_DRAFT),
            created_by=request.user,
        )
        messages.success(request, f"Homework '{hw.title}' created.")
        # Phase 7: if published, notify enrolled students of the track
        if hw.status == Homework.STATUS_PUBLISHED:
            from apps.accounts.models import StudentProfile
            from apps.notifications.models import homework_url, notify_many, Notification
            students = [p.user for p in StudentProfile.objects.filter(
                tracks=track, is_enrolled=True).select_related("user")]
            notify_many(students, f"New homework: {hw.title}",
                        f"{track.name} — due {hw.due_date.strftime('%d %b')}" if hw.due_date else track.name,
                        homework_url(hw.pk), Notification.TYPE_HOMEWORK)
        return redirect("homework:homework_detail", pk=hw.pk)

    # ListView requires a queryset; we only use it for the mixin chain.
    def get_queryset(self):
        return Homework.objects.none()


class SubmitHomeworkView(LoginRequiredMixin, DetailView):
    """Student: submit text and/or file. One submission per student (resubmit updates)."""

    model = Homework
    template_name = "homework/submit.html"
    context_object_name = "homework"

    def get_queryset(self):
        return super().get_queryset().filter(status=Homework.STATUS_PUBLISHED)

    def post(self, request, pk):
        hw = self.get_object()
        sub, _ = Submission.objects.get_or_create(homework=hw, student=request.user)
        sub.text_answer = request.POST.get("text_answer", "").strip()
        if request.FILES.get("file"):
            sub.file = request.FILES["file"]
        sub.is_late = hw.is_overdue
        if sub.status == Submission.STATUS_GRADED:
            sub.status = Submission.STATUS_SUBMITTED  # resubmit after grading reopens it
            sub.marks = None
        sub.save()
        messages.success(request, "Homework submitted." + (" (late)" if sub.is_late else ""))
        return redirect("homework:homework_detail", pk=hw.pk)


class GradeSubmissionView(StaffRequiredMixin, DetailView):
    """Teacher: grade one submission (GET form, POST saves marks + feedback)."""

    model = Submission
    template_name = "homework/grade.html"
    context_object_name = "submission"
    pk_url_kwarg = "sub_pk"

    def post(self, request, sub_pk):
        sub = self.get_object()
        try:
            marks = int(request.POST.get("marks") or 0)
        except ValueError:
            marks = 0
        marks = max(0, min(marks, sub.homework.max_marks))
        sub.marks = marks
        sub.feedback = request.POST.get("feedback", "").strip()
        sub.status = Submission.STATUS_GRADED
        sub.graded_by = request.user
        sub.graded_at = timezone.now()
        sub.save()
        # Phase 7: notify the student
        from apps.notifications.models import homework_url, notify, Notification
        notify(sub.student, f"Graded: {sub.homework.title}",
               f"You got {marks}/{sub.homework.max_marks}",
               homework_url(sub.homework.pk), Notification.TYPE_GRADE)
        messages.success(request, f"Graded: {marks}/{sub.homework.max_marks}")
        return redirect("homework:homework_detail", pk=sub.homework.pk)


class MyGradesView(LoginRequiredMixin, ListView):
    """Student: all graded submissions."""

    template_name = "homework/my_grades.html"
    context_object_name = "submissions"

    def get_queryset(self):
        return (
            Submission.objects.filter(student=self.request.user)
            .select_related("homework", "homework__track")
            .order_by("-graded_at")
        )
