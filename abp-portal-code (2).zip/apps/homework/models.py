"""Phase 5 — Homework & Tests. All free: text/file submissions, teacher grading."""

from django.conf import settings
from django.db import models
from django.utils import timezone


class Homework(models.Model):
    """An assignment created by a teacher. Draft until published."""

    STATUS_DRAFT = "draft"
    STATUS_PUBLISHED = "published"
    STATUS_CHOICES = [
        (STATUS_DRAFT, "Draft"),
        (STATUS_PUBLISHED, "Published"),
    ]

    TYPE_WRITTEN = "written"
    TYPE_SPEAKING = "speaking"
    TYPE_LISTENING = "listening"
    TYPE_CHOICES = [
        (TYPE_WRITTEN, "Written"),
        (TYPE_SPEAKING, "Speaking (audio submission)"),
        (TYPE_LISTENING, "Listening"),
    ]

    track = models.ForeignKey(
        "courses.CourseTrack", on_delete=models.CASCADE, related_name="homeworks"
    )
    lesson = models.ForeignKey(
        "courses.Lesson", on_delete=models.SET_NULL, null=True, blank=True,
        related_name="homeworks", help_text="Optional: link to a lesson.",
    )
    title = models.CharField(max_length=200)
    instructions = models.TextField()
    homework_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default=TYPE_WRITTEN)
    due_date = models.DateTimeField(null=True, blank=True)
    max_marks = models.PositiveIntegerField(default=10)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_DRAFT)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True,
        related_name="created_homeworks",
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.title} ({self.track.name})"

    @property
    def is_overdue(self):
        return bool(self.due_date and timezone.now() > self.due_date)


class Submission(models.Model):
    """A student's answer to a homework. One per student per homework."""

    STATUS_SUBMITTED = "submitted"
    STATUS_GRADED = "graded"
    STATUS_CHOICES = [
        (STATUS_SUBMITTED, "Submitted"),
        (STATUS_GRADED, "Graded"),
    ]

    homework = models.ForeignKey(Homework, on_delete=models.CASCADE, related_name="submissions")
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="submissions"
    )
    text_answer = models.TextField(blank=True)
    file = models.FileField(upload_to="homework_submissions/", blank=True, null=True,
                            help_text="Optional file or audio recording.")
    submitted_at = models.DateTimeField(auto_now_add=True)
    is_late = models.BooleanField(default=False)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_SUBMITTED)
    marks = models.PositiveIntegerField(null=True, blank=True)
    feedback = models.TextField(blank=True)
    graded_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="graded_submissions",
    )
    graded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = [("homework", "student")]
        ordering = ["-submitted_at"]

    def __str__(self):
        return f"{self.student.email} — {self.homework.title}"
