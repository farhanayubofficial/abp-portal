from django.urls import path

from . import views

app_name = "snake"

urlpatterns = [
    path("", views.home, name="home"),
    path("play/<str:kind>/<int:level>/", views.play, name="play"),
    path("submit/<str:kind>/<int:level>/", views.submit, name="submit"),
]
