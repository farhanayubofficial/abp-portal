from django.contrib import admin

from .models import SnakeRun, SnakeSentence


@admin.register(SnakeSentence)
class SnakeSentenceAdmin(admin.ModelAdmin):
    list_display = ("arabic", "kind", "level", "source", "is_active")
    list_filter = ("kind", "level", "is_active")
    search_fields = ("arabic",)


@admin.register(SnakeRun)
class SnakeRunAdmin(admin.ModelAdmin):
    list_display = ("student", "kind", "level", "score", "completed",
                    "created_at")
    list_filter = ("kind", "level", "completed")
