"""Snake Levels tests (Phase 15)."""

import json

from django.test import TestCase
from django.urls import reverse

from apps.accounts.models import User

from .models import KIND_LANG, KIND_QURAN, SnakeRun, SnakeSentence


def make_user(email):
    return User.objects.create_user(
        email=email, password="x", first_name="T", last_name="U",
        role=User.ROLE_STUDENT)


class SnakeTests(TestCase):
    def setUp(self):
        self.student = make_user("s@x.com")
        self.s1 = SnakeSentence.objects.create(
            arabic="الولد يلعب", english="The boy plays.",
            kind=KIND_LANG, level=1, source="Practice")
        self.s2 = SnakeSentence.objects.create(
            arabic="البنت تلعب", english="The girl plays.",
            kind=KIND_LANG, level=1, source="Practice")

    def test_home(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("snake:home"))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "10 Levels")

    def test_play_ok(self):
        self.client.force_login(self.student)
        r = self.client.get(reverse("snake:play",
                                    args=[KIND_LANG, 1]))
        self.assertEqual(r.status_code, 200)
        self.assertContains(r, "Level 1")

    def test_no_repeat_until_exhausted(self):
        from .views import _pick_sentence
        first = _pick_sentence(self.student, KIND_LANG, 1)
        SnakeRun.objects.create(
            student=self.student, kind=KIND_LANG, level=1,
            sentence=first, score=10, completed=True)
        second = _pick_sentence(self.student, KIND_LANG, 1)
        self.assertIsNotNone(second)
        self.assertNotEqual(first.pk, second.pk)
        # exhaust pool -> resets
        SnakeRun.objects.create(
            student=self.student, kind=KIND_LANG, level=1,
            sentence=second, score=10, completed=True)
        third = _pick_sentence(self.student, KIND_LANG, 1)
        self.assertIsNotNone(third)

    def test_submit(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("snake:submit", args=[KIND_LANG, 1]),
            json.dumps({"sentence_id": self.s1.pk, "score": 80,
                        "completed": True}),
            content_type="application/json")
        self.assertTrue(r.json()["ok"])
        run = SnakeRun.objects.get()
        self.assertEqual(run.score, 80)
        self.assertTrue(run.completed)

    def test_submit_wrong_sentence_rejected(self):
        self.client.force_login(self.student)
        r = self.client.post(
            reverse("snake:submit", args=[KIND_QURAN, 1]),
            json.dumps({"sentence_id": self.s1.pk, "score": 80}),
            content_type="application/json")
        self.assertEqual(r.status_code, 400)

    def test_seed_levels_present(self):
        # seed migration ran in test DB too
        for lvl in range(1, 11):
            self.assertTrue(
                SnakeSentence.objects.filter(
                    kind=KIND_LANG, level=lvl).exists(),
                f"lang L{lvl} empty")
            self.assertTrue(
                SnakeSentence.objects.filter(
                    kind=KIND_QURAN, level=lvl).exists(),
                f"quran L{lvl} empty")
