"""Snake Levels Game: 10 levels, sentences from the student's books.

- Language track: sentences from reading books / exercises / practice.
- Quran track: ayahs grouped by difficulty (word count).
- No repeats: a replay picks a sentence the student hasn't played yet
  at that level (pool resets only when exhausted).
"""

from django.conf import settings
from django.db import models

KIND_LANG = "lang"
KIND_QURAN = "quran"
KINDS = [(KIND_LANG, "Language Arabic"), (KIND_QURAN, "Quranic Arabic")]

# level -> (min_words, max_words) for language sentences
LEVEL_BANDS = {
    1: (2, 2), 2: (3, 3), 3: (3, 4), 4: (4, 4), 5: (4, 5),
    6: (5, 6), 7: (6, 6), 8: (6, 7), 9: (7, 8), 10: (8, 99),
}


def level_for_quran(word_count):
    if word_count <= 4:
        return "easy"
    if word_count <= 7:
        return "medium"
    return "hard"


class SnakeSentence(models.Model):
    arabic = models.TextField()
    english = models.CharField(max_length=300, blank=True)
    kind = models.CharField(max_length=10, choices=KINDS, default=KIND_LANG)
    level = models.PositiveIntegerField(default=1)
    source = models.CharField(max_length=100, blank=True,
                              help_text="Book / origin label")
    surah_number = models.PositiveIntegerField(null=True, blank=True)
    ayah_number = models.PositiveIntegerField(null=True, blank=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["kind", "level", "id"]

    def __str__(self):
        return f"L{self.level} [{self.kind}] {self.arabic[:40]}"

    def words(self):
        return self.arabic.split()


class SnakeRun(models.Model):
    student = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE,
        related_name="snake_runs")
    kind = models.CharField(max_length=10, choices=KINDS, default=KIND_LANG)
    level = models.PositiveIntegerField(default=1)
    sentence = models.ForeignKey(
        SnakeSentence, on_delete=models.CASCADE, related_name="runs")
    score = models.PositiveIntegerField(default=0)
    completed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"{self.student} L{self.level} {self.score}"
