"""Seed Snake levels: book/reading sentences + leveled ayah pools."""

from django.db import migrations

# (arabic, english, level, source) — reading book, exercises, practice
LANG = [
    # --- Level 1 (2 words) ---
    ("السَّلَامُ عَلَيْكُمْ", "Peace be upon you.", 1, "Exercises"),
    ("كَيْفَ حَالُكَ؟", "How are you?", 1, "Exercises"),
    ("الْحَمْدُ لِلَّهِ", "All praise is for Allah.", 1, "Exercises"),
    ("مَا اسْمُكَ؟", "What is your name?", 1, "Exercises"),
    ("شُكْرًا لَكَ", "Thank you.", 1, "Exercises"),
    ("هذا بيتٌ", "This is a house.", 1, "Practice"),
    ("هذه سيارةٌ", "This is a car.", 1, "Practice"),
    ("هذا قلمٌ", "This is a pen.", 1, "Practice"),
    ("الولد يلعب", "The boy plays.", 1, "Practice"),
    ("البنت تلعب", "The girl plays.", 1, "Practice"),
    # --- Level 2 (3 words) ---
    ("أحب القراءة والكتابة", "I love reading and writing.", 2, "القراءة الرشيدة"),
    ("الولد يقرأ الكتاب", "The boy reads the book.", 2, "Practice"),
    ("البنت تكتب الدرس", "The girl writes the lesson.", 2, "Practice"),
    ("الرجل يكتب الدرس", "The man writes the lesson.", 2, "Practice"),
    # --- Level 3 (3-4 words) ---
    ("المعلم يشرح القاعدة", "The teacher explains the rule.", 3, "Practice"),
    ("المرأة تقرأ القرآن", "The woman reads the Quran.", 3, "Practice"),
    ("الطفل يشرب الحليب", "The child drinks milk.", 3, "Practice"),
    # --- Level 4 (4 words) ---
    ("في الصباح أستيقظ مبكرا", "In the morning I wake up early.", 4, "القراءة الرشيدة"),
    ("القرآن نور وهداية للناس", "The Quran is light and guidance.", 4, "القراءة الرشيدة"),
    ("الطالب يتعلم اللغة العربية", "The student learns Arabic.", 4, "Practice"),
    ("نحن نحب المدرسة كثيرا", "We love the school very much.", 4, "Practice"),
    ("القراءة مفيدة للعقل والقلب", "Reading benefits mind and heart.", 4, "Practice"),
    ("التلميذ يقرأ الدرس الجديد", "The pupil reads the new lesson.", 4, "Practice"),
    ("المدرس يكتب على السبورة", "The teacher writes on the board.", 4, "Practice"),
    ("نحن نتعلم اللغة العربية", "We learn the Arabic language.", 4, "Practice"),
    ("هم يلعبون في الحديقة", "They play in the garden.", 4, "Practice"),
    # --- Level 5 (4-5 words) ---
    ("أنا طالب في مدرسة عربية", "I am a student in an Arabic school.", 5, "القراءة الرشيدة"),
    ("أتعلم اللغة العربية كل يوم", "I learn Arabic every day.", 5, "القراءة الرشيدة"),
    ("ذهب محمد إلى السوق صباحا", "Muhammad went to the market in the morning.", 5, "Practice"),
    ("اللغة العربية لغة جميلة وسهلة", "Arabic is a beautiful, easy language.", 5, "Practice"),
    # --- Level 6 (5-6 words) ---
    ("أصلي الفجر ثم أتناول الفطور", "I pray Fajr then eat breakfast.", 6, "القراءة الرشيدة"),
    ("بعد ذلك أذهب إلى المدرسة", "After that I go to school.", 6, "القراءة الرشيدة"),
    ("المسلم يقرأ القرآن كل يوم", "The Muslim reads the Quran daily.", 6, "القراءة الرشيدة"),
    ("من قرأ القرآن نال الأجر", "Whoever reads the Quran earns reward.", 6, "القراءة الرشيدة"),
    ("اشرب الماء البارد في الصيف", "Drink cold water in summer.", 6, "Practice"),
    # --- Level 7 (6 words) ---
    ("العلم نور يهدي الناس إلى الحق", "Knowledge is light guiding to truth.", 7, "Practice"),
    ("قرأت البنت قصة جميلة قبل النوم", "The girl read a beautiful story before sleep.", 7, "Practice"),
    ("المعلمة تشرح الدرس بابتسامة جميلة", "The teacher explains with a beautiful smile.", 7, "Practice"),
    # --- Level 8 (6-8 words) ---
    ("يحب المسلمون قراءة القرآن الكريم كل يوم", "Muslims love reading the Noble Quran daily.", 8, "Practice"),
    ("اللغة العربية من أجمل لغات العالم كله", "Arabic is among the world's most beautiful languages.", 8, "Practice"),
    ("ذهب التلاميذ إلى المدرسة في الصباح الباكر", "The pupils went to school early in the morning.", 8, "Practice"),
    ("شربت العصير البارد بعد اللعب في الحر الشديد", "I drank cold juice after playing in severe heat.", 8, "Practice"),
    # --- Level 9 (8-9 words) ---
    ("كان الطالب المجتهد يقرأ دروسه كل مساء بانتظام", "The hardworking student read his lessons every evening regularly.", 9, "Practice"),
    ("تحب الأم أبناءها حبا كثيرا وتسهر على راحتهم", "The mother loves her children much and stays up for their comfort.", 9, "Practice"),
    ("يستيقظ الفلاح نشيطا ويذهب إلى حقله مع شروق الشمس", "The farmer wakes up active and goes to his field at sunrise.", 9, "Practice"),
    # --- Level 10 (9+ words) ---
    ("من جد واجتهد في دراسته نال النجاح والتفوق دائما", "Whoever strives in studies always attains success.", 10, "Practice"),
    ("سافر التاجر الكبير إلى بلاد بعيدة ليشتري بضاعة جديدة لمتجره", "The great merchant traveled far to buy new goods for his shop.", 10, "Practice"),
    ("الصدق من أجمل الأخلاق وهو يرفع قدر صاحبه بين الناس", "Honesty is among the finest morals; it raises one's worth.", 10, "Practice"),
]


def seed(apps, schema_editor):
    SnakeSentence = apps.get_model("snake", "SnakeSentence")
    for ar, en, level, source in LANG:
        SnakeSentence.objects.get_or_create(
            arabic=ar, kind="lang",
            defaults={"english": en, "level": level, "source": source})
    # Quran pools: 6 ayahs per level, sliced from difficulty bands
    try:
        from apps.maze.quran import _data
        surahs = _data()["surahs"]
    except Exception:
        return
    bands = {"easy": [], "medium": [], "hard": []}
    for s in surahs:
        for v in s["verses"]:
            n = len(v["text"].split())
            key = "easy" if n <= 4 else ("medium" if n <= 7 else "hard")
            if n >= 2 and (key != "hard" or n <= 12):
                bands[key].append((s["number"], s["name"], v["n"], v["text"]))
    plan = ([("easy", l) for l in range(1, 6)]
            + [("medium", l) for l in range(6, 9)]
            + [("hard", l) for l in range(9, 11)])
    used = set()
    for band, level in plan:
        picked = 0
        for sn, sname, an, text in bands[band]:
            if (sn, an) in used:
                continue
            used.add((sn, an))
            SnakeSentence.objects.get_or_create(
                arabic=text, kind="quran",
                defaults={"english": f"Surah {sname} ({sn}:{an})",
                          "level": level, "source": "Quran",
                          "surah_number": sn, "ayah_number": an})
            picked += 1
            if picked >= 6:
                break


class Migration(migrations.Migration):
    dependencies = [("snake", "0001_initial")]
    operations = [migrations.RunPython(seed, migrations.RunPython.noop)]
