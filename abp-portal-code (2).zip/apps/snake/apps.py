from django.apps import AppConfig


class SnakeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.snake"
    verbose_name = "Snake Levels Game"
