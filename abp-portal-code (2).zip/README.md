# Arabic Bridge Program (ABP)

Online learning management platform for an international online Arabic academy.
Founder: Farhan Khan.

## Quick start (development)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # then fill in your values
python manage.py migrate
python manage.py createsuperuser   # first central administrator
python manage.py runserver
```

Open http://127.0.0.1:8000/

## Project layout

```
arabic-bridge-program/
├── branding/            # Logo SVGs, favicon, BRANDING.md (brand source of truth)
├── docs/                # Architecture proposal, roadmap, phase notes
├── apps/                # Django apps (one per domain: accounts, courses, ...)
├── config/              # Django project settings / URLs / WSGI
├── manage.py
├── requirements.txt
├── .env.example         # Copy to .env — never commit real secrets
└── README.md
```

## Rules (from project spec)

- One phase at a time; summarize + test + get owner approval before the next.
- Never commit secrets, API keys, or `.env` to source control.
- No fake integrations presented as live; label dev demos clearly.
- Multi-currency fees: USD and PKR.
