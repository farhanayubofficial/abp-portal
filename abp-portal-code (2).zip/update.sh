#!/bin/bash
# ABP Portal — one-command updater (PythonAnywhere)
# Usage: bash update.sh
# Does: git pull -> unzip -> migrate -> collectstatic -> reload site
set -e
cd /home/sahab4321/abp-portal
echo "1/5 Git pull..."
git pull
echo "2/5 Unzip..."
unzip -o -q abp-portal-code.zip
cd arabic-bridge-program
echo "3/5 Migrate..."
./venv/bin/python manage.py migrate
echo "4/5 Collectstatic..."
./venv/bin/python manage.py collectstatic --noinput
echo "5/5 Reload..."
touch /var/www/sahab4321_pythonanywhere_com_wsgi.py
echo "Done! ✅ Site updated aur reload ho gayi."
