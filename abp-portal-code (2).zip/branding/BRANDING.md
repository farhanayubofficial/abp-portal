# ABP Branding Guide

## Brand identity
- **Platform name:** Arabic Bridge Program
- **Abbreviation:** ABP
- **Founder / Owner:** Farhan Khan — display as “Founded and Managed by Farhan Khan” in the About section and footer only. Do not repeat the owner's name on every screen.

## Colors
| Name | Hex | Usage |
|---|---|---|
| Deep navy blue | `#16294D` | Primary — headers, book in logo, main text |
| Navy (light) | `#22375F` | Secondary depth shade (right book page) |
| Emerald green | `#0E7C61` | Secondary — bridge arch, accents, success states |
| Restrained gold | `#C6A15B` | Accent only — star, highlights, never large areas |
| White | `#FFFFFF` | Backgrounds, favicon book pages |

## Logo files (`branding/`)
| File | Purpose |
|---|---|
| `logo-full.svg` | Full lockup: icon + “Arabic Bridge Program” wordmark + “ONLINE ARABIC ACADEMY” tagline. Login/registration pages, landing page, dashboards header, certificates, receipts. |
| `logo-icon.svg` | Compact icon only (book + arch + star). Mobile interface, small screens, app branding. Transparent background. |
| `favicon.svg` | Simplified icon on navy rounded square. Browser tab favicon. |

All logos are original vector artwork created for this project (SVG, scalable, with `<title>`/`<desc>` for accessibility). No third-party or copyrighted marks are used.

## Logo concept
An **open book** (learning & knowledge) in deep navy, from whose pages rises an **emerald calligraphic arch** — simultaneously a bridge (the program's name) and a flowing Arabic-script-inspired stroke. A restrained **gold eight-pointed star** (khatam — subtle Islamic geometric reference) crowns the arch.

## Where branding appears (per spec)
1. Login and registration pages
2. Public landing page and About section
3. Student, teacher, administrator dashboards
4. Navigation header and mobile interface
5. Course certificates and downloadable PDF reports
6. Official fee receipts and academy documents
7. Browser favicon and application branding

## How to replace or update branding later
1. Replace the SVG files in `branding/` keeping the same filenames — every template references these paths.
2. To change colors: update the hex values in `branding/BRANDING.md` (this file) and in the CSS variables file `apps/core/static/css/brand.css` (created in Phase 1).
3. To change the wordmark/tagline: edit the `<text>` elements in `logo-full.svg`.
4. After replacing, check: login page, header, and one dashboard at desktop + mobile widths.
